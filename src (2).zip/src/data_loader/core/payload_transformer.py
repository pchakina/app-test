import importlib
import json
import sys

from injector import Injector, singleton

from data_loader.core.json_mapper.json_mapper import JsonMapper


@singleton
class PayloadTransformer:

    def __init__(self):
        pass

    def transform(self, scriptlets: dict, config: dict, payload: dict) -> dict:
        return JsonMapper(payload, scriptlets).map(self.__to_transform_spec(scriptlets, config))

    def __to_transform_spec(self, scriptlets: dict, config: dict) -> dict:
        spec = dict()

        for key, value in config.items():
            idx = value.find(",")
            if idx != -1:
                ref_mth = value[idx+1:].strip()
                if ref_mth in scriptlets:
                    spec[key] = [value[:idx], ref_mth]
            else:
                spec[key] = [value]

        return spec


if __name__ == '__main__':
    payload = """
    {"person":
         {
            "name": "Juan dela Cruz",
            "age": 37 
        }
    }

    """

    with open("db.json", 'r') as json_file:
        json_data = json.load(json_file)

    config = dict()
    config["employee.name"] = 'person.name'

    transformer = PayloadTransformer()
    payload = transformer.transform([], config, json.loads(payload))
    print(payload)