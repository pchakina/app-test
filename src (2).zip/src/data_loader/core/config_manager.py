from injector import singleton

from data_loader.core.dto import Pipeline


@singleton
class ConfigManager:
    pipelines: list[Pipeline] = []
