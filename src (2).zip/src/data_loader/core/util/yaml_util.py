from typing import TypeVar

import yaml

T = TypeVar('T')


class YamlUtil:

    @staticmethod
    def load_yaml(file_name):
        with open(file_name, 'r') as file:
            yaml_data = yaml.safe_load(file)
            return yaml_data
