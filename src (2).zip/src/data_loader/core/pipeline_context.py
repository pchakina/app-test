from typing import Any

from data_loader.core.dto import Pipeline


class PipelineContext:
    config: dict
    request: Any
    pipeline_config: Pipeline
    pipeline_manager: Any
    response: dict

