from typing import Any

from injector import singleton

# from data_loader.step_impl.enrichment_step import EnrichmentStep
from data_loader.step_impl.http_step import HttpStep
from data_loader.step_impl.iterator_step import IteratorStep
from data_loader.step_impl.log_step import LogStep
from data_loader.step_impl.python_step import PythonStep
from data_loader.step_impl.transformation_step import TransformationStep
from data_loader.step_impl.validator_step import ValidatorStep
from data_loader.core.base_step import BaseStep
from data_loader.core.dto import Step
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext


@singleton
class StepManager:
    #default_impls = [ValidatorStep, TransformationStep, EnrichmentStep, HttpStep, LogStep]
    default_impls = [ValidatorStep, TransformationStep, HttpStep, LogStep, ValidatorStep, PythonStep, IteratorStep]
    pipeline_manager: Any

    def __init__(self):
        self.steps_impl = self.__get_all_subclasses(BaseStep)
        if len(self.steps_impl) == 0:
            self.steps_impl = self.default_impls
        self.step_instances = self.__get_instances(self.steps_impl)

    def __get_all_subclasses(self, cls):
        subclasses = cls.__subclasses__()
        for subclass in subclasses:
            subclasses.extend(self.__get_all_subclasses(subclass))
        return subclasses

    def __get_instances(self, subclasses):
        instances = []
        for clazz in subclasses:
            instance = clazz()
            instances.append(instance)
        return instances

    def __get_instance(self, type) -> BaseStep:
        for instance in self.step_instances:
            if instance.type.casefold() == type.casefold():
                return instance

    def execute(self, step: Step, pipeline_context: PipelineContext, step_context: StepContext, payload: Any) -> str:
        step_instance = self.__get_instance(step.type)
        if step_instance is not None:
            if step.pipeline is not None and step.pipeline is not '':
                # return self.pipeline_manager.execute(step.pipeline, payload)
                return self.pipeline_manager.execute(step.pipeline, pipeline_context, step_context, payload)
            return step_instance.execute(pipeline_context, step_context, payload)
        return None
