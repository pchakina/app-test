from typing import Any

from injector import singleton
from sqlalchemy import text
from sqlalchemy.ext.declarative import declarative_base

from data_loader.core.base_step import BaseStep
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext


Base = declarative_base()


@singleton
class EnrichmentStep(BaseStep):
    type = "enrichment"

    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any) -> Any:
        print("In EnrichmentStep")
        print("received payload: ", payload)
        db_session = get_db_session()

        practice: Practice = Practice(payload, db_session)
        practice_exist, practice_details = practice.practice_exist()
        if practice_exist:
            practitioner: Practitioner = Practitioner(payload, db_session)
            practitioner_exist, practitioner_list = practitioner.practitioner_exist(practice_details)
            if practitioner_exist:
                location: Location = Location(payload, db_session)
                location.practice_billing_location_exist(practitioner_list)
                location.practice_service_location_exist()
        else:
            print("Practice does not exist ...Skip the practitoner create process")
            payload["status"] = "Practice does not exist ...Skip the practitoner create process"
        print(payload)
        return payload
