import json
import httpx

from typing import Any
from pprint import pprint
from injector import singleton

from data_loader.core.base_step import BaseStep
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext

@singleton
class HttpStep(BaseStep):
    type = "http"

    URL = "url"
    METHOD = "method"
    REQUEST_TRANSFORM_CONFIG = "request_transform_config"
    RESPONSE_SUCCESS_TRANSFORM_CONFIG = "response_success_transform_config"
    RESPONSE_FAILURE_TRANSFORM_CONFIG = "response_failure_transform_config"
    BASE_RESPONSE = "base_response"
    BASE_RESPONSE_REQUEST = "REQUEST"
    BASE_RESPONSE_BLANK = "BLANK"
    BASE_RESPONSE_PREV_RESPONSE = "PREV_RESPONSE"

    #ticket viXNf2bvOq4u7u4nI8POuK2x620rvHtL4fQ6cr99I/s8BQyfbB2I47w43G4x9SAgxMxim+9GqGxdGPzSawXQ8w==
    #datasource
    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any)->Any:
        print("In HttpStep")
        print("received payload: " + json.dumps(payload))
        step_config = step_context.step_config
        pipeline_config = pipeline_context.pipeline_config
        if self.REQUEST_TRANSFORM_CONFIG in step_config.config:
            transform_config = step_config.config[self.REQUEST_TRANSFORM_CONFIG]
            request_transform_config = dict()
            payload_transform_config = dict()
            fixedval_transform_config = dict()

            for key, value in transform_config.items():
                value2 = value.lower()
                if value2.startswith("request:"):
                    request_transform_config[key] = value[8:]
                elif value2.startswith("val:"):
                    fixedval_transform_config[key] = value[4:]
                else:
                    payload_transform_config[key] = value

            merged_payload = dict()
            if len(request_transform_config)>0:
                transformed_payload = self.payload_transformer.transform(pipeline_config.scriptlets, request_transform_config, pipeline_context.request)
                merged_payload.update(transformed_payload)

            if len(fixedval_transform_config)>0:
                merged_payload.update(fixedval_transform_config)

            if len(payload_transform_config)>0:
                transformed_payload = self.payload_transformer.transform(pipeline_config.scriptlets, payload_transform_config, pipeline_context.request)
                merged_payload.update(transformed_payload)

            payload = merged_payload.copy()

        url = step_config.config[self.URL]
        method = step_config.config[self.METHOD].lower()
        base_response = step_config.config[self.BASE_RESPONSE].upper()
        json_payload = json.dumps(payload)
        trans_response = dict()
        with httpx.Client() as client:
            if method == "post":
                response = client.post(url, json=json_payload)
            elif method == "get":
                response = client.get(url)
            if response.status_code == 200 or  response.status_code == 201:
                pprint(response.json())
                response = response.json()
                if self.RESPONSE_SUCCESS_TRANSFORM_CONFIG in step_config.config:
                    transform_config = step_config.config[self.RESPONSE_SUCCESS_TRANSFORM_CONFIG]
                    trans_response = self.payload_transformer.transform(pipeline_config.scriptlets, transform_config, response)
                    for key, value in transform_config.items():
                        if value.lower().startswith("val:"):
                            trans_response[key] = value[4:]
                if base_response.startswith(self.BASE_RESPONSE_REQUEST):
                    trans_response.update(pipeline_context.request)
                elif base_response.startswith(self.BASE_RESPONSE_PREV_RESPONSE):
                    trans_response.update(payload)
            else:
                print("404 errrrrror")
                # payload["status"] = "Resource Not Found"
                if self.RESPONSE_FAILURE_TRANSFORM_CONFIG in step_config.config:
                    transform_config = step_config.config[self.RESPONSE_FAILURE_TRANSFORM_CONFIG]
                    try:
                        trans_response = self.payload_transformer.transform(pipeline_config.scriptlets, transform_config, response)
                        for key, value in transform_config.items():
                            if value.startswith("\""):
                                trans_response[key] = value
                    except Exception as e:
                        print(e)
                        return trans_response

            return trans_response



