import json
from typing import Any

from injector import singleton

from data_loader.core.base_step import BaseStep
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext
from jsonpath_ng import jsonpath, parse


@singleton
class IteratorStep(BaseStep):
    type = "iterator"
    COLLECTION_PATH = "array_path"
    PIPELINE = "pipeline"
    VERSION = "version"
    RESPONSE_PATH = "response_path"

    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any):
        step_config = step_context.step_config.config
        pipeline_manager = pipeline_context.pipeline_manager
        collection_path = step_config[self.COLLECTION_PATH]
        json_expr = parse(collection_path)
        pipeline = step_config[self.PIPELINE]
        version = str(step_config[self.VERSION])
        responses = []
        response_attr = str(step_config[self.RESPONSE_PATH])
        response_json_expr = parse(response_attr)
        new_response_path = self.__path2dict(response_attr, [])
        prev_response = pipeline_context.response
        items = json_expr.find(payload)
        for item in items:
            itemvlaue = item.value
            resp = pipeline_manager.execute(pipeline, version, pipeline_context, step_context, itemvlaue)
            print("Received response in iterator: ", resp)
            responses.append(resp)
        print("logging payload with name: " + step_context.step_config.name + " >>>> " + json.dumps(payload))
        new_response = prev_response | new_response_path ## merged response
        new_resp_expr_path = response_json_expr.find(new_response)
        new_resp_extract = new_resp_expr_path
        if hasattr(new_resp_expr_path[0], "value"):
            new_resp_extract = new_resp_expr_path[0].value
        new_resp_extract.append(responses)
        pipeline_context.response = new_response
        return payload

    def __path2dict(self, path, val):
        if path == "":
            return val

        path_elements = path.split(".")
        current_node = path_elements[0]
        children_path = ".".join(path_elements[1:])
        children_dict = self.__path2dict(children_path, val)
        if current_node == "$":
            return children_dict
        return {current_node: children_dict}
