import uvicorn
import os

if __name__ == '__main__':
    host = "localhost" #os.getenv("SERVER__HOST")
    port = 8080 #os.getenv("SERVER__PORT")
    uvicorn.run("data_loader.application:app",
                host=host,
                port=int(port), reload=True,
                log_config="log.ini")
