import json
from typing import Any

from fastapi import APIRouter, status
from injector import Injector

from data_loader.service.pipeline_service import PipelineService

router = APIRouter()
injector = Injector()

pipelineService = injector.get(PipelineService)


@router.post("/", status_code=status.HTTP_201_CREATED)
def process(payload: Any):
    payload_obj = json.loads(payload)
    resp = pipelineService.process(payload_obj)
    return resp
