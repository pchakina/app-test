import json
from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse

from data_loader.core.database import session_manager
from data_loader.rest import user_resource, pipeline_resource

app = FastAPI()
payloadSchema = None
app.include_router(user_resource.router, prefix="/user", tags=["/user"])
app.include_router(pipeline_resource.router, prefix="/pipeline", tags=["/pipeline"])


@app.exception_handler(Exception)
async def entity_not_found_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={"detail": f"{exc.__str__()}"}
    )

#@app.on_event("startup")
#def on_startup():
#    session_manager.create_db_and_tables()
