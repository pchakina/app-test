from data_loader.core.dto import Pipeline, Step


class StepContext:
    params: dict
    pipeline: Pipeline
    step_config: Step
