class PipelineContext:
    params: dict
