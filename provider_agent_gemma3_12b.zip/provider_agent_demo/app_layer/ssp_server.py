"""
app_layer/ssp_server.py
────────────────────────
Layer 1 — sPayer Provider Intelligence Platform / SSP (port 8000)

Provides:
  - A beautiful web UI (the "UI/Presentation Layer")
  - /ask   POST  — sends user question to agent layer via a2a
  - /logs  GET   — shows the centralised audit log
  - /       GET  — the main chat UI (HTML)
"""
import sys, os; sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
from shared.audit_log import log, get_all

app = FastAPI(title="SSP — sPayer Provider Intelligence Platform", version="1.0")

AGENT_BASE = "http://localhost:8001"

# ── System Prompt (SSP Context History field in diagram) ───────────────
SYSTEM_PROMPT = (
    "You are the sPayer Provider Intelligence Platform. "
    "You help healthcare operations teams look up provider and facility data quickly. "
    "Be concise, professional, and accurate."
)

CONVERSATION_HISTORY: list[dict] = []   # in-memory context window


class AskRequest(BaseModel):
    question: str


@app.post("/ask")
async def ask(req: AskRequest):
    """Receives a question from the UI and forwards it to the agent layer via a2a."""
    log("app", "ssp", "user_question", {"question": req.question})

    # Store in conversation history (SSP Context History)
    CONVERSATION_HISTORY.append({"role": "user", "content": req.question})

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(f"{AGENT_BASE}/a2a/task", json={
            "sender": "ssp_app_layer",
            "question": req.question,
            "intent": "auto",
        })
        result = resp.json()

    answer = result.get("answer", "Sorry, no answer was returned.")
    CONVERSATION_HISTORY.append({"role": "assistant", "content": answer})

    log("app", "ssp", "answer_delivered", {"intent": result.get("intent"), "answer": answer[:80]})
    return {
        "question": req.question,
        "answer": answer,
        "intent": result.get("intent"),
        "raw_count": len(result.get("raw_data", {}).get("results", [])),
    }


@app.get("/logs")
def audit_logs():
    return get_all()


@app.get("/discover")
async def discover_agents():
    async with httpx.AsyncClient(timeout=5) as client:
        resp = await client.get(f"{AGENT_BASE}/a2a/discover")
        return resp.json()


@app.get("/", response_class=HTMLResponse)
def ui():
    return HTMLResponse(content=CHAT_UI)


@app.get("/health")
def health():
    return {"status": "healthy", "layer": "app", "service": "ssp"}


# ── The Chat UI ─────────────────────────────────────────────────────────
CHAT_UI = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>sPayer Provider Intelligence Platform</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', system-ui, sans-serif; background: #0f1117; color: #e8e8e8; height: 100vh; display: flex; flex-direction: column; }
  header { background: #1a1d2e; border-bottom: 1px solid #2d3050; padding: 14px 24px; display: flex; align-items: center; gap: 12px; }
  .logo { width: 32px; height: 32px; background: linear-gradient(135deg,#4f46e5,#7c3aed); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 16px; }
  header h1 { font-size: 16px; font-weight: 600; color: #fff; }
  header span { font-size: 12px; color: #6b7280; margin-left: 8px; }
  .badge { background: #1e3a5f; color: #60a5fa; font-size: 11px; padding: 2px 8px; border-radius: 4px; margin-left: auto; }
  .main { display: flex; flex: 1; overflow: hidden; }
  .sidebar { width: 220px; background: #13151f; border-right: 1px solid #2d3050; padding: 16px; overflow-y: auto; flex-shrink: 0; }
  .sidebar h3 { font-size: 11px; font-weight: 600; color: #6b7280; text-transform: uppercase; letter-spacing: .08em; margin-bottom: 12px; }
  .layer-card { background: #1a1d2e; border: 1px solid #2d3050; border-radius: 8px; padding: 10px; margin-bottom: 8px; }
  .layer-card .title { font-size: 12px; font-weight: 600; color: #a5b4fc; margin-bottom: 4px; }
  .layer-card .desc { font-size: 11px; color: #6b7280; line-height: 1.5; }
  .dot { display: inline-block; width: 6px; height: 6px; border-radius: 50%; background: #22c55e; margin-right: 5px; }
  .chat { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
  .messages { flex: 1; overflow-y: auto; padding: 24px; display: flex; flex-direction: column; gap: 16px; }
  .bubble { max-width: 75%; padding: 12px 16px; border-radius: 12px; font-size: 14px; line-height: 1.6; }
  .bubble.user { background: #4f46e5; color: #fff; align-self: flex-end; border-bottom-right-radius: 4px; }
  .bubble.bot  { background: #1a1d2e; border: 1px solid #2d3050; align-self: flex-start; border-bottom-left-radius: 4px; }
  .bubble .meta { font-size: 11px; color: #6b7280; margin-top: 6px; }
  .bubble.bot .meta { color: #4f46e5; }
  .typing { display: none; align-self: flex-start; background: #1a1d2e; border: 1px solid #2d3050; border-radius: 12px; padding: 12px 16px; }
  .typing span { display: inline-block; width: 6px; height: 6px; border-radius: 50%; background: #4f46e5; margin: 0 2px; animation: bounce .8s infinite; }
  .typing span:nth-child(2) { animation-delay: .15s; }
  .typing span:nth-child(3) { animation-delay: .3s; }
  @keyframes bounce { 0%,60%,100% { transform: translateY(0); } 30% { transform: translateY(-6px); } }
  .input-bar { background: #13151f; border-top: 1px solid #2d3050; padding: 16px 24px; display: flex; gap: 10px; }
  .input-bar input { flex: 1; background: #1a1d2e; border: 1px solid #2d3050; color: #e8e8e8; border-radius: 8px; padding: 10px 16px; font-size: 14px; outline: none; transition: border-color .2s; }
  .input-bar input:focus { border-color: #4f46e5; }
  .input-bar button { background: #4f46e5; color: white; border: none; border-radius: 8px; padding: 10px 20px; font-size: 14px; cursor: pointer; transition: background .2s; }
  .input-bar button:hover { background: #4338ca; }
  .chips { padding: 0 24px 12px; display: flex; gap: 8px; flex-wrap: wrap; }
  .chip { background: #1a1d2e; border: 1px solid #2d3050; color: #a5b4fc; font-size: 12px; padding: 5px 12px; border-radius: 20px; cursor: pointer; transition: background .2s; }
  .chip:hover { background: #2d3250; }
  .log-panel { width: 280px; background: #13151f; border-left: 1px solid #2d3050; padding: 16px; overflow-y: auto; flex-shrink: 0; }
  .log-panel h3 { font-size: 11px; font-weight: 600; color: #6b7280; text-transform: uppercase; letter-spacing:.08em; margin-bottom: 12px; }
  .log-entry { font-size: 11px; font-family: monospace; color: #6b7280; padding: 4px 0; border-bottom: 1px solid #1e2030; }
  .log-entry .l-app { color: #a5b4fc; } .log-entry .l-agent { color: #34d399; } .log-entry .l-tools { color: #fbbf24; }
</style>
</head>
<body>
<header>
  <div class="logo">🏥</div>
  <h1>sPayer Provider Intelligence Platform</h1>
  <span>SSP — Application Layer</span>
  <div class="badge"><span class="dot"></span>All layers online</div>
</header>
<div class="main">
  <!-- Sidebar: Architecture overview -->
  <div class="sidebar">
    <h3>Architecture</h3>
    <div class="layer-card">
      <div class="title">🏢 App Layer (you)</div>
      <div class="desc">SSP UI + LLM context + conversation history. Port 8000.</div>
    </div>
    <div class="layer-card">
      <div class="title">🤖 Agent Layer</div>
      <div class="desc">Registry, practitioner agent, facility agent, synthesis agent. Port 8001.</div>
    </div>
    <div class="layer-card">
      <div class="title">🔧 Tools Layer</div>
      <div class="desc">MCP server — provider data, facility data, NPI validation. Port 8002.</div>
    </div>
    <div class="layer-card">
      <div class="title">📓 Audit Log</div>
      <div class="desc">Every action from every layer is logged in real time →</div>
    </div>
  </div>

  <!-- Chat -->
  <div class="chat">
    <div class="messages" id="messages">
      <div class="bubble bot">
        👋 Hello! I'm the <strong>sPayer Provider Intelligence Platform</strong>.<br><br>
        Ask me to find a doctor, look up a clinic, or validate an NPI. I'll route your request through the agent layer automatically.
        <div class="meta">system prompt loaded • context window ready</div>
      </div>
    </div>
    <div class="chips">
      <div class="chip" onclick="ask('Find a cardiologist in Texas')">Find a cardiologist in TX</div>
      <div class="chip" onclick="ask('Look up Sunrise Medical Center')">Sunrise Medical Center</div>
      <div class="chip" onclick="ask('Validate NPI 1234567890')">Validate NPI</div>
      <div class="chip" onclick="ask('Find a pediatrician')">Find pediatrician</div>
    </div>
    <div class="typing" id="typing"><span></span><span></span><span></span></div>
    <div class="input-bar">
      <input id="q" placeholder="Ask about a provider, clinic, or NPI..." onkeydown="if(event.key==='Enter')send()">
      <button onclick="send()">Send ↗</button>
    </div>
  </div>

  <!-- Live audit log -->
  <div class="log-panel">
    <h3>Live audit log</h3>
    <div id="logbox"></div>
  </div>
</div>

<script>
async function send() {
  const q = document.getElementById('q').value.trim();
  if (!q) return;
  document.getElementById('q').value = '';
  ask(q);
}

async function ask(question) {
  addBubble(question, 'user');
  document.getElementById('typing').style.display = 'flex';
  scrollDown();
  try {
    const r = await fetch('/ask', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({question})
    });
    const d = await r.json();
    document.getElementById('typing').style.display = 'none';
    addBubble(d.answer, 'bot', `intent: ${d.intent} • ${d.raw_count} records found`);
  } catch(e) {
    document.getElementById('typing').style.display = 'none';
    addBubble('Error reaching agent layer. Make sure all 3 servers are running.', 'bot', 'error');
  }
  updateLogs();
  scrollDown();
}

function addBubble(text, role, meta='') {
  const box = document.getElementById('messages');
  const d = document.createElement('div');
  d.className = `bubble ${role}`;
  d.innerHTML = text.replace(/•/g, '<br>•') + (meta ? `<div class="meta">${meta}</div>` : '');
  box.appendChild(d);
}

function scrollDown() {
  const box = document.getElementById('messages');
  box.scrollTop = box.scrollHeight;
}

async function updateLogs() {
  const r = await fetch('/logs');
  const entries = await r.json();
  const box = document.getElementById('logbox');
  box.innerHTML = entries.slice(-30).reverse().map(e =>
    `<div class="log-entry"><span class="l-${e.layer}">[${e.layer}]</span> ${e.component}.${e.action}</div>`
  ).join('');
}

setInterval(updateLogs, 3000);
updateLogs();
</script>
</body>
</html>"""


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="warning")
