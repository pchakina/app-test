#!/usr/bin/env python3
"""
scripts/run_all.py
───────────────────
Starts all three layers as background processes:
  Port 8002 → Tools Layer  (MCP Server)
  Port 8001 → Agent Layer  (Gemma 3 12B + A2A Router)
  Port 8000 → App Layer    (SSP Chat UI)

Then opens http://localhost:8000 in your browser.

Usage:
    python scripts/run_all.py
    Ctrl+C to stop all servers.
"""
import subprocess
import sys
import time
import os
import signal
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

SERVERS = [
    {
        "name":   "Tools Layer  (port 8002)",
        "module": "tools_layer.tools_server",
        "port":   8002,
        "color":  "\033[93m",  # yellow
    },
    {
        "name":   "Agent Layer  (port 8001)",
        "module": "agent_layer.agent_server",
        "port":   8001,
        "color":  "\033[92m",  # green
    },
    {
        "name":   "App Layer    (port 8000)",
        "module": "app_layer.ssp_server",
        "port":   8000,
        "color":  "\033[96m",  # cyan
    },
]

RESET = "\033[0m"
BOLD  = "\033[1m"

procs = []

def start_server(cfg):
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT)
    cmd = [sys.executable, "-m", cfg["module"]]
    p = subprocess.Popen(cmd, cwd=ROOT, env=env)
    procs.append(p)
    print(f"  {cfg['color']}▶ {cfg['name']}{RESET}  (PID {p.pid})")
    return p

def stop_all(sig=None, frame=None):
    print(f"\n{BOLD}Stopping all servers...{RESET}")
    for p in procs:
        try:
            p.terminate()
        except Exception:
            pass
    for p in procs:
        try:
            p.wait(timeout=3)
        except Exception:
            p.kill()
    print("All stopped. Goodbye!")
    sys.exit(0)

if __name__ == "__main__":
    signal.signal(signal.SIGINT,  stop_all)
    signal.signal(signal.SIGTERM, stop_all)

    print(f"\n{BOLD}Provider Agent Demo — Gemma 3 12B via AWS Bedrock{RESET}")
    print("─" * 52)
    print("Starting layers...\n")

    for cfg in SERVERS:
        start_server(cfg)
        time.sleep(1.5)  # give each server time to bind

    print(f"\n{BOLD}All servers running.{RESET}")
    print(f"  Chat UI → {BOLD}http://localhost:8000{RESET}")
    print(f"  Agents  → http://localhost:8001/a2a/discover")
    print(f"  Tools   → http://localhost:8002/registry")
    print(f"\nPress {BOLD}Ctrl+C{RESET} to stop.\n")

    time.sleep(2)
    try:
        webbrowser.open("http://localhost:8000")
    except Exception:
        pass

    # Keep alive until Ctrl+C
    while True:
        time.sleep(1)
        # Check if any server died unexpectedly
        for i, p in enumerate(procs):
            if p.poll() is not None:
                name = SERVERS[i]["name"]
                print(f"\n⚠  {name} exited (code {p.returncode}). Check logs.")
