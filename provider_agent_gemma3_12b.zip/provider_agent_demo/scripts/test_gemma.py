#!/usr/bin/env python3
"""
scripts/test_gemma.py
──────────────────────
Quick connectivity test for Google Gemma 3 12B via AWS Bedrock.
Run this BEFORE starting the servers to confirm your credentials work.

Usage:
    python scripts/test_gemma.py
    AWS_ACCESS_KEY_ID=... AWS_SECRET_ACCESS_KEY=... python scripts/test_gemma.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from shared.bedrock_gemma import BedrockGemma

def run_test():
    print("=" * 60)
    print("Google Gemma 3 12B — AWS Bedrock connectivity test")
    print("=" * 60)

    gemma = BedrockGemma()

    tests = [
        {
            "name": "Basic hello-world",
            "system": "You are a helpful assistant. Be very brief.",
            "user": "Say exactly: Hello from Gemma 3 12B on Bedrock!",
        },
        {
            "name": "Intent classification",
            "system": (
                "Classify the intent as exactly one word: 'provider' or 'facility'. "
                "No other output."
            ),
            "user": "Find me a cardiologist in Texas",
        },
        {
            "name": "Synthesis / summarisation",
            "system": "You are a healthcare assistant. Summarise in one sentence.",
            "user": (
                "Data: Dr. Alice Chen | Specialty: Cardiology | State: TX | NPI: 1234567890\n"
                "Question: Who is the cardiologist available in Texas?"
            ),
        },
    ]

    all_passed = True
    for t in tests:
        print(f"\n▶ Test: {t['name']}")
        answer = gemma.chat_sync(t["user"], system_prompt=t["system"])
        print(f"  Response: {answer[:120]}")
        if answer.startswith("["):
            print("  ✗ FAILED — likely a credentials or model-access issue.")
            all_passed = False
        else:
            print("  ✓ PASSED")

    print("\n" + "=" * 60)
    if all_passed:
        print("✓ All tests passed — ready to run the full demo!")
        print("  Start servers with:  python scripts/run_all.py")
    else:
        print("✗ Some tests failed. Check:")
        print("  1. AWS credentials set (env vars or IAM role)")
        print("  2. Model enabled in Bedrock console:")
        print("     https://console.aws.amazon.com/bedrock/home#/modelaccess")
        print(f"  3. Model ID correct: google.gemma-3-12b-it")
        print(f"  4. Region correct (default: us-east-1)")

if __name__ == "__main__":
    run_test()
