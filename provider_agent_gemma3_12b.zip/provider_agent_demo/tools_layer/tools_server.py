"""
tools_layer/tools_server.py
────────────────────────────
Layer 3 — Tools Registry (MCP Server, port 8002)
Holds the real data: provider lookup, facility lookup, validation.

In the real system this would call Symplr sPayerAPIs.
Here we use in-memory mock data so it runs 100% locally.
"""
import sys, os; sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from fastapi import FastAPI, HTTPException
from shared.models import ToolBlueprint
from shared.audit_log import log

app = FastAPI(title="Tools Registry (MCP Server)", version="1.0")

# ── Tool Registry Blueprint ────────────────────────────────────────────
TOOLS_REGISTRY: dict[str, ToolBlueprint] = {
    "lookup_provider": ToolBlueprint(
        tool_name="lookup_provider",
        description="Find a healthcare provider by name or NPI",
        input_schema={"query": "string"},
        accessible_by=["practitioner_agent", "synthesis_agent"],
        owner_team="Provider Data Team",
        requires_human_approval=False,
    ),
    "lookup_facility": ToolBlueprint(
        tool_name="lookup_facility",
        description="Find a clinic or hospital by name or ID",
        input_schema={"query": "string"},
        accessible_by=["facility_agent", "synthesis_agent"],
        owner_team="Facility Data Team",
        requires_human_approval=False,
    ),
    "validate_npi": ToolBlueprint(
        tool_name="validate_npi",
        description="Validate an NPI number against NPPES",
        input_schema={"npi": "string"},
        accessible_by=["practitioner_agent"],
        owner_team="Validation Team",
        requires_human_approval=False,
    ),
}

# ── Mock Data (replaces Symplr sPayerAPIs) ────────────────────────────
PROVIDERS = [
    {"npi": "1234567890", "name": "Dr. Alice Chen",   "specialty": "Cardiology",    "state": "TX", "active": True},
    {"npi": "9876543210", "name": "Dr. Bob Martinez", "specialty": "Pediatrics",    "state": "FL", "active": True},
    {"npi": "1111111111", "name": "Dr. Carol White",  "specialty": "Neurology",     "state": "CA", "active": False},
]
FACILITIES = [
    {"id": "FAC001", "name": "Sunrise Medical Center",  "city": "Austin",     "state": "TX", "beds": 120},
    {"id": "FAC002", "name": "Bayshore Clinic",         "city": "Miami",      "state": "FL", "beds": 45},
    {"id": "FAC003", "name": "Golden Gate Hospital",    "city": "San Francisco", "state": "CA", "beds": 300},
]


# ── Endpoints ──────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "healthy", "layer": "tools", "service": "mcp_server"}


@app.get("/registry")
def list_tools():
    log("tools", "registry", "list_tools", {})
    return {name: vars(bp) for name, bp in TOOLS_REGISTRY.items()}


@app.get("/tools/lookup_provider")
def lookup_provider(query: str, caller: str = "unknown"):
    log("tools", "lookup_provider", "query", {"query": query, "caller": caller})
    q = query.lower()
    results = [p for p in PROVIDERS if q in p["name"].lower() or q in p["specialty"].lower() or q == p["npi"]]
    if not results:
        results = PROVIDERS  # return all if nothing matches (demo mode)
    log("tools", "lookup_provider", "result", {"count": len(results)})
    return {"tool": "lookup_provider", "results": results}


@app.get("/tools/lookup_facility")
def lookup_facility(query: str, caller: str = "unknown"):
    log("tools", "lookup_facility", "query", {"query": query, "caller": caller})
    q = query.lower()
    results = [f for f in FACILITIES if q in f["name"].lower() or q in f["city"].lower() or q in f["state"].lower()]
    if not results:
        results = FACILITIES
    log("tools", "lookup_facility", "result", {"count": len(results)})
    return {"tool": "lookup_facility", "results": results}


@app.get("/tools/validate_npi")
def validate_npi(npi: str, caller: str = "unknown"):
    log("tools", "validate_npi", "query", {"npi": npi, "caller": caller})
    match = next((p for p in PROVIDERS if p["npi"] == npi), None)
    valid = match is not None
    log("tools", "validate_npi", "result", {"valid": valid})
    return {"tool": "validate_npi", "npi": npi, "valid": valid, "provider": match}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002, log_level="warning")
