"""shared/config_loader.py — loads config/config.yaml with env-var overrides."""
import os
from pathlib import Path
import yaml

_DEFAULT = Path(__file__).resolve().parent.parent / "config" / "config.yaml"

def load_config(path=None):
    p = Path(path) if path else _DEFAULT
    if not p.exists():
        return {}
    with open(p) as f:
        cfg = yaml.safe_load(f) or {}
    # Environment variable overrides: BEDROCK__MODEL_ID, AWS__REGION, etc.
    for key, val in os.environ.items():
        if "__" not in key:
            continue
        parts = key.lower().split("__")
        node = cfg
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        node[parts[-1]] = val
    return cfg
