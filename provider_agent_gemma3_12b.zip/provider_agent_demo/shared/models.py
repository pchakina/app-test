"""
shared/models.py  —  shared data contracts across all layers
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class A2AMessage:
    """Agent-to-Agent message envelope (mirrors the a2a http protocol)"""
    sender: str
    recipient: str
    intent: str           # e.g. "lookup_provider", "ask_question"
    payload: dict
    message_id: str = ""
    timestamp: str = ""

    def __post_init__(self):
        import uuid
        self.message_id = self.message_id or str(uuid.uuid4())[:8]
        self.timestamp = self.timestamp or datetime.now().isoformat()


@dataclass
class AgentBlueprint:
    """What every agent must declare about itself (Agent Blueprint)"""
    name: str
    description: str
    owner_team: str
    llm_used: str
    skills: list[str]          # what this agent can do
    discover_endpoint: str     # /a2a/discover
    task_endpoint: str         # /a2a/task
    health_endpoint: str       # /health


@dataclass
class ToolBlueprint:
    """What every tool must declare (Tools Registry Blueprint)"""
    tool_name: str
    description: str
    input_schema: dict
    accessible_by: list[str]   # which agents can call this
    owner_team: str
    requires_human_approval: bool = False


@dataclass
class AuditLogEntry:
    """Every action across all layers is logged here"""
    layer: str
    component: str
    action: str
    details: dict
    status: str = "ok"
    timestamp: str = ""

    def __post_init__(self):
        self.timestamp = self.timestamp or datetime.now().isoformat()
