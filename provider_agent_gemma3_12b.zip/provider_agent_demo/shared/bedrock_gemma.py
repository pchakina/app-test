"""
shared/bedrock_gemma.py
────────────────────────
Reusable AWS Bedrock client for Google Gemma 3 12B IT.

Model ID  : google.gemma-3-12b-it
Context   : 128K tokens
API       : boto3 bedrock-runtime  ─  converse()  (preferred)
                                   ─  invoke_model() (fallback)

Auth options (in priority order):
  1. Env vars:  AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + AWS_DEFAULT_REGION
  2. Config  :  bedrock.aws_access_key_id / secret / region  in config.yaml
  3. IAM role:  works automatically on EC2 / ECS / Lambda

Usage:
    from shared.bedrock_gemma import BedrockGemma
    llm = BedrockGemma(cfg)
    answer = await llm.chat("Find me a cardiologist in Texas")
    answer = llm.chat_sync("Find me a cardiologist in Texas")
"""

import json
import asyncio
import logging
from functools import partial
from typing import Optional

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

logger = logging.getLogger("bedrock_gemma")

MODEL_ID = "google.gemma-3-12b-it"


class BedrockGemma:
    """
    Thin wrapper around AWS Bedrock → Google Gemma 3 12B IT.
    Supports both async (chat) and sync (chat_sync) usage.
    """

    def __init__(self, cfg: Optional[dict] = None):
        cfg = cfg or {}
        bedrock_cfg = cfg.get("bedrock", {})
        aws_cfg     = cfg.get("aws", {})

        region = (
            bedrock_cfg.get("region")
            or aws_cfg.get("region")
            or "us-east-1"
        )

        session_kwargs: dict = {"region_name": region}

        # Explicit credentials (only if provided; otherwise boto3 uses its chain)
        key = bedrock_cfg.get("aws_access_key_id") or aws_cfg.get("access_key_id")
        secret = bedrock_cfg.get("aws_secret_access_key") or aws_cfg.get("secret_access_key")
        if key and secret:
            session_kwargs["aws_access_key_id"]     = key
            session_kwargs["aws_secret_access_key"] = secret

        self.region   = region
        self.model_id = bedrock_cfg.get("model_id", MODEL_ID)
        self.max_tokens = bedrock_cfg.get("max_tokens", 512)
        self.temperature = bedrock_cfg.get("temperature", 0.3)

        try:
            self._client = boto3.client("bedrock-runtime", **session_kwargs)
            logger.info("Bedrock client ready — model: %s  region: %s", self.model_id, region)
        except Exception as e:
            logger.error("Failed to create Bedrock client: %s", e)
            self._client = None

    # ── Async interface (use inside FastAPI / asyncio) ─────────────────
    async def chat(
        self,
        user_message: str,
        system_prompt: Optional[str] = None,
        conversation_history: Optional[list] = None,
    ) -> str:
        """Non-blocking call — runs the sync boto3 call in a thread pool."""
        loop = asyncio.get_event_loop()
        fn = partial(
            self.chat_sync,
            user_message,
            system_prompt,
            conversation_history,
        )
        return await loop.run_in_executor(None, fn)

    # ── Sync interface (scripts, tests, non-async contexts) ────────────
    def chat_sync(
        self,
        user_message: str,
        system_prompt: Optional[str] = None,
        conversation_history: Optional[list] = None,
    ) -> str:
        if not self._client:
            return "[Bedrock client not initialised — check AWS credentials]"

        # Build messages list (multi-turn aware)
        messages = list(conversation_history or [])
        messages.append({"role": "user", "content": [{"text": user_message}]})

        kwargs: dict = {
            "modelId": self.model_id,
            "messages": messages,
            "inferenceConfig": {
                "maxTokens": self.max_tokens,
                "temperature": self.temperature,
            },
        }

        # Gemma 3 12B supports system prompts via the system field
        if system_prompt:
            kwargs["system"] = [{"text": system_prompt}]

        try:
            response = self._client.converse(**kwargs)
            output   = response["output"]["message"]["content"]
            text     = " ".join(block["text"] for block in output if "text" in block)
            logger.debug("Gemma response (%d chars): %s…", len(text), text[:60])
            return text.strip()

        except NoCredentialsError:
            msg = (
                "[AWS credentials not found] Set AWS_ACCESS_KEY_ID + "
                "AWS_SECRET_ACCESS_KEY + AWS_DEFAULT_REGION, or attach an IAM role."
            )
            logger.error(msg)
            return msg

        except ClientError as e:
            code = e.response["Error"]["Code"]
            msg  = e.response["Error"]["Message"]
            logger.error("Bedrock ClientError %s: %s", code, msg)

            if code == "AccessDeniedException":
                return f"[Access denied to {self.model_id}. Enable it in the Bedrock console → Model access.]"
            if code == "ValidationException":
                return f"[Validation error: {msg}]"
            if code == "ThrottlingException":
                return "[Bedrock rate limit hit — retry in a moment]"
            return f"[Bedrock error {code}: {msg}]"

        except Exception as e:
            logger.error("Unexpected Bedrock error: %s", e)
            return f"[Unexpected error: {e}]"

    # ── Convenience: build a Bedrock conversation history entry ────────
    @staticmethod
    def user_turn(text: str) -> dict:
        return {"role": "user", "content": [{"text": text}]}

    @staticmethod
    def assistant_turn(text: str) -> dict:
        return {"role": "assistant", "content": [{"text": text}]}
