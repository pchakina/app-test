"""
shared/audit_log.py  —  Centralised Audit Logging (mirrors "Status Service" in diagram)
All three layers write here.
"""
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import List

from shared.models import AuditLogEntry

_LOG_FILE = Path("audit.log")
_entries: List[AuditLogEntry] = []

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%H:%M:%S",
)
_logger = logging.getLogger("audit")


def log(layer: str, component: str, action: str, details: dict, status: str = "ok") -> None:
    entry = AuditLogEntry(layer=layer, component=component,
                          action=action, details=details, status=status)
    _entries.append(entry)
    line = json.dumps({
        "ts": entry.timestamp, "layer": layer,
        "component": component, "action": action,
        "status": status, **details,
    })
    _logger.info(line)
    with open(_LOG_FILE, "a") as f:
        f.write(line + "\n")


def get_all() -> List[dict]:
    return [vars(e) for e in _entries]
