"""
agent_layer/agent_server.py   (Gemma 3 12B edition)
─────────────────────────────────────────────────────
Layer 2 — Agent Registry + Reusable Agent Pool  (port 8001)

LLM: Google Gemma 3 12B IT via AWS Bedrock (model: google.gemma-3-12b-it)
     Falls back gracefully with a descriptive message if credentials are absent.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import httpx
from fastapi import FastAPI
from pydantic import BaseModel

from shared.models import AgentBlueprint
from shared.audit_log import log
from shared.bedrock_gemma import BedrockGemma

app = FastAPI(title="Agent Registry — Gemma 3 12B", version="2.0")
TOOLS_BASE = "http://localhost:8002"

try:
    from shared.config_loader import load_config
    _cfg = load_config()
except Exception:
    _cfg = {}

gemma = BedrockGemma(_cfg)

INTENT_SYSTEM = (
    "You are an intent router for a healthcare provider intelligence platform. "
    "Given a user question, respond with EXACTLY one word: "
    "'provider' if the question is about doctors/practitioners/NPIs, "
    "'facility' if it is about clinics/hospitals/centers. "
    "No explanation, no punctuation — one word only."
)

SYNTHESIS_SYSTEM = (
    "You are a friendly, professional healthcare operations assistant. "
    "You receive structured provider or facility data and a user question. "
    "Respond in 2-3 clear, helpful sentences. Be concise and accurate."
)

AGENT_REGISTRY: dict = {
    "intent_router": AgentBlueprint(
        name="intent_router",
        description="Uses Gemma 3 12B to classify intent",
        owner_team="Platform AI Team",
        llm_used="google.gemma-3-12b-it via AWS Bedrock",
        skills=["intent_classification"],
        discover_endpoint="/a2a/discover",
        task_endpoint="/a2a/task",
        health_endpoint="/health",
    ),
    "practitioner_agent": AgentBlueprint(
        name="practitioner_agent",
        description="Looks up healthcare practitioners",
        owner_team="Provider AI Team",
        llm_used="google.gemma-3-12b-it via AWS Bedrock",
        skills=["lookup_provider", "validate_npi"],
        discover_endpoint="/a2a/discover",
        task_endpoint="/a2a/task",
        health_endpoint="/health",
    ),
    "facility_agent": AgentBlueprint(
        name="facility_agent",
        description="Looks up clinics and hospitals",
        owner_team="Facility AI Team",
        llm_used="google.gemma-3-12b-it via AWS Bedrock",
        skills=["lookup_facility"],
        discover_endpoint="/a2a/discover",
        task_endpoint="/a2a/task",
        health_endpoint="/health",
    ),
    "synthesis_agent": AgentBlueprint(
        name="synthesis_agent",
        description="Formats the final answer using Gemma 3 12B",
        owner_team="Platform AI Team",
        llm_used="google.gemma-3-12b-it via AWS Bedrock",
        skills=["format_response", "summarise"],
        discover_endpoint="/a2a/discover",
        task_endpoint="/a2a/task",
        health_endpoint="/health",
    ),
}

async def detect_intent(question: str) -> str:
    log("agent", "intent_router", "start", {"question": question})
    raw = await gemma.chat(user_message=question, system_prompt=INTENT_SYSTEM)
    intent = raw.strip().lower().split()[0] if raw.strip() else "provider"
    intent = intent if intent in ("provider", "facility") else "provider"
    log("agent", "intent_router", "classified", {"intent": intent, "raw": raw[:40]})
    return intent

async def run_practitioner_agent(question: str) -> dict:
    log("agent", "practitioner_agent", "start", {"question": question})
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(f"{TOOLS_BASE}/tools/lookup_provider",
                                params={"query": question, "caller": "practitioner_agent"})
        data = resp.json()
    log("agent", "practitioner_agent", "tool_result", {"count": len(data.get("results", []))})
    return data

async def run_facility_agent(question: str) -> dict:
    log("agent", "facility_agent", "start", {"question": question})
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(f"{TOOLS_BASE}/tools/lookup_facility",
                                params={"query": question, "caller": "facility_agent"})
        data = resp.json()
    log("agent", "facility_agent", "tool_result", {"count": len(data.get("results", []))})
    return data

async def run_synthesis_agent(raw_data: dict, question: str) -> str:
    log("agent", "synthesis_agent", "start", {"question": question})
    results = raw_data.get("results", [])
    if not results:
        return "No results were found for your query."

    lines = []
    for r in results[:3]:
        if "npi" in r:
            status = "active" if r.get("active") else "inactive"
            lines.append(f"  - {r['name']} | Specialty: {r['specialty']} | State: {r['state']} | NPI: {r['npi']} | Status: {status}")
        else:
            lines.append(f"  - {r['name']} | City: {r['city']}, {r['state']} | Beds: {r.get('beds','N/A')} | ID: {r['id']}")

    data_block = "\n".join(lines)
    user_msg = f"User question: \"{question}\"\n\nData retrieved:\n{data_block}\n\nPlease answer the user's question based on this data."
    answer = await gemma.chat(user_message=user_msg, system_prompt=SYNTHESIS_SYSTEM)
    log("agent", "synthesis_agent", "done", {"answer_length": len(answer), "model": gemma.model_id})
    return answer

class TaskRequest(BaseModel):
    sender: str = "app_layer"
    question: str
    intent: str = "auto"

@app.post("/a2a/task")
async def handle_task(req: TaskRequest):
    log("agent", "registry", "task_received", {"sender": req.sender, "question": req.question})

    if req.intent == "auto":
        intent = await detect_intent(req.question)
    elif req.intent in ("provider", "facility"):
        intent = req.intent
    else:
        intent = "provider"

    raw = await run_facility_agent(req.question) if intent == "facility" else await run_practitioner_agent(req.question)
    log("agent", "registry", "intent_routed", {"intent": intent})

    answer = await run_synthesis_agent(raw, req.question)
    log("agent", "registry", "task_complete", {"intent": intent, "model": gemma.model_id})

    return {"question": req.question, "intent": intent, "raw_data": raw, "answer": answer, "llm": gemma.model_id}

@app.get("/a2a/discover")
def discover():
    log("agent", "registry", "discover", {})
    return {name: vars(bp) for name, bp in AGENT_REGISTRY.items()}

@app.get("/health")
def health():
    return {"status": "healthy", "layer": "agent", "service": "agent_registry",
            "llm": gemma.model_id, "llm_region": gemma.region}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001, log_level="warning")
