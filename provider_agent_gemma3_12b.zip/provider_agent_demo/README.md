# Provider Agent Demo — Google Gemma 3 12B via AWS Bedrock

End-to-end agentic demo implementing the 3-layer architecture with
**Google Gemma 3 12B IT** (`google.gemma-3-12b-it`) as the LLM brain.

```
┌─────────────────────────────────────────────────────────────┐
│  App Layer    — SSP Chat UI                    :8000        │
│  (Layer 1)     sends user question via a2a http             │
├─────────────────────────────────────────────────────────────┤
│  Agent Layer  — A2A Router + Specialist Agents :8001        │
│  (Layer 2)     Gemma 3 12B decides intent                   │
│                Gemma 3 12B synthesises answer               │
├─────────────────────────────────────────────────────────────┤
│  Tools Layer  — MCP Server (mock provider data) :8002       │
│  (Layer 3)     REST API returning real structured data      │
└─────────────────────────────────────────────────────────────┘
           Centralised Audit Log  →  audit.log
```

---

## Model Details

| Field | Value |
|---|---|
| **Model** | Google Gemma 3 12B IT |
| **Bedrock model ID** | `google.gemma-3-12b-it` |
| **Context window** | 128K tokens |
| **API** | `bedrock-runtime` → `converse()` |
| **Pricing** | ~$0.05/1M input · $0.10/1M output tokens |

---

## Prerequisites

```bash
# 1. Install dependencies
pip install fastapi uvicorn httpx boto3 pyyaml

# 2. Set AWS credentials (choose one method)

# Method A — environment variables (recommended for local dev)
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
export AWS_DEFAULT_REGION=us-east-1

# Method B — edit config/config.yaml
# Set aws.access_key_id and aws.secret_access_key

# Method C — IAM role (automatic on EC2/ECS/Lambda)

# 3. Enable Gemma 3 12B in the Bedrock console
#    https://console.aws.amazon.com/bedrock/home#/modelaccess
#    → Request access to:  google.gemma-3-12b-it
```

---

## Quickstart

```bash
# Step 1 — verify Bedrock + Gemma access
python scripts/test_gemma.py

# Step 2 — launch all three layers
python scripts/run_all.py

# Browser opens automatically at http://localhost:8000
```

---

## Try These Queries

| Query | What happens |
|---|---|
| `Find a cardiologist in Texas` | Gemma → intent=provider → PractitionerAgent → Tools Layer → Gemma synthesises |
| `Look up Sunrise Medical Center` | Gemma → intent=facility → FacilityAgent → Tools Layer → Gemma synthesises |
| `Validate NPI 1234567890` | PractitionerAgent → Tools Layer validate_npi endpoint |
| `Find a pediatrician in Florida` | Full pipeline end-to-end |

---

## How Gemma 3 12B Is Used (Two Roles)

### Role 1 — Intent Router
```
System: "Respond with exactly one word: 'provider' or 'facility'."
User:   "Find me a cardiologist in Texas"
Gemma → "provider"
```

### Role 2 — Synthesis Agent
```
System: "You are a healthcare assistant. Summarise in 2-3 sentences."
User:   "Data: [structured results from Tools Layer]
         Question: Find me a cardiologist in Texas"
Gemma → "Dr. Alice Chen is a cardiologist based in Texas with NPI 1234567890..."
```

---

## Endpoints

| Endpoint | Description |
|---|---|
| `GET  :8000/` | Chat UI |
| `POST :8000/ask` | Submit a question |
| `GET  :8000/logs` | View audit log |
| `GET  :8001/health` | Agent layer health (shows model ID) |
| `GET  :8001/a2a/discover` | List all agents + their blueprints |
| `POST :8001/a2a/task` | Submit task directly to agent layer |
| `GET  :8002/registry` | List all tools |
| `GET  :8002/tools/lookup_provider?query=cardio` | Raw tool call |

---

## Project Structure

```
provider_agent_demo/
├── config/
│   └── config.yaml              ← AWS region, model ID, logging
├── shared/
│   ├── bedrock_gemma.py         ← Gemma 3 12B client (async + sync)
│   ├── config_loader.py         ← YAML config + env-var overrides
│   ├── models.py                ← A2AMessage, AgentBlueprint, ToolBlueprint
│   └── audit_log.py             ← Centralised audit logging
├── tools_layer/
│   └── tools_server.py          ← MCP Server (mock provider/facility data)
├── agent_layer/
│   └── agent_server.py          ← A2A Router + Gemma-powered agents
├── app_layer/
│   └── ssp_server.py            ← SSP Chat UI
└── scripts/
    ├── test_gemma.py            ← Pre-flight Bedrock connectivity test ← RUN FIRST
    └── run_all.py               ← Launches all three servers
```

---

## IAM Permissions Required

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["bedrock:InvokeModel", "bedrock:InvokeModelWithResponseStream"],
    "Resource": "arn:aws:bedrock:*::foundation-model/google.gemma-3-12b-it"
  }]
}
```

---

## Troubleshooting

| Error | Fix |
|---|---|
| `[AWS credentials not found]` | Set `AWS_ACCESS_KEY_ID` + `AWS_SECRET_ACCESS_KEY` |
| `[Access denied to google.gemma-3-12b-it]` | Enable model in Bedrock console → Model access |
| `[Bedrock error ValidationException]` | Check region — model may not be in your region |
| `Connection refused :8001` | Run `python scripts/run_all.py` first |
