# CVO Fallout Report Utility

Automated daily pipeline for processing CVO fallout Excel/CSV reports from S3,
categorising errors, maintaining a cumulative master workbook, and logging each
run via **AWS Bedrock (Google Gemma)** → **DynamoDB**.

---

## Architecture

```
S3 (daily report)
       │
       ▼
  [Step 1] Download latest CVO_Fallout_YYYYMMDD file
       │
  [Step 2] Sort A→Z by "Error Description"
       │
  [Step 3] Count records per distinct error category
       │
  [Step 4] Download master workbook from S3 (or create new)
       │
  [Steps 5–6] Update Legend sheet + per-error-type sheets
       │
  [Step 7] Upload updated master workbook back to S3
       │
  [Bedrock] Google Gemma generates AI run summary
       │
  [DynamoDB] Persist run metadata + AI summary
```

---

## Project Structure

```
cvo_utility/
├── config/
│   └── config.yaml          ← all settings (S3, logging, Bedrock, etc.)
├── src/
│   ├── __init__.py
│   ├── config_loader.py     ← YAML + env-var override loader
│   ├── logger.py            ← rotating file + console logger
│   ├── s3_handler.py        ← S3 download / upload
│   ├── report_processor.py  ← sort, categorise, build master workbook
│   └── bedrock_logger.py    ← Bedrock (Gemma) + DynamoDB DB logger
├── scripts/
│   ├── test_local.py        ← local end-to-end test (no AWS needed)
│   └── setup_dynamodb.py    ← one-time DynamoDB table creation
├── logs/                    ← auto-created; rotating log files here
├── main.py                  ← CLI entry point
└── requirements.txt
```

---

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure
Edit `config/config.yaml`:
```yaml
s3:
  bucket_name: "your-actual-bucket"
  daily_report_prefix: "reports/daily/"
  master_report_prefix: "reports/master/"

report:
  error_description_column: "Error Description"   # match your column name exactly
```

Or use environment variables (no code changes needed):
```bash
export CVO__S3__BUCKET_NAME=my-bucket
export CVO__AWS__REGION=us-west-2
```

### 3. (One-time) Create DynamoDB table
```bash
python scripts/setup_dynamodb.py
```

### 4. Run the daily pipeline
```bash
# Process today's report
python main.py

# Process a specific date
python main.py --date 20240115

# Use a local file (skip S3 download)
python main.py --local ./CVO_Fallout_20240115.xlsx

# Dry run — process but don't upload to S3
python main.py --dry-run

# Custom config
python main.py --config /etc/cvo/prod.yaml
```

---

## Master Workbook Structure

| Sheet Name | Contents |
|---|---|
| **Legend** | Cumulative error category counts + last-updated date (appended daily) |
| **INVALID_ACCOUNT_NUMBER** | All records of this error type across all runs |
| **DUPLICATE_RECORD** | All records of this error type across all runs |
| *(one sheet per error type)* | Appended daily |

---

## Logging

- **File**: `logs/cvo_utility.log` (rotating, 10 MB × 5 files)
- **Console**: enabled by default
- **Level**: set in `config.yaml` → `logging.level` (`DEBUG/INFO/WARNING/ERROR`)

Sample log output:
```
2024-01-15 09:00:01 | INFO     | cvo_utility.s3        | Downloaded daily report: s3://bucket/reports/daily/CVO_Fallout_20240115.xlsx
2024-01-15 09:00:02 | INFO     | cvo_utility.processor | Sorted 1423 records by 'Error Description'
2024-01-15 09:00:02 | INFO     | cvo_utility.processor | Found 8 distinct error categories
2024-01-15 09:00:04 | INFO     | cvo_utility.bedrock   | Bedrock AI summary generated successfully.
2024-01-15 09:00:04 | INFO     | cvo_utility.bedrock   | Run log persisted to DynamoDB table 'CVO_RunLogs'
```

---

## DB Logging (Bedrock + DynamoDB)

Each run logs:
| Field | Example |
|---|---|
| `run_id` | UUID |
| `run_date` | `2024-01-15T09:00:01` |
| `daily_file` | `CVO_Fallout_20240115.xlsx` |
| `total_records` | `1423` |
| `error_category_count` | `8` |
| `top_errors` | Top 5 error categories with counts |
| `status` | `SUCCESS` / `FAILED` |
| `ai_summary` | *AI-generated summary from Gemma* |

**Bedrock model**: `google.gemma-3-27b-it-v1:0`
Update `bedrock.model_id` in config when a new Gemma version is available.

---

## Configuration Reference

```yaml
aws:
  region: us-east-1
  access_key_id: ""           # leave blank → use IAM role
  secret_access_key: ""

s3:
  bucket_name: "your-bucket"
  daily_report_prefix: "reports/daily/"
  master_report_prefix: "reports/master/"
  master_filename: "CVO_Master_Report.xlsx"

report:
  error_description_column: "Error Description"
  daily_file_pattern: "CVO_Fallout_"
  daily_file_date_format: "%Y%m%d"
  local_temp_dir: "/tmp/cvo_reports"

legend:
  sheet_name: "Legend"
  error_desc_col_header: "Error Description"
  error_count_col_header: "Error Count"
  last_updated_col_header: "Last Updated"

logging:
  level: INFO
  log_dir: logs
  log_filename: cvo_utility.log
  max_bytes: 10485760
  backup_count: 5
  console: true

bedrock:
  enabled: true
  region: us-east-1
  model_id: "google.gemma-3-27b-it-v1:0"
  max_tokens: 512
  dynamodb:
    enabled: true
    table_name: "CVO_RunLogs"
    region: us-east-1
```

---

## Scheduling (cron example)

```cron
# Run every weekday at 6 AM
0 6 * * 1-5 cd /opt/cvo_utility && python main.py >> /var/log/cvo_cron.log 2>&1
```

---

## IAM Permissions Required

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:PutObject", "s3:ListBucket", "s3:HeadObject"],
      "Resource": ["arn:aws:s3:::your-bucket", "arn:aws:s3:::your-bucket/*"]
    },
    {
      "Effect": "Allow",
      "Action": ["bedrock:InvokeModel"],
      "Resource": "arn:aws:bedrock:*::foundation-model/google.gemma-3-27b-it-v1:0"
    },
    {
      "Effect": "Allow",
      "Action": ["dynamodb:PutItem", "dynamodb:CreateTable"],
      "Resource": "arn:aws:dynamodb:*:*:table/CVO_RunLogs"
    }
  ]
}
```
