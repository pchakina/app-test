#!/usr/bin/env python3
"""
scripts/test_local.py
──────────────────────
End-to-end local test: generates a synthetic daily CSV, runs the
full processing pipeline (skip S3 & Bedrock), and prints results.

Usage:
    python scripts/test_local.py
"""

import os
import sys
import tempfile
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
from src.config_loader import load_config
from src.logger import get_logger
from src.report_processor import ReportProcessor

# ── Generate synthetic daily report ──────────────────────────

SAMPLE_ERRORS = [
    "INVALID_ACCOUNT_NUMBER",
    "MISSING_REQUIRED_FIELD",
    "DUPLICATE_RECORD",
    "TIMEOUT_ERROR",
    "INVALID_ACCOUNT_NUMBER",
    "MISSING_REQUIRED_FIELD",
    "INVALID_ACCOUNT_NUMBER",
    "DOWNSTREAM_SERVICE_UNAVAILABLE",
    "DUPLICATE_RECORD",
    "MISSING_REQUIRED_FIELD",
    "INVALID_ROUTING_CODE",
    "TIMEOUT_ERROR",
    "INVALID_ACCOUNT_NUMBER",
    "INVALID_ROUTING_CODE",
    "MISSING_REQUIRED_FIELD",
]

def make_sample_df() -> pd.DataFrame:
    import random, string
    random.seed(42)
    rows = []
    for i, err in enumerate(SAMPLE_ERRORS):
        rows.append({
            "Record ID":          f"REC{i+1:04d}",
            "Account Number":     "".join(random.choices(string.digits, k=10)),
            "Transaction Date":   f"2024-01-{(i % 28) + 1:02d}",
            "Amount":             round(random.uniform(10, 5000), 2),
            "Error Description":  err,
            "Source System":      random.choice(["CRM", "BILLING", "ERP"]),
            "Region":             random.choice(["EAST", "WEST", "CENTRAL"]),
        })
    return pd.DataFrame(rows)


def run_test():
    cfg = load_config()
    # Override err column to match sample data
    cfg.setdefault("report", {})["error_description_column"] = "Error Description"

    logger = get_logger("cvo_test", cfg)
    logger.info("=== LOCAL TEST RUN ===")

    processor = ReportProcessor(cfg)

    with tempfile.TemporaryDirectory() as tmpdir:
        # Write sample daily CSV
        daily_path = os.path.join(tmpdir, "CVO_Fallout_20240115.csv")
        make_sample_df().to_csv(daily_path, index=False)
        logger.info("Created sample daily file: %s", daily_path)

        # Step 2
        df_sorted = processor.load_and_sort(daily_path)
        logger.info("Sorted %d records", len(df_sorted))
        print("\n── Sorted Sample (first 5) ──")
        print(df_sorted[["Record ID", "Error Description"]].head().to_string(index=False))

        # Step 3
        error_summary = processor.get_error_summary(df_sorted)
        print("\n── Error Summary ──")
        print(error_summary.to_string(index=False))

        # Steps 4–6
        master_path = os.path.join(tmpdir, "CVO_Master_Report.xlsx")
        processor.update_master_workbook(
            master_path=master_path,
            df_sorted=df_sorted,
            error_summary=error_summary,
            run_date=datetime(2024, 1, 15),
        )

        # Load & verify
        from openpyxl import load_workbook
        wb = load_workbook(master_path)
        print(f"\n── Master Workbook Sheets ({len(wb.sheetnames)}) ──")
        for name in wb.sheetnames:
            ws = wb[name]
            print(f"  {name:<35} rows={ws.max_row}")

        logger.info("LOCAL TEST PASSED ✓")
        print(f"\nMaster workbook written to: {master_path}")
        print("LOCAL TEST PASSED ✓")


if __name__ == "__main__":
    run_test()
