#!/usr/bin/env python3
"""
scripts/setup_dynamodb.py
──────────────────────────
One-time script to create the DynamoDB table for CVO run logs.

Usage:
    python scripts/setup_dynamodb.py
    python scripts/setup_dynamodb.py --config /path/to/config.yaml
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import boto3
from botocore.exceptions import ClientError
from src.config_loader import load_config
from src.logger import get_logger


def create_table(cfg: dict) -> None:
    logger = get_logger("cvo_utility.setup", cfg)

    bedrock_cfg = cfg.get("bedrock", {})
    ddb_cfg = bedrock_cfg.get("dynamodb", {})
    table_name = ddb_cfg.get("table_name", "CVO_RunLogs")
    region = ddb_cfg.get("region", cfg.get("aws", {}).get("region", "us-east-1"))

    aws_cfg = cfg.get("aws", {})
    session_kwargs: dict = {"region_name": region}
    if aws_cfg.get("access_key_id"):
        session_kwargs["aws_access_key_id"] = aws_cfg["access_key_id"]
    if aws_cfg.get("secret_access_key"):
        session_kwargs["aws_secret_access_key"] = aws_cfg["secret_access_key"]

    ddb = boto3.client("dynamodb", **session_kwargs)

    try:
        ddb.create_table(
            TableName=table_name,
            KeySchema=[
                {"AttributeName": "run_id",   "KeyType": "HASH"},
                {"AttributeName": "run_date",  "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "run_id",  "AttributeType": "S"},
                {"AttributeName": "run_date", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
            Tags=[
                {"Key": "Application", "Value": "CVO-Fallout-Utility"},
                {"Key": "ManagedBy",   "Value": "cvo_utility_setup_script"},
            ],
        )
        logger.info("DynamoDB table '%s' created successfully in %s.", table_name, region)

    except ClientError as e:
        if e.response["Error"]["Code"] == "ResourceInUseException":
            logger.info("Table '%s' already exists — nothing to do.", table_name)
        else:
            logger.error("Failed to create DynamoDB table: %s", e)
            raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None)
    args = parser.parse_args()
    cfg = load_config(args.config)
    create_table(cfg)
