"""
cvo_utility/src/report_processor.py
─────────────────────────────────────
Steps 2–6: Sort, categorise, build Legend, write per-error sheets.
"""

import os
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

import pandas as pd
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from .logger import get_logger


# ── Colour palette ────────────────────────────────────────────
HEADER_FILL   = PatternFill("solid", start_color="1F3864")  # Dark navy
SUBHEAD_FILL  = PatternFill("solid", start_color="2E75B6")  # Blue
ALT_ROW_FILL  = PatternFill("solid", start_color="D9E1F2")  # Light blue
WHITE_FILL    = PatternFill("solid", start_color="FFFFFF")
HEADER_FONT   = Font(bold=True, color="FFFFFF", name="Calibri", size=11)
BODY_FONT     = Font(name="Calibri", size=10)
CENTER_ALIGN  = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT_ALIGN    = Alignment(horizontal="left",   vertical="center", wrap_text=True)

THIN_BORDER = Border(
    left=Side(style="thin"), right=Side(style="thin"),
    top=Side(style="thin"),  bottom=Side(style="thin"),
)


def _sanitise_sheet_name(name: str) -> str:
    """Excel sheet names: max 31 chars, no special chars."""
    clean = re.sub(r'[\\/*?:\[\]]', "_", str(name))
    return clean[:31]


def _style_header_row(ws, row: int, col_count: int, fill=HEADER_FILL):
    for col in range(1, col_count + 1):
        cell = ws.cell(row=row, column=col)
        cell.fill = fill
        cell.font = HEADER_FONT
        cell.alignment = CENTER_ALIGN
        cell.border = THIN_BORDER


def _style_data_rows(ws, start_row: int, end_row: int, col_count: int):
    for row in range(start_row, end_row + 1):
        fill = ALT_ROW_FILL if row % 2 == 0 else WHITE_FILL
        for col in range(1, col_count + 1):
            cell = ws.cell(row=row, column=col)
            cell.fill = fill
            cell.font = BODY_FONT
            cell.alignment = LEFT_ALIGN
            cell.border = THIN_BORDER


def _auto_column_width(ws):
    for col in ws.columns:
        max_len = max((len(str(c.value)) if c.value else 0) for c in col)
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(max_len + 4, 60)


class ReportProcessor:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.logger = get_logger("cvo_utility.processor", cfg)
        self.err_col = cfg.get("report", {}).get("error_description_column", "Error Description")
        self.legend_cfg = cfg.get("legend", {})

    # ── Step 2: Sort ──────────────────────────────────────────

    def load_and_sort(self, file_path: str) -> pd.DataFrame:
        self.logger.info("Loading daily report: %s", file_path)
        ext = Path(file_path).suffix.lower()
        if ext in (".xlsx", ".xls"):
            df = pd.read_excel(file_path)
        else:
            df = pd.read_csv(file_path)

        if self.err_col not in df.columns:
            raise ValueError(
                f"Column '{self.err_col}' not found. Available: {list(df.columns)}"
            )

        df_sorted = df.sort_values(by=self.err_col, ascending=True, na_position="last")
        df_sorted.reset_index(drop=True, inplace=True)
        self.logger.info("Sorted %d records by '%s'", len(df_sorted), self.err_col)
        return df_sorted

    # ── Step 3: Count by error category ──────────────────────

    def get_error_summary(self, df: pd.DataFrame) -> pd.DataFrame:
        summary = (
            df.groupby(self.err_col, dropna=False)
            .size()
            .reset_index(name="Error Count")
        )
        summary.rename(columns={self.err_col: "Error Description"}, inplace=True)
        summary.sort_values("Error Description", inplace=True)
        summary.reset_index(drop=True, inplace=True)
        self.logger.info("Found %d distinct error categories", len(summary))
        return summary

    # ── Steps 4 & 7: Update Legend + per-error sheets ─────────

    def update_master_workbook(
        self,
        master_path: str,
        df_sorted: pd.DataFrame,
        error_summary: pd.DataFrame,
        run_date: Optional[datetime] = None,
    ) -> str:
        run_date = run_date or datetime.now()
        date_label = run_date.strftime("%Y-%m-%d")

        master_path = str(master_path)

        if os.path.exists(master_path):
            wb = load_workbook(master_path)
            self.logger.info("Opened existing master workbook: %s", master_path)
        else:
            wb = Workbook()
            # Remove default empty sheet
            if "Sheet" in wb.sheetnames:
                del wb["Sheet"]
            self.logger.info("Creating new master workbook: %s", master_path)

        # ── Legend sheet (step 4) ──────────────────────────────
        self._update_legend(wb, error_summary, date_label)

        # ── Per-error sheets (steps 5 & 6) ────────────────────
        self._update_category_sheets(wb, df_sorted, date_label)

        wb.save(master_path)
        self.logger.info("Master workbook saved: %s", master_path)
        return master_path

    # ── Legend ────────────────────────────────────────────────

    def _update_legend(self, wb: Workbook, error_summary: pd.DataFrame, date_label: str):
        legend_name = self.legend_cfg.get("sheet_name", "Legend")
        desc_hdr = self.legend_cfg.get("error_desc_col_header", "Error Description")
        cnt_hdr  = self.legend_cfg.get("error_count_col_header", "Error Count")
        upd_hdr  = self.legend_cfg.get("last_updated_col_header", "Last Updated")

        if legend_name in wb.sheetnames:
            ws = wb[legend_name]
            self.logger.info("Appending to existing Legend sheet")

            # Find next empty row (skip header)
            next_row = ws.max_row + 1
            for _, row_data in error_summary.iterrows():
                ws.cell(next_row, 1).value = row_data["Error Description"]
                ws.cell(next_row, 2).value = row_data["Error Count"]
                ws.cell(next_row, 3).value = date_label
                next_row += 1

            _style_data_rows(ws, 2, ws.max_row, 3)

        else:
            ws = wb.create_sheet(legend_name, 0)  # insert at front
            # Header
            for col, hdr in enumerate([desc_hdr, cnt_hdr, upd_hdr], start=1):
                ws.cell(1, col).value = hdr
            _style_header_row(ws, 1, 3)

            # Data
            for i, (_, row_data) in enumerate(error_summary.iterrows(), start=2):
                ws.cell(i, 1).value = row_data["Error Description"]
                ws.cell(i, 2).value = row_data["Error Count"]
                ws.cell(i, 3).value = date_label

            _style_data_rows(ws, 2, ws.max_row, 3)
            ws.freeze_panes = "A2"
            ws.row_dimensions[1].height = 20

        _auto_column_width(ws)
        self.logger.info("Legend sheet updated with %d error categories", len(error_summary))

    # ── Per-error category sheets ─────────────────────────────

    def _update_category_sheets(self, wb: Workbook, df_sorted: pd.DataFrame, date_label: str):
        columns = list(df_sorted.columns)
        col_count = len(columns)

        for err_desc, group_df in df_sorted.groupby(self.err_col, dropna=False):
            sheet_name = _sanitise_sheet_name(str(err_desc))

            if sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                # Append rows below existing data
                start_row = ws.max_row + 1
                for _, row_data in group_df.iterrows():
                    ws.append([row_data[c] if pd.notna(row_data[c]) else "" for c in columns])
                _style_data_rows(ws, start_row, ws.max_row, col_count)
                self.logger.debug("Appended %d rows to sheet '%s'", len(group_df), sheet_name)

            else:
                ws = wb.create_sheet(sheet_name)
                # Header
                for col_idx, hdr in enumerate(columns, start=1):
                    ws.cell(1, col_idx).value = hdr
                _style_header_row(ws, 1, col_count)

                # Data
                for r_idx, (_, row_data) in enumerate(group_df.iterrows(), start=2):
                    for c_idx, col_name in enumerate(columns, start=1):
                        val = row_data[col_name]
                        ws.cell(r_idx, c_idx).value = val if pd.notna(val) else ""

                _style_data_rows(ws, 2, ws.max_row, col_count)
                ws.freeze_panes = "A2"
                ws.row_dimensions[1].height = 20
                self.logger.info("Created sheet '%s' with %d records", sheet_name, len(group_df))

            _auto_column_width(ws)
