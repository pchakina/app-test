"""
cvo_utility/src/bedrock_logger.py
───────────────────────────────────
Uses AWS Bedrock (Google Gemma model) to generate an AI-enriched
run summary, then persists it to DynamoDB.
"""

import json
import uuid
from datetime import datetime
from typing import Optional

import boto3
from botocore.exceptions import ClientError

from .logger import get_logger


class BedrockDBLogger:
    """
    Logs CVO run metadata + AI-generated summary to DynamoDB via Bedrock.
    All operations are best-effort: failures log a warning but never
    crash the main pipeline.
    """

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.logger = get_logger("cvo_utility.bedrock", cfg)

        bedrock_cfg = cfg.get("bedrock", {})
        self.enabled = bedrock_cfg.get("enabled", False)
        if not self.enabled:
            self.logger.info("Bedrock DB logging is disabled in config.")
            return

        aws_cfg = cfg.get("aws", {})
        region = bedrock_cfg.get("region", aws_cfg.get("region", "us-east-1"))
        self.model_id = bedrock_cfg.get("model_id", "google.gemma-3-27b-it-v1:0")
        self.max_tokens = bedrock_cfg.get("max_tokens", 512)

        session_kwargs: dict = {"region_name": region}
        if aws_cfg.get("access_key_id"):
            session_kwargs["aws_access_key_id"] = aws_cfg["access_key_id"]
        if aws_cfg.get("secret_access_key"):
            session_kwargs["aws_secret_access_key"] = aws_cfg["secret_access_key"]

        self.session = boto3.Session(**session_kwargs)
        self.bedrock = self.session.client("bedrock-runtime")

        # DynamoDB
        ddb_cfg = bedrock_cfg.get("dynamodb", {})
        self.ddb_enabled = ddb_cfg.get("enabled", True)
        if self.ddb_enabled:
            ddb_region = ddb_cfg.get("region", region)
            self.table_name = ddb_cfg.get("table_name", "CVO_RunLogs")
            ddb_session = boto3.Session(region_name=ddb_region, **{
                k: v for k, v in {
                    "aws_access_key_id": aws_cfg.get("access_key_id"),
                    "aws_secret_access_key": aws_cfg.get("secret_access_key"),
                }.items() if v
            })
            self.ddb = ddb_session.resource("dynamodb")
            self.table = self.ddb.Table(self.table_name)

    # ── Public API ────────────────────────────────────────────

    def log_run(
        self,
        run_date: datetime,
        daily_file: str,
        total_records: int,
        error_categories: list[dict],
        status: str = "SUCCESS",
        error_message: Optional[str] = None,
    ) -> None:
        if not self.enabled:
            return

        run_meta = {
            "run_date": run_date.isoformat(),
            "daily_file": daily_file,
            "total_records": total_records,
            "error_category_count": len(error_categories),
            "top_errors": error_categories[:5],
            "status": status,
            "error_message": error_message or "",
        }

        self.logger.info("Requesting AI run summary from Bedrock (%s)...", self.model_id)
        ai_summary = self._generate_summary(run_meta)
        run_meta["ai_summary"] = ai_summary

        if self.ddb_enabled:
            self._persist_to_dynamodb(run_meta)

    # ── Bedrock Inference ─────────────────────────────────────

    def _generate_summary(self, run_meta: dict) -> str:
        prompt = (
            "You are a data quality analyst. Summarise the following CVO fallout "
            "report processing run in 3–4 concise sentences. Highlight total records, "
            "dominant error categories, and any concerns.\n\n"
            f"Run metadata:\n{json.dumps(run_meta, indent=2, default=str)}"
        )

        # Gemma uses the Converse API or InvokeModel with specific body
        body = json.dumps({
            "prompt": f"<start_of_turn>user\n{prompt}<end_of_turn>\n<start_of_turn>model\n",
            "max_new_tokens": self.max_tokens,
            "temperature": 0.3,
        })

        try:
            resp = self.bedrock.invoke_model(
                modelId=self.model_id,
                body=body,
                contentType="application/json",
                accept="application/json",
            )
            result = json.loads(resp["body"].read())
            # Gemma response key varies; handle both
            summary = (
                result.get("generated_text")
                or result.get("outputs", [{}])[0].get("outputText", "")
                or str(result)
            )
            self.logger.info("Bedrock AI summary generated successfully.")
            return summary.strip()

        except ClientError as e:
            self.logger.warning("Bedrock call failed: %s", e)
            return f"[AI summary unavailable: {e}]"
        except Exception as e:
            self.logger.warning("Unexpected Bedrock error: %s", e)
            return f"[AI summary unavailable: {e}]"

    # ── DynamoDB Persistence ──────────────────────────────────

    def _persist_to_dynamodb(self, record: dict) -> None:
        item = {
            "run_id": str(uuid.uuid4()),
            "run_date": record["run_date"],
            "daily_file": record["daily_file"],
            "total_records": record["total_records"],
            "error_category_count": record["error_category_count"],
            "top_errors": json.dumps(record["top_errors"], default=str),
            "status": record["status"],
            "error_message": record["error_message"],
            "ai_summary": record.get("ai_summary", ""),
            "created_at": datetime.utcnow().isoformat(),
        }

        try:
            self.table.put_item(Item=item)
            self.logger.info(
                "Run log persisted to DynamoDB table '%s' (run_id=%s)",
                self.table_name, item["run_id"],
            )
        except ClientError as e:
            self.logger.warning("DynamoDB write failed: %s", e)
        except Exception as e:
            self.logger.warning("Unexpected DynamoDB error: %s", e)
