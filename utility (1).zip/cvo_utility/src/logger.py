"""
cvo_utility/src/logger.py
─────────────────────────
Centralised logging setup.
Supports rotating file handler + optional console output.
"""

import logging
import os
from logging.handlers import RotatingFileHandler
from typing import Optional


_initialized: dict[str, logging.Logger] = {}


def get_logger(name: str = "cvo_utility", cfg: Optional[dict] = None) -> logging.Logger:
    """
    Return (and cache) a logger with the given name.
    First call uses *cfg* to configure handlers; subsequent calls
    return the same logger regardless of cfg.
    """
    if name in _initialized:
        return _initialized[name]

    log_cfg = (cfg or {}).get("logging", {})
    level_str = log_cfg.get("level", "INFO").upper()
    level = getattr(logging, level_str, logging.INFO)

    log_dir = log_cfg.get("log_dir", "logs")
    log_filename = log_cfg.get("log_filename", "cvo_utility.log")
    max_bytes = log_cfg.get("max_bytes", 10 * 1024 * 1024)
    backup_count = log_cfg.get("backup_count", 5)
    console = log_cfg.get("console", True)

    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, log_filename)

    fmt = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.propagate = False

    # Rotating file handler
    fh = RotatingFileHandler(log_path, maxBytes=max_bytes, backupCount=backup_count)
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    # Console handler
    if console:
        ch = logging.StreamHandler()
        ch.setFormatter(fmt)
        logger.addHandler(ch)

    _initialized[name] = logger
    logger.info("Logger initialised. Log file: %s | Level: %s", log_path, level_str)
    return logger
