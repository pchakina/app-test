"""
cvo_utility/src/s3_handler.py
──────────────────────────────
All S3 interactions: download latest daily report, check / upload master.
"""

import os
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import boto3
from botocore.exceptions import ClientError

from .logger import get_logger


class S3Handler:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.logger = get_logger("cvo_utility.s3", cfg)

        aws_cfg = cfg.get("aws", {})
        s3_cfg = cfg.get("s3", {})

        session_kwargs: dict = {"region_name": aws_cfg.get("region", "us-east-1")}
        if aws_cfg.get("access_key_id"):
            session_kwargs["aws_access_key_id"] = aws_cfg["access_key_id"]
        if aws_cfg.get("secret_access_key"):
            session_kwargs["aws_secret_access_key"] = aws_cfg["secret_access_key"]

        self.session = boto3.Session(**session_kwargs)
        self.s3 = self.session.client("s3")
        self.bucket = s3_cfg["bucket_name"]
        self.daily_prefix = s3_cfg.get("daily_report_prefix", "reports/daily/")
        self.master_prefix = s3_cfg.get("master_report_prefix", "reports/master/")
        self.master_filename = s3_cfg.get("master_filename", "CVO_Master_Report.xlsx")

        local_temp = cfg.get("report", {}).get("local_temp_dir", "/tmp/cvo_reports")
        os.makedirs(local_temp, exist_ok=True)
        self.local_temp = local_temp

    # ── Daily Report ──────────────────────────────────────────

    def get_latest_daily_report(self, target_date: Optional[datetime] = None) -> str:
        """
        Find and download the latest daily CVO report from S3.
        Tries today first, then yesterday (to handle early-morning runs).
        Returns local file path.
        """
        pattern = self.cfg.get("report", {}).get("daily_file_pattern", "CVO_Fallout_")
        date_fmt = self.cfg.get("report", {}).get("daily_file_date_format", "%Y%m%d")

        dates_to_try = []
        if target_date:
            dates_to_try = [target_date]
        else:
            today = datetime.now()
            dates_to_try = [today, today - timedelta(days=1)]

        for dt in dates_to_try:
            date_str = dt.strftime(date_fmt)
            key = self._find_key_by_date_and_pattern(pattern, date_str)
            if key:
                local_path = os.path.join(self.local_temp, Path(key).name)
                self._download(key, local_path)
                self.logger.info("Downloaded daily report: s3://%s/%s → %s", self.bucket, key, local_path)
                return local_path

        raise FileNotFoundError(
            f"No daily CVO report found in s3://{self.bucket}/{self.daily_prefix} "
            f"for dates {[d.strftime(date_fmt) for d in dates_to_try]}"
        )

    def _find_key_by_date_and_pattern(self, pattern: str, date_str: str) -> Optional[str]:
        """List objects in daily prefix and return key matching pattern+date."""
        resp = self.s3.list_objects_v2(Bucket=self.bucket, Prefix=self.daily_prefix)
        for obj in resp.get("Contents", []):
            key = obj["Key"]
            fname = Path(key).name
            if pattern in fname and date_str in fname:
                return key
        return None

    # ── Master Report ─────────────────────────────────────────

    def master_exists(self) -> bool:
        key = self.master_prefix + self.master_filename
        try:
            self.s3.head_object(Bucket=self.bucket, Key=key)
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] == "404":
                return False
            raise

    def download_master(self) -> str:
        key = self.master_prefix + self.master_filename
        local_path = os.path.join(self.local_temp, self.master_filename)
        self._download(key, local_path)
        self.logger.info("Downloaded master: s3://%s/%s → %s", self.bucket, key, local_path)
        return local_path

    def upload_master(self, local_path: str) -> None:
        key = self.master_prefix + self.master_filename
        self._upload(local_path, key)
        self.logger.info("Uploaded master: %s → s3://%s/%s", local_path, self.bucket, key)

    # ── Helpers ───────────────────────────────────────────────

    def _download(self, key: str, local_path: str) -> None:
        self.s3.download_file(self.bucket, key, local_path)

    def _upload(self, local_path: str, key: str) -> None:
        self.s3.upload_file(local_path, self.bucket, key)
