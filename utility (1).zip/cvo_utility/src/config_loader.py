"""
cvo_utility/src/config_loader.py
─────────────────────────────────
Loads YAML config with env-variable overrides.
Environment variables follow the pattern:  CVO__SECTION__KEY
e.g.  CVO__S3__BUCKET_NAME overrides  s3.bucket_name
"""

import os
import yaml
from pathlib import Path
from typing import Any


_DEFAULT_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "config.yaml"


def _deep_merge(base: dict, override: dict) -> dict:
    result = base.copy()
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(result.get(k), dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def _apply_env_overrides(cfg: dict) -> dict:
    """
    Walk all env vars prefixed with CVO__ and inject them into cfg.
    Example: CVO__S3__BUCKET_NAME=my-bucket  →  cfg['s3']['bucket_name'] = 'my-bucket'
    """
    prefix = "CVO__"
    for key, value in os.environ.items():
        if not key.startswith(prefix):
            continue
        parts = key[len(prefix):].lower().split("__")
        node = cfg
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        leaf = parts[-1]
        # Attempt numeric / bool coercion
        if value.lower() in ("true", "false"):
            node[leaf] = value.lower() == "true"
        else:
            try:
                node[leaf] = int(value)
            except ValueError:
                try:
                    node[leaf] = float(value)
                except ValueError:
                    node[leaf] = value
    return cfg


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    config_path = Path(path) if path else _DEFAULT_CONFIG_PATH

    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(config_path, "r") as f:
        cfg = yaml.safe_load(f) or {}

    cfg = _apply_env_overrides(cfg)
    return cfg
