#!/usr/bin/env python3
"""
cvo_utility/main.py
────────────────────
Orchestrator: ties together S3, Excel processing, and Bedrock DB logging.

Usage:
    python main.py                          # process today's report
    python main.py --date 20240115          # process specific date
    python main.py --config /path/cfg.yaml  # custom config
    python main.py --local ./daily.xlsx     # use a local file (skip S3 download)
    python main.py --dry-run                # process but do NOT upload back to S3
"""

import argparse
import sys
import traceback
from datetime import datetime
from pathlib import Path

# Allow running from project root
sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.config_loader import load_config
from src.logger import get_logger
from src.s3_handler import S3Handler
from src.report_processor import ReportProcessor
from src.bedrock_logger import BedrockDBLogger


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="CVO Fallout Report Daily Utility")
    parser.add_argument("--config", default=None, help="Path to config YAML (default: config/config.yaml)")
    parser.add_argument("--date", default=None, help="Target date YYYYMMDD (default: today)")
    parser.add_argument("--local", default=None, help="Use a local file instead of downloading from S3")
    parser.add_argument("--dry-run", action="store_true", help="Do not upload master back to S3")
    return parser.parse_args()


def main():
    args = parse_args()

    # ── Config ────────────────────────────────────────────────
    cfg = load_config(args.config)
    logger = get_logger("cvo_utility", cfg)
    logger.info("=" * 60)
    logger.info("CVO Fallout Report Utility — Run Started")
    logger.info("=" * 60)

    # Parse target date
    run_date = datetime.now()
    if args.date:
        try:
            run_date = datetime.strptime(args.date, "%Y%m%d")
        except ValueError:
            logger.error("Invalid --date format. Use YYYYMMDD. Got: %s", args.date)
            sys.exit(1)

    logger.info("Target date: %s | Dry-run: %s", run_date.strftime("%Y-%m-%d"), args.dry_run)

    # ── Initialise components ─────────────────────────────────
    s3 = S3Handler(cfg)
    processor = ReportProcessor(cfg)
    db_logger = BedrockDBLogger(cfg)

    status = "SUCCESS"
    error_message = None
    total_records = 0
    error_categories = []

    try:
        # ── Step 1: Pull daily report ─────────────────────────
        if args.local:
            daily_file = args.local
            logger.info("Using local file: %s", daily_file)
        else:
            logger.info("Downloading latest daily CVO report from S3...")
            daily_file = s3.get_latest_daily_report(target_date=run_date)

        # ── Step 2: Sort by Error Description ────────────────
        logger.info("Step 2: Sorting daily report...")
        df_sorted = processor.load_and_sort(daily_file)
        total_records = len(df_sorted)
        logger.info("Total records in daily report: %d", total_records)

        # ── Step 3: Error category summary ───────────────────
        logger.info("Step 3: Computing error category summary...")
        error_summary = processor.get_error_summary(df_sorted)
        error_categories = error_summary.to_dict("records")
        for row in error_categories:
            logger.info("  %-60s → %d records", row["Error Description"], row["Error Count"])

        # ── Steps 4–7: Update / create master workbook ───────
        import os
        local_temp = cfg.get("report", {}).get("local_temp_dir", "/tmp/cvo_reports")
        master_filename = cfg.get("s3", {}).get("master_filename", "CVO_Master_Report.xlsx")
        local_master_path = os.path.join(local_temp, master_filename)

        if not args.local and s3.master_exists():
            logger.info("Step 4: Downloading existing master workbook from S3...")
            local_master_path = s3.download_master()
        else:
            logger.info("Step 4: Master workbook not found in S3 — will create new.")

        logger.info("Steps 4–6: Updating Legend + category sheets in master workbook...")
        processor.update_master_workbook(
            master_path=local_master_path,
            df_sorted=df_sorted,
            error_summary=error_summary,
            run_date=run_date,
        )

        # ── Step 7: Upload master back to S3 ─────────────────
        if not args.dry_run and not args.local:
            logger.info("Step 7: Uploading updated master workbook to S3...")
            s3.upload_master(local_master_path)
        else:
            logger.info("Skipping S3 upload (dry-run or local mode). File at: %s", local_master_path)

    except FileNotFoundError as e:
        status = "FAILED"
        error_message = str(e)
        logger.error("File not found: %s", e)
        sys.exit(1)

    except Exception as e:
        status = "FAILED"
        error_message = str(e)
        logger.error("Unexpected error: %s\n%s", e, traceback.format_exc())
        sys.exit(1)

    finally:
        # ── DB Logging via Bedrock ────────────────────────────
        logger.info("Logging run metadata via Bedrock → DynamoDB...")
        try:
            db_logger.log_run(
                run_date=run_date,
                daily_file=str(daily_file if 'daily_file' in dir() else "unknown"),
                total_records=total_records,
                error_categories=error_categories,
                status=status,
                error_message=error_message,
            )
        except Exception as e:
            logger.warning("Bedrock/DynamoDB logging failed (non-fatal): %s", e)

        logger.info("=" * 60)
        logger.info("Run completed with status: %s", status)
        logger.info("=" * 60)


if __name__ == "__main__":
    main()
