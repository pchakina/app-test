# Healthcare Schema Mapper — OOD Architecture

## Project Structure

```
healthcare-mapper-ood/
│
├── main.py                          # FastAPI app entry point
├── requirements.txt                 # All dependencies
├── .env.example                     # Environment variable template
│
└── app/
    ├── core/                        # Infrastructure / cross-cutting concerns
    │   ├── config.py                # AppConfig  — all env vars in one place
    │   ├── logging.py               # LoggerFactory — structured logging
    │   ├── exceptions.py            # Domain exception hierarchy
    │   └── dependencies.py          # FastAPI dependency injection wiring
    │
    ├── models/                      # Pure data models (Pydantic)
    │   ├── provider.py              # ProviderCategory, SourceRow, FileMeta
    │   ├── mapping.py               # MappingRecord, MappingSummary, MappingResult
    │   └── schema.py                # DestinationField, DestinationSchema
    │
    ├── repositories/                # Data access — S3 read/write
    │   ├── base.py                  # BaseRepository — abstract S3 helpers
    │   ├── schema_repository.py     # SchemaRepository — dest schema CRUD
    │   ├── source_repository.py     # SourceRepository — source file read + split
    │   ├── config_repository.py     # ConfigRepository — prompt config YAML
    │   └── output_repository.py     # OutputRepository — save JSON/Excel/HTML
    │
    ├── services/                    # Business logic — pure Python, no AWS coupling
    │   ├── prompt_builder.py        # PromptBuilder — builds LLM messages
    │   ├── bedrock_client.py        # BedrockClient — LLM call + response parse
    │   ├── mapping_summariser.py    # MappingSummariser — coverage stats
    │   ├── output_writer.py         # OutputWriter — orchestrates all 3 formats
    │   └── mapping_pipeline.py      # MappingPipeline — orchestrates full run
    │
    ├── utils/                       # Stateless helpers
    │   ├── excel_builder.py         # ExcelBuilder — openpyxl workbook logic
    │   └── verification.py          # VerificationEngine — config health checks
    │
    └── api/                         # FastAPI routers
        ├── routes/
        │   ├── health.py            # GET  /health
        │   ├── sources.py           # POST /sources/validate
        │   ├── schemas.py           # GET  /schemas, GET /schemas/{category}
        │   ├── mappings.py          # POST /mappings/run, GET /mappings/{id}
        │   └── verification.py      # POST /verify/{category}
        └── router.py                # Registers all routers
```

## Class Responsibility Map

| Class | Layer | Responsibility |
|---|---|---|
| `AppConfig` | core | Single source of truth for all env vars |
| `LoggerFactory` | core | Named structured loggers |
| `BaseRepository` | repository | S3 client, read_bytes/text/json/put helpers |
| `SchemaRepository` | repository | Load destination schemas by category |
| `SourceRepository` | repository | Read source file, split rows by category |
| `ConfigRepository` | repository | Load + cache prompt_config.yaml |
| `OutputRepository` | repository | Save JSON, Excel, HTML outputs to S3 |
| `PromptBuilder` | service | Build OpenAI-compatible message lists |
| `BedrockClient` | service | Call Bedrock converse, parse JSON response |
| `MappingSummariser` | service | Compute coverage summary from mappings |
| `OutputWriter` | service | Coordinate OutputRepository for all 3 formats |
| `MappingPipeline` | service | Orchestrate full multi-category ETL run |
| `ExcelBuilder` | util | Build openpyxl workbook from mapping records |
| `VerificationEngine` | util | Run health checks on a template config |

## REST API Endpoints

| Method | Path | Description |
|---|---|---|
| GET | /health | Liveness + dependency check |
| GET | /schemas | List all available category schemas |
| GET | /schemas/{category} | Get full destination schema for a category |
| POST | /sources/validate | Upload + validate a source file (detect headers, categories) |
| POST | /mappings/run | Trigger a full multi-category mapping run |
| POST | /mappings/run/{category} | Trigger mapping for one category only |
| GET | /mappings/{run_id} | Get combined result for a completed run |
| GET | /mappings/{run_id}/{category} | Get per-category result |
| GET | /mappings/{run_id}/{category}/download/{format} | Download json/excel/html output |
| POST | /verify/{category} | Run verification health checks on a template config |
