"""
app/api/router.py
──────────────────
Central router registry.
Import and include all sub-routers here so main.py stays clean.
"""

from fastapi import APIRouter

from app.api.routes.health       import router as health_router
from app.api.routes.schemas      import router as schemas_router
from app.api.routes.sources      import router as sources_router
from app.api.routes.mappings     import router as mappings_router
from app.api.routes.verification import router as verification_router

api_router = APIRouter(prefix="/api/v1")

api_router.include_router(health_router)
api_router.include_router(schemas_router)
api_router.include_router(sources_router)
api_router.include_router(mappings_router)
api_router.include_router(verification_router)
