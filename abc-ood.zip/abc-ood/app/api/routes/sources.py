"""
app/api/routes/sources.py
──────────────────────────
Source file validation endpoints.

POST /sources/validate → detect headers and categories in a source file
GET  /sources/headers  → list headers for a given source S3 key
"""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException

from app.core.dependencies import get_source_repository
from app.core.exceptions import SourceFileError, CategoryColumnMissingError
from app.models.provider import ValidateSourceRequest, ValidateSourceResponse
from app.repositories.source_repository import SourceRepository

router = APIRouter(prefix="/sources", tags=["Sources"])


@router.post(
    "/validate",
    response_model=ValidateSourceResponse,
    summary="Validate a source file",
    description="Reads the source file from S3, detects headers, "
                "identifies the category column, and returns the unique "
                "provider categories found. Use before triggering a mapping run "
                "to confirm the file is structured correctly.",
)
def validate_source(
    request: ValidateSourceRequest,
    repo:    Annotated[SourceRepository, Depends(get_source_repository)],
) -> ValidateSourceResponse:
    try:
        split = repo.split_by_category(
            source_key      = request.source_key,
            category_column = request.category_column,
        )
    except (SourceFileError, CategoryColumnMissingError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    return ValidateSourceResponse(
        source_key       = request.source_key,
        file_meta        = split.file_meta,
        categories_found = split.categories_found,
        column_count     = len(split.headers),
        headers          = split.headers,
    )


@router.get(
    "/headers",
    summary="Get column headers for a source file",
    description="Returns the raw column headers detected in the source file "
                "(without category splitting). Useful for schema design.",
)
def get_headers(
    source_key: str,
    repo:       Annotated[SourceRepository, Depends(get_source_repository)],
) -> dict:
    try:
        headers, file_meta = repo.get_headers(source_key)
    except SourceFileError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    return {
        "source_key":   source_key,
        "column_count": len(headers),
        "file_meta":    file_meta.model_dump(),
        "headers":      headers,
    }
