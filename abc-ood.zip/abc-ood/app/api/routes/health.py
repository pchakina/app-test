"""
app/api/routes/health.py
─────────────────────────
GET /health — liveness and dependency check.
"""

from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends

from app.core.config import AppConfig, get_config

router = APIRouter(tags=["System"])


@router.get(
    "/health",
    summary="Health check",
    description="Returns service status, version, and timestamp. "
                "Use for liveness probes and dependency verification.",
)
def health_check(cfg: Annotated[AppConfig, Depends(get_config)]) -> dict:
    return {
        "status":      "ok",
        "service":     cfg.app_title,
        "version":     cfg.app_version,
        "timestamp":   datetime.now().isoformat(),
        "region":      cfg.aws_region,
        "source_bucket": cfg.source_bucket,
        "output_bucket": cfg.output_bucket,
    }
