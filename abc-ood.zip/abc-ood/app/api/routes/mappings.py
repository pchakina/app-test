"""
app/api/routes/mappings.py
───────────────────────────
Mapping run endpoints.

POST /mappings/run              → trigger full multi-category mapping run
POST /mappings/run/{category}   → trigger single-category mapping run
GET  /mappings/{run_id}         → retrieve combined run result JSON from S3
GET  /mappings/{run_id}/{category}             → retrieve per-category result
GET  /mappings/{run_id}/{category}/download/{fmt} → download json | excel | html
"""

import io
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse

from app.core.dependencies import get_mapping_pipeline, get_output_repository
from app.core.exceptions import (
    CategoryNotFoundError,
    SchemaNotFoundError,
    SourceFileError,
    OutputNotFoundError,
    BedrockCallError,
    MappingParseError,
)
from app.models.mapping import (
    RunMappingRequest,
    RunMappingResponse,
    CategoryMappingResponse,
)
from app.repositories.output_repository import OutputRepository
from app.services.mapping_pipeline import MappingPipeline

router = APIRouter(prefix="/mappings", tags=["Mappings"])

# ── MIME types for download formats ──────────────────────────────
_MIME = {
    "json":  "application/json",
    "excel": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "html":  "text/html",
}
_EXT = {"json": "json", "excel": "xlsx", "html": "html"}


# ── Trigger full run ──────────────────────────────────────────────

@router.post(
    "/run",
    response_model=RunMappingResponse,
    status_code=201,
    summary="Run full multi-category mapping",
    description=(
        "Triggers a complete ETL schema mapping run for all (or selected) "
        "provider categories found in the source file. "
        "Each category is mapped against its own destination schema via AWS Bedrock. "
        "Returns a combined summary and S3 keys for all output files. "
        "**Note**: This call is synchronous and may take 30–120 seconds depending "
        "on the number of categories and source columns."
    ),
)
def run_full_mapping(
    request:  RunMappingRequest,
    pipeline: Annotated[MappingPipeline, Depends(get_mapping_pipeline)],
) -> RunMappingResponse:
    try:
        return pipeline.run(request)
    except (CategoryNotFoundError, SchemaNotFoundError) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except SourceFileError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except (BedrockCallError, MappingParseError) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


# ── Trigger single-category run ───────────────────────────────────

@router.post(
    "/run/{category}",
    response_model=CategoryMappingResponse,
    status_code=201,
    summary="Run mapping for one category",
    description=(
        "Triggers a mapping run for a single provider category only "
        "(e.g. PRACTITIONER, PRACTICE, or FACILITY). "
        "Useful for re-running a failed category without re-processing the full file."
    ),
)
def run_category_mapping(
    category: str,
    request:  RunMappingRequest,
    pipeline: Annotated[MappingPipeline, Depends(get_mapping_pipeline)],
) -> CategoryMappingResponse:
    try:
        result = pipeline.run_single_category(category.upper(), request)
    except (CategoryNotFoundError, SchemaNotFoundError) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except SourceFileError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except (BedrockCallError, MappingParseError) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    # run_id not available in single-category mode — use timestamp
    return CategoryMappingResponse(
        run_id      = result.output_keys.json.split("/")[-1].replace(".json", ""),
        category    = result.category,
        summary     = result.summary,
        output_keys = result.output_keys,
        mappings    = result.mappings,
    )


# ── Retrieve combined run result ──────────────────────────────────

@router.get(
    "/{run_id}",
    summary="Get combined run result",
    description=(
        "Fetches the combined summary JSON for a completed mapping run from S3. "
        "The run_id is returned in the response of POST /mappings/run."
    ),
)
def get_run_result(
    run_id:      str,
    source_name: str,
    timestamp:   str,
    output_repo: Annotated[OutputRepository, Depends(get_output_repository)],
) -> dict:
    key = f"mappings/{source_name}/combined_summary_{timestamp}.json"
    try:
        raw = output_repo.get_output_bytes(key)
    except OutputNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    import json
    return json.loads(raw)


# ── Retrieve per-category result ──────────────────────────────────

@router.get(
    "/{source_name}/{category}/{timestamp}",
    summary="Get per-category mapping result",
    description="Fetches the JSON mapping result for a specific category and run.",
)
def get_category_result(
    source_name: str,
    category:    str,
    timestamp:   str,
    output_repo: Annotated[OutputRepository, Depends(get_output_repository)],
) -> dict:
    key = f"mappings/{source_name}/{category.lower()}_{timestamp}.json"
    try:
        raw = output_repo.get_output_bytes(key)
    except OutputNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    import json
    return json.loads(raw)


# ── Download output file ──────────────────────────────────────────

@router.get(
    "/{source_name}/{category}/{timestamp}/download/{fmt}",
    summary="Download mapping output file",
    description=(
        "Downloads a specific output file for a category mapping run. "
        "`fmt` must be one of: `json`, `excel`, `html`."
    ),
)
def download_output(
    source_name: str,
    category:    str,
    timestamp:   str,
    fmt:         Literal["json", "excel", "html"],
    output_repo: Annotated[OutputRepository, Depends(get_output_repository)],
) -> StreamingResponse:
    ext = _EXT[fmt]
    key = f"mappings/{source_name}/{category.lower()}_{timestamp}.{ext}"

    try:
        content = output_repo.get_output_bytes(key)
    except OutputNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    filename = key.split("/")[-1]
    return StreamingResponse(
        io.BytesIO(content),
        media_type=_MIME[fmt],
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
