"""
app/api/routes/verification.py
────────────────────────────────
Template config verification endpoints.

POST /verify/{category} → run health checks on a category schema
GET  /verify/{category}/checks → list all check names (dry-run, no S3)
"""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException

from app.core.dependencies import get_schema_repository, get_verification_engine, get_source_repository
from app.core.exceptions import SchemaNotFoundError, SourceFileError
from app.repositories.schema_repository import SchemaRepository
from app.repositories.source_repository import SourceRepository
from app.utils.verification import VerificationEngine

router = APIRouter(prefix="/verify", tags=["Verification"])


@router.post(
    "/{category}",
    summary="Verify schema configuration for a category",
    description=(
        "Runs a suite of automated health checks against the destination schema "
        "and the source file for the given provider category. "
        "Returns a health score (0–100), grade, and individual check results. "
        "Optionally pass `source_key` to validate against a specific source file."
    ),
)
def verify_category(
    category:    str,
    source_key:  str | None = None,
    schema_repo: Annotated[SchemaRepository, Depends(get_schema_repository)] = None,
    source_repo: Annotated[SourceRepository, Depends(get_source_repository)] = None,
    engine:      Annotated[VerificationEngine, Depends(get_verification_engine)] = None,
) -> dict:
    # Load destination schema
    try:
        schema = schema_repo.get(category.upper())
    except SchemaNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    # Load source columns if a source key was provided
    source_columns: list[str] = []
    if source_key:
        try:
            split          = source_repo.split_by_category(source_key)
            source_columns = split.headers
        except SourceFileError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
    else:
        # Use field names as a minimal proxy for source column check
        source_columns = [f.name for f in schema.fields]

    result = engine.verify(schema, source_columns)
    return result.to_dict()


@router.get(
    "/{category}/checks",
    summary="List verification check names",
    description=(
        "Returns the names and IDs of all checks that will be run for "
        "the given category without executing them. Use to understand what "
        "the verification suite covers."
    ),
)
def list_checks(
    category:    str,
    schema_repo: Annotated[SchemaRepository, Depends(get_schema_repository)] = None,
    engine:      Annotated[VerificationEngine, Depends(get_verification_engine)] = None,
) -> dict:
    try:
        schema = schema_repo.get(category.upper())
    except SchemaNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    # Run against the schema's own field names to generate the check list
    result = engine.verify(schema, [f.name for f in schema.fields])
    return {
        "category": category.upper(),
        "check_count": len(result.checks),
        "checks": [
            {"check_id": c.check_id, "title": c.title}
            for c in result.checks
        ],
    }
