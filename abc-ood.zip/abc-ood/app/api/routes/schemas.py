"""
app/api/routes/schemas.py
──────────────────────────
Schema management endpoints.

GET  /schemas            → list all configured category schemas
GET  /schemas/{category} → full field list for one category
POST /schemas/{category}/reload → invalidate S3 cache and reload
"""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException

from app.core.dependencies import get_schema_repository
from app.core.exceptions import SchemaNotFoundError
from app.models.schema import SchemaListResponse, SchemaDetailResponse
from app.repositories.schema_repository import SchemaRepository

router = APIRouter(prefix="/schemas", tags=["Schemas"])


@router.get(
    "",
    response_model=SchemaListResponse,
    summary="List all destination schemas",
    description="Returns a summary of all category schemas configured via CATEGORY_SCHEMA_MAP. "
                "Includes field count per category.",
)
def list_schemas(
    repo: Annotated[SchemaRepository, Depends(get_schema_repository)],
) -> SchemaListResponse:
    return repo.list_all()


@router.get(
    "/{category}",
    response_model=SchemaDetailResponse,
    summary="Get destination schema for a category",
    description="Returns the full field list for the given provider category "
                "(PRACTITIONER, PRACTICE, or FACILITY). "
                "Category name is case-insensitive.",
)
def get_schema(
    category: str,
    repo: Annotated[SchemaRepository, Depends(get_schema_repository)],
) -> SchemaDetailResponse:
    try:
        schema = repo.get(category.upper())
    except SchemaNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    return SchemaDetailResponse(
        category    = schema.category,
        s3_key      = schema.s3_key,
        field_count = schema.field_count,
        fields      = schema.fields,
    )


@router.post(
    "/{category}/reload",
    summary="Reload schema from S3",
    description="Invalidates the in-memory cache for the given category and "
                "re-fetches the schema from S3. Use after updating a schema JSON file.",
)
def reload_schema(
    category: str,
    repo: Annotated[SchemaRepository, Depends(get_schema_repository)],
) -> dict:
    repo.invalidate(category.upper())
    try:
        schema = repo.get(category.upper())
    except SchemaNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    return {
        "message":    f"Schema for {category.upper()} reloaded from S3.",
        "category":   schema.category,
        "s3_key":     schema.s3_key,
        "field_count": schema.field_count,
    }
