"""
app/repositories/schema_repository.py
───────────────────────────────────────
SchemaRepository — loads destination schemas from S3 by category.
"""

from app.core.config import AppConfig
from app.core.exceptions import SchemaNotFoundError
from app.models.schema import DestinationField, DestinationSchema, SchemaListResponse
from app.repositories.base import BaseRepository


class SchemaRepository(BaseRepository):
    """
    Responsible for reading and serving destination schema JSON files.
    One schema file per provider category, stored in S3.

    Schemas are cached per category after the first load.
    """

    def __init__(self, s3_client, config: AppConfig) -> None:
        super().__init__(s3_client, config)
        self._cache: dict[str, DestinationSchema] = {}

    # ── Public interface ──────────────────────────────────────────

    def get(self, category: str) -> DestinationSchema:
        """Load and return the destination schema for the given category."""
        category = category.upper()
        if category not in self._cache:
            self._cache[category] = self._load(category)
        return self._cache[category]

    def list_all(self) -> SchemaListResponse:
        """Return a lightweight listing of all configured category schemas."""
        schema_map = self._config.category_schema_map
        schemas = []
        for cat, key in schema_map.items():
            try:
                s = self.get(cat)
                schemas.append({
                    "category":    cat,
                    "s3_key":      key,
                    "field_count": s.field_count,
                })
            except SchemaNotFoundError:
                schemas.append({
                    "category":    cat,
                    "s3_key":      key,
                    "field_count": None,
                    "error":       "Schema not found in S3",
                })
        return SchemaListResponse(
            count=len(schemas),
            categories=list(schema_map.keys()),
            schemas=schemas,
        )

    def get_raw_fields(self, category: str) -> list[dict]:
        """Return the raw list of field dicts (as loaded from S3 JSON)."""
        schema = self.get(category)
        return [f.model_dump() for f in schema.fields]

    def invalidate(self, category: str | None = None) -> None:
        """Clear schema cache. Pass None to clear all."""
        if category:
            self._cache.pop(category.upper(), None)
        else:
            self._cache.clear()

    # ── Internal ──────────────────────────────────────────────────

    def _load(self, category: str) -> DestinationSchema:
        schema_map = self._config.category_schema_map
        if category not in schema_map:
            raise SchemaNotFoundError(
                f"No destination schema configured for category '{category}'. "
                f"Known categories: {list(schema_map.keys())}"
            )
        key    = schema_map[category]
        bucket = self._config.source_bucket

        self._log.info("Loading destination schema s3://%s/%s", bucket, key)
        raw_fields: list[dict] = self._read_json(bucket, key)  # type: ignore[assignment]
        fields = [DestinationField(**f) for f in raw_fields]
        self._log.info("Schema loaded — category=%s  fields=%d", category, len(fields))

        return DestinationSchema(category=category, s3_key=key, fields=fields)
