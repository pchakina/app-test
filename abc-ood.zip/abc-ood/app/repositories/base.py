"""
app/repositories/base.py
─────────────────────────
BaseRepository — thin, reusable S3 helpers shared by all repositories.
Every concrete repository extends this class.
"""

import json
import logging
from abc import ABC
from typing import Any

from botocore.exceptions import ClientError

from app.core.config import AppConfig
from app.core.exceptions import OutputWriteError, OutputNotFoundError
from app.core.logging import LoggerFactory


class BaseRepository(ABC):
    """
    Abstract base providing typed S3 read/write helpers.

    All concrete repositories inject the same boto3 S3 client and
    AppConfig instance so there is a single boto3 client per
    application lifetime (managed by the DI layer in dependencies.py).
    """

    def __init__(self, s3_client: Any, config: AppConfig) -> None:
        self._s3     = s3_client
        self._config = config
        self._log: logging.Logger = LoggerFactory.get(self.__class__.__name__)

    # ── Read helpers ──────────────────────────────────────────────

    def _read_bytes(self, bucket: str, key: str) -> bytes:
        self._log.debug("S3 GET s3://%s/%s", bucket, key)
        try:
            return self._s3.get_object(Bucket=bucket, Key=key)["Body"].read()
        except ClientError as exc:
            code = exc.response["Error"]["Code"]
            if code in ("NoSuchKey", "404"):
                raise OutputNotFoundError(f"s3://{bucket}/{key} not found") from exc
            raise OutputWriteError(f"S3 read error: {exc}") from exc

    def _read_text(self, bucket: str, key: str, encoding: str = "utf-8") -> str:
        return self._read_bytes(bucket, key).decode(encoding)

    def _read_json(self, bucket: str, key: str) -> dict | list:
        return json.loads(self._read_bytes(bucket, key))

    # ── Write helpers ─────────────────────────────────────────────

    def _put(
        self,
        bucket:       str,
        key:          str,
        body:         bytes | str,
        content_type: str = "application/octet-stream",
    ) -> None:
        if isinstance(body, str):
            body = body.encode("utf-8")
        try:
            self._s3.put_object(Bucket=bucket, Key=key, Body=body,
                                ContentType=content_type)
        except ClientError as exc:
            raise OutputWriteError(f"S3 write error for {key}: {exc}") from exc
        self._log.info("Saved → s3://%s/%s (%d bytes)", bucket, key, len(body))

    def _put_json(self, bucket: str, key: str, data: dict | list) -> None:
        self._put(bucket, key, json.dumps(data, indent=2), "application/json")

    # ── Existence check ───────────────────────────────────────────

    def _exists(self, bucket: str, key: str) -> bool:
        try:
            self._s3.head_object(Bucket=bucket, Key=key)
            return True
        except ClientError:
            return False
