"""
app/repositories/source_repository.py
───────────────────────────────────────
SourceRepository — reads the source file from S3 and splits rows by category.
"""

import io

import pandas as pd

from app.core.config import AppConfig
from app.core.exceptions import CategoryColumnMissingError, SourceFileError
from app.models.provider import FileMeta, SourceSplit
from app.repositories.base import BaseRepository


class SourceRepository(BaseRepository):
    """
    Responsible for:
      1. Reading the source CSV/Excel from S3.
      2. Detecting headers and file metadata.
      3. Splitting rows by provider category so each category's
         data is available independently for the pipeline.
    """

    def __init__(self, s3_client, config: AppConfig) -> None:
        super().__init__(s3_client, config)

    # ── Public interface ──────────────────────────────────────────

    def split_by_category(
        self,
        source_key:      str | None = None,
        category_column: str | None = None,
    ) -> SourceSplit:
        """
        Read the source file and split into per-category column lists.

        Returns a SourceSplit with:
          - headers           : column headers (excluding category column)
          - categories_found  : unique category values in the file
          - file_meta         : file type, header row, sheet, etc.
        """
        src_key  = source_key      or self._config.source_key
        cat_col  = category_column or self._config.category_column
        bucket   = self._config.source_bucket

        raw      = self._read_bytes(bucket, src_key)
        file_meta = self._detect_meta(src_key)
        df        = self._load_dataframe(raw, file_meta)

        df.columns = [str(c).strip() for c in df.columns]

        # Resolve category column name
        cat_col_name = self._resolve_category_column(df, cat_col)

        data_cols        = [c for c in df.columns if c != cat_col_name]
        categories_found = df[cat_col_name].dropna().unique().tolist()

        self._log.info(
            "Source split — categories=%s  data_cols=%d",
            categories_found, len(data_cols),
        )

        return SourceSplit(
            headers=data_cols,
            categories_found=categories_found,
            file_meta=file_meta,
        )

    def get_headers(
        self,
        source_key: str | None = None,
    ) -> tuple[list[str], FileMeta]:
        """
        Return (headers, file_meta) for the source file without
        splitting by category. Used by the single-schema fallback.
        """
        src_key   = source_key or self._config.source_key
        bucket    = self._config.source_bucket
        raw       = self._read_bytes(bucket, src_key)
        file_meta = self._detect_meta(src_key)
        df        = self._load_dataframe(raw, file_meta)
        headers   = [str(c).strip() for c in df.columns]
        return headers, file_meta

    # ── Internal ──────────────────────────────────────────────────

    def _detect_meta(self, source_key: str) -> FileMeta:
        ext = source_key.rsplit(".", 1)[-1].lower()
        if ext not in ("csv", "xlsx", "xls"):
            raise SourceFileError(
                f"Unsupported file extension '.{ext}'. Supported: csv, xlsx, xls"
            )
        return FileMeta(
            file_type=ext,
            header_row=0,
            skipped_rows=0,
            sheet=None,
            source_key=source_key,
        )

    def _load_dataframe(self, raw: bytes, meta: FileMeta) -> pd.DataFrame:
        try:
            if meta.file_type == "csv":
                return pd.read_csv(io.BytesIO(raw), header=meta.header_row)
            else:
                sheet = meta.sheet or 0
                return pd.read_excel(
                    io.BytesIO(raw), sheet_name=sheet, header=meta.header_row
                )
        except Exception as exc:
            raise SourceFileError(f"Cannot parse source file: {exc}") from exc

    def _resolve_category_column(self, df: pd.DataFrame, category_col: str) -> str:
        if category_col.isdigit():
            idx = int(category_col)
            if idx >= len(df.columns):
                raise CategoryColumnMissingError(
                    f"Column index {idx} is out of range (file has {len(df.columns)} columns)"
                )
            return df.columns[idx]
        if category_col in df.columns:
            return category_col
        raise CategoryColumnMissingError(
            f"Category column '{category_col}' not found. "
            f"Available columns: {list(df.columns)[:10]}…"
        )
