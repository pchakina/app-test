"""
app/repositories/output_repository.py
───────────────────────────────────────
OutputRepository — persists all mapping output artefacts to S3.
"""

import json
from datetime import datetime

from app.core.config import AppConfig
from app.models.mapping import MappingRunResult, CategoryResult
from app.repositories.base import BaseRepository


class OutputRepository(BaseRepository):
    """
    Responsible for writing all three output formats (JSON, Excel, HTML)
    to S3 and returning the keys under which they were stored.

    The S3 path convention is:
      mappings/{source_name}/{category_lower}_{timestamp}.{ext}
      mappings/{source_name}/combined_summary_{timestamp}.json
    """

    def __init__(self, s3_client, config: AppConfig) -> None:
        super().__init__(s3_client, config)

    # ── JSON ──────────────────────────────────────────────────────

    def save_category_json(
        self,
        category:    str,
        source_name: str,
        result:      CategoryResult,
        ts:          str,
        model_id:    str,
        source_key:  str,
        file_meta:   dict,
    ) -> str:
        key  = self._key(source_name, category, ts, "json")
        body = {
            "version":      "1.0",
            "generated_at": datetime.now().isoformat(),
            "source":       source_name,
            "source_file":  source_key,
            "category":     category,
            "file_type":    file_meta.get("file_type"),
            "header_row":   file_meta.get("header_row"),
            "sheet":        file_meta.get("sheet"),
            "model":        model_id,
            "summary":      result.summary.model_dump(),
            "mappings":     [m.model_dump() for m in result.mappings],
        }
        self._put_json(self._config.output_bucket, key, body)
        return key

    def save_combined_json(self, result: MappingRunResult) -> str:
        key = f"mappings/{result.source_name}/combined_summary_{result.timestamp}.json"
        self._put_json(
            self._config.output_bucket, key, result.model_dump(mode="json")
        )
        return key

    # ── Excel ─────────────────────────────────────────────────────

    def save_category_excel(
        self,
        category:    str,
        source_name: str,
        workbook_bytes: bytes,
        ts:          str,
    ) -> str:
        key = self._key(source_name, category, ts, "xlsx")
        self._put(
            self._config.output_bucket, key, workbook_bytes,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        return key

    # ── HTML ──────────────────────────────────────────────────────

    def save_category_html(
        self,
        category:    str,
        source_name: str,
        html:        str,
        ts:          str,
    ) -> str:
        key = self._key(source_name, category, ts, "html")
        self._put(self._config.output_bucket, key, html, "text/html")
        return key

    # ── Download ──────────────────────────────────────────────────

    def get_output_bytes(self, key: str) -> bytes:
        """Fetch raw bytes for a stored output file (for download endpoints)."""
        return self._read_bytes(self._config.output_bucket, key)

    # ── Helpers ───────────────────────────────────────────────────

    @staticmethod
    def _key(source_name: str, category: str, ts: str, ext: str) -> str:
        return f"mappings/{source_name}/{category.lower()}_{ts}.{ext}"
