"""
app/repositories/config_repository.py
───────────────────────────────────────
ConfigRepository — loads and caches the prompt_config.yaml from S3.
"""

import yaml
from functools import lru_cache

from app.core.config import AppConfig
from app.core.exceptions import PromptConfigNotFoundError, ConfigurationError
from app.repositories.base import BaseRepository


class ConfigRepository(BaseRepository):
    """
    Responsible for loading the prompt and model configuration YAML
    from S3 and providing it as a plain dict to callers.

    The config is cached after the first load. Call reload() to force
    a fresh fetch (e.g. after updating the YAML in S3).
    """

    def __init__(self, s3_client, config: AppConfig) -> None:
        super().__init__(s3_client, config)
        self._cached: dict | None = None

    # ── Public interface ──────────────────────────────────────────

    def load(self) -> dict:
        """
        Return the prompt config dict, loading from S3 if not already cached.
        """
        if self._cached is None:
            self._cached = self._fetch()
        return self._cached

    def reload(self) -> dict:
        """Force a fresh load from S3, bypassing the in-memory cache."""
        self._cached = None
        return self.load()

    # ── Internal ──────────────────────────────────────────────────

    def _fetch(self) -> dict:
        bucket = self._config.source_bucket
        key    = self._config.prompt_config_key
        self._log.info("Loading prompt config s3://%s/%s", bucket, key)
        try:
            raw = self._read_text(bucket, key)
        except Exception as exc:
            raise PromptConfigNotFoundError(
                f"Cannot load prompt config from s3://{bucket}/{key}: {exc}"
            ) from exc

        try:
            cfg = yaml.safe_load(raw)
        except yaml.YAMLError as exc:
            raise ConfigurationError(f"Invalid YAML in prompt config: {exc}") from exc

        self._log.info(
            "Prompt config loaded — model=%s  temp=%s",
            cfg.get("model", {}).get("model_id", "?"),
            cfg.get("model", {}).get("temperature", "?"),
        )
        return cfg
