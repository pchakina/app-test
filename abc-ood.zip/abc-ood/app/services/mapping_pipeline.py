"""
app/services/mapping_pipeline.py
──────────────────────────────────
MappingPipeline — orchestrates the full multi-category ETL mapping run.

This is the top-level service that coordinates all collaborators:
  SourceRepository   → read + split source file
  SchemaRepository   → load destination schema per category
  ConfigRepository   → load prompt config
  PromptBuilder      → assemble LLM messages
  BedrockClient      → call LLM, parse response
  MappingSummariser  → compute coverage stats
  OutputWriter       → persist JSON / Excel / HTML
  OutputRepository   → save combined summary
"""

import time
import uuid
from datetime import datetime

from app.core.config import AppConfig
from app.core.exceptions import CategoryNotFoundError
from app.core.logging import LoggerFactory
from app.models.mapping import (
    CategoryResult,
    MappingRunResult,
    RunMappingRequest,
    RunMappingResponse,
    CategoryOutputKeys,
)
from app.repositories.config_repository import ConfigRepository
from app.repositories.output_repository import OutputRepository
from app.repositories.schema_repository import SchemaRepository
from app.repositories.source_repository import SourceRepository
from app.services.bedrock_client import BedrockClient
from app.services.mapping_summariser import MappingSummariser
from app.services.output_writer import OutputWriter
from app.services.prompt_builder import PromptBuilder


class MappingPipeline:
    """
    Orchestrates the full healthcare schema mapping pipeline.

    One instance per request (constructed via DI in dependencies.py).
    Stateless beyond the injected collaborators — safe to reuse.
    """

    def __init__(
        self,
        config:         AppConfig,
        config_repo:    ConfigRepository,
        schema_repo:    SchemaRepository,
        source_repo:    SourceRepository,
        bedrock:        BedrockClient,
        prompt_builder: PromptBuilder,
        summariser:     MappingSummariser,
        output_writer:  OutputWriter,
    ) -> None:
        self._config         = config
        self._config_repo    = config_repo
        self._schema_repo    = schema_repo
        self._source_repo    = source_repo
        self._bedrock        = bedrock
        self._prompt_builder = prompt_builder
        self._summariser     = summariser
        self._output_writer  = output_writer
        self._output_repo    = output_writer._repo      # shared reference
        self._log            = LoggerFactory.get(self.__class__.__name__)

    # ── Public interface ──────────────────────────────────────────

    def run(self, request: RunMappingRequest) -> RunMappingResponse:
        """
        Execute a full multi-category mapping run and return a
        lightweight RunMappingResponse immediately.
        Full results are persisted to S3.
        """
        run_id      = str(uuid.uuid4())
        ts          = datetime.now().strftime("%Y%m%d_%H%M%S")
        src_key     = request.source_key    or self._config.source_key
        cat_col     = request.category_column or self._config.category_column
        source_name = src_key.rsplit("/", 1)[-1].rsplit(".", 1)[0]
        t0          = time.time()

        self._log.info("=" * 60)
        self._log.info("START run_id=%s  source=%s", run_id, src_key)

        # 1. Load prompt config
        prompt_cfg = self._config_repo.load()
        model_id   = prompt_cfg["model"]["model_id"]

        # 2. Split source by category
        source_split = self._source_repo.split_by_category(src_key, cat_col)
        categories_to_run = self._resolve_categories(
            request.categories, source_split.categories_found
        )

        # 3. Per-category pipeline
        category_results: dict[str, CategoryResult] = {}
        for cat in categories_to_run:
            category_results[cat] = self._run_category(
                category    = cat,
                headers     = source_split.headers,
                source_name = source_name,
                src_key     = src_key,
                ts          = ts,
                file_meta   = source_split.file_meta,
                prompt_cfg  = prompt_cfg,
                model_id    = model_id,
            )

        # 4. Combined summary
        summaries       = {cat: r.summary for cat, r in category_results.items()}
        combined_summary = self._summariser.combine(summaries)

        # 5. Build full run result and persist combined JSON
        run_result = MappingRunResult(
            run_id               = run_id,
            source_name          = source_name,
            source_key           = src_key,
            timestamp            = ts,
            generated_at         = datetime.now(),
            model_id             = model_id,
            categories_processed = categories_to_run,
            combined_summary     = combined_summary,
            combined_key         = "",           # filled below
            category_results     = category_results,
        )
        combined_key       = self._output_repo.save_combined_json(run_result)
        run_result.combined_key = combined_key

        elapsed = time.time() - t0
        self._log.info(
            "DONE run_id=%s  %.2fs  categories=%d  coverage=%d%%",
            run_id, elapsed, len(category_results),
            combined_summary.overall_coverage_pct,
        )
        self._log.info("=" * 60)

        # 6. Return lightweight response
        return RunMappingResponse(
            run_id               = run_id,
            source_name          = source_name,
            timestamp            = ts,
            categories_processed = categories_to_run,
            combined_key         = combined_key,
            combined_summary     = combined_summary,
            output_keys_by_category = {
                cat: res.output_keys for cat, res in category_results.items()
            },
        )

    def run_single_category(
        self,
        category:    str,
        request:     RunMappingRequest,
    ) -> CategoryResult:
        """
        Run the pipeline for one specific category only.
        Used by POST /mappings/run/{category}.
        """
        ts          = datetime.now().strftime("%Y%m%d_%H%M%S")
        src_key     = request.source_key or self._config.source_key
        cat_col     = request.category_column or self._config.category_column
        source_name = src_key.rsplit("/", 1)[-1].rsplit(".", 1)[0]

        prompt_cfg   = self._config_repo.load()
        model_id     = prompt_cfg["model"]["model_id"]
        source_split = self._source_repo.split_by_category(src_key, cat_col)

        if category not in source_split.categories_found:
            raise CategoryNotFoundError(
                f"Category '{category}' not found in source file. "
                f"Found: {source_split.categories_found}"
            )

        return self._run_category(
            category    = category,
            headers     = source_split.headers,
            source_name = source_name,
            src_key     = src_key,
            ts          = ts,
            file_meta   = source_split.file_meta,
            prompt_cfg  = prompt_cfg,
            model_id    = model_id,
        )

    # ── Internal ──────────────────────────────────────────────────

    def _run_category(
        self,
        category:    str,
        headers:     list[str],
        source_name: str,
        src_key:     str,
        ts:          str,
        file_meta,
        prompt_cfg:  dict,
        model_id:    str,
    ) -> CategoryResult:
        self._log.info("── Category: %s ──────────────────────────", category)

        schema   = self._schema_repo.get(category)
        messages = self._prompt_builder.build(headers, schema, source_name, category)
        mappings = self._bedrock.converse(messages, prompt_cfg["model"])
        summary  = self._summariser.summarise(mappings)

        # Build a preliminary result (output_keys filled after write)
        result = CategoryResult(
            category    = category,
            summary     = summary,
            output_keys = CategoryOutputKeys(json="", excel="", html=""),
            mappings    = mappings,
        )

        output_keys = self._output_writer.write_all(
            result      = result,
            source_name = source_name,
            ts          = ts,
            file_meta   = file_meta,
            source_key  = src_key,
            model_id    = model_id,
        )
        result.output_keys = output_keys

        self._log.info(
            "Category done — %s  coverage=%d%%  needs_review=%d",
            category, summary.coverage_pct, summary.needs_review,
        )
        return result

    def _resolve_categories(
        self,
        requested:  list[str] | None,
        available:  list[str],
    ) -> list[str]:
        schema_map = self._config.category_schema_map
        if requested:
            missing = [c for c in requested if c not in available]
            if missing:
                raise CategoryNotFoundError(
                    f"Requested categories not in source file: {missing}. "
                    f"Available: {available}"
                )
            return [c for c in requested if c in schema_map]
        return [c for c in available if c in schema_map]
