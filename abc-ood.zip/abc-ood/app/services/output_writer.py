"""
app/services/output_writer.py
──────────────────────────────
OutputWriter — orchestrates writing all three output formats for one category.

Coordinates between:
  - ExcelBuilder (builds the openpyxl workbook bytes)
  - Jinja2 HTML template (renders the HTML report)
  - OutputRepository (persists all artefacts to S3)
"""

from jinja2 import Environment, BaseLoader, TemplateNotFound

from app.core.config import AppConfig
from app.core.logging import LoggerFactory
from app.models.mapping import CategoryResult, CategoryOutputKeys
from app.models.provider import FileMeta
from app.repositories.output_repository import OutputRepository
from app.utils.excel_builder import ExcelBuilder


class _S3TemplateLoader(BaseLoader):
    """Jinja2 loader that reads templates directly from S3."""

    def __init__(self, output_repo: OutputRepository, source_bucket: str) -> None:
        self._repo          = output_repo
        self._source_bucket = source_bucket

    def get_source(self, env, key):
        try:
            text = self._repo._read_text(self._source_bucket, key)
            return text, key, lambda: False
        except Exception:
            raise TemplateNotFound(key)


class OutputWriter:
    """
    Responsible for converting a CategoryResult into three persisted outputs:
      JSON  → structured mapping data
      Excel → colour-coded reviewer workbook
      HTML  → Jinja2-rendered review report

    Returns a CategoryOutputKeys with the S3 keys for all three artefacts.
    """

    def __init__(self, output_repo: OutputRepository, config: AppConfig) -> None:
        self._repo          = output_repo
        self._config        = config
        self._excel_builder = ExcelBuilder()
        self._log           = LoggerFactory.get(self.__class__.__name__)
        self._jinja_env     = Environment(
            loader=_S3TemplateLoader(output_repo, config.source_bucket),
            autoescape=True,
        )

    # ── Public interface ──────────────────────────────────────────

    def write_all(
        self,
        result:      CategoryResult,
        source_name: str,
        ts:          str,
        file_meta:   FileMeta,
        source_key:  str,
        model_id:    str,
    ) -> CategoryOutputKeys:
        """
        Write JSON, Excel and HTML outputs for one category result.
        Returns the S3 keys for all three files.
        """
        json_key  = self._write_json(result, source_name, ts, file_meta, source_key, model_id)
        excel_key = self._write_excel(result, source_name, ts, file_meta, model_id)
        html_key  = self._write_html(result, source_name, ts, model_id)

        self._log.info(
            "Outputs written — category=%s  json=%s  excel=%s  html=%s",
            result.category, json_key, excel_key, html_key,
        )
        return CategoryOutputKeys(json=json_key, excel=excel_key, html=html_key)

    # ── Internal ──────────────────────────────────────────────────

    def _write_json(
        self,
        result:      CategoryResult,
        source_name: str,
        ts:          str,
        file_meta:   FileMeta,
        source_key:  str,
        model_id:    str,
    ) -> str:
        return self._repo.save_category_json(
            category    = result.category,
            source_name = source_name,
            result      = result,
            ts          = ts,
            model_id    = model_id,
            source_key  = source_key,
            file_meta   = file_meta.model_dump(),
        )

    def _write_excel(
        self,
        result:      CategoryResult,
        source_name: str,
        ts:          str,
        file_meta:   FileMeta,
        model_id:    str,
    ) -> str:
        workbook_bytes = self._excel_builder.build(
            mappings    = result.mappings,
            category    = result.category,
            source_key  = self._config.source_key,
            file_meta   = file_meta,
            model_id    = model_id,
        )
        return self._repo.save_category_excel(
            category       = result.category,
            source_name    = source_name,
            workbook_bytes = workbook_bytes,
            ts             = ts,
        )

    def _write_html(
        self,
        result:      CategoryResult,
        source_name: str,
        ts:          str,
        model_id:    str,
    ) -> str:
        from datetime import datetime
        try:
            template = self._jinja_env.get_template(self._config.template_key)
            html = template.render(
                source_name  = source_name,
                category     = result.category,
                generated_at = datetime.now().strftime("%Y-%m-%d %H:%M"),
                model_id     = model_id,
                summary      = result.summary.model_dump(),
                mappings     = [m.model_dump() for m in result.mappings],
            )
        except TemplateNotFound:
            self._log.warning(
                "HTML template not found at %s — skipping HTML output",
                self._config.template_key,
            )
            html = f"<html><body><h1>{result.category} mapping</h1><p>Template not found.</p></body></html>"

        return self._repo.save_category_html(
            category    = result.category,
            source_name = source_name,
            html        = html,
            ts          = ts,
        )
