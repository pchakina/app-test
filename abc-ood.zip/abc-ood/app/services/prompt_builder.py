"""
app/services/prompt_builder.py
────────────────────────────────
PromptBuilder — assembles LLM-ready message lists from templates and schemas.

This class has no I/O and no AWS coupling — it is a pure transformation
service that turns configuration + column lists into message dicts.
"""

from app.core.logging import LoggerFactory
from app.models.schema import DestinationSchema
from app.repositories.config_repository import ConfigRepository


class PromptBuilder:
    """
    Builds OpenAI-compatible message lists:
      [{"role": "system", "content": "..."}, {"role": "user", "content": "..."}]

    Handles the Gemma 3 special case (no system role on Bedrock converse) by
    merging the system prompt into the first user message when the model_id
    starts with "google.".
    """

    def __init__(self, config_repo: ConfigRepository) -> None:
        self._config_repo = config_repo
        self._log         = LoggerFactory.get(self.__class__.__name__)

    # ── Public interface ──────────────────────────────────────────

    def build(
        self,
        source_columns: list[str],
        schema:         DestinationSchema,
        source_name:    str,
        category:       str,
    ) -> list[dict]:
        """
        Return the messages list for a single category mapping call.
        """
        cfg         = self._config_repo.load()
        dest_block  = self._build_dest_block(schema, cfg)
        src_block   = self._build_src_block(source_columns)
        user_content = cfg["user_prompt_template"].format(
            category         = category,
            dest_block       = dest_block,
            source_name      = source_name,
            src_block        = src_block,
            mapping_rules    = cfg["mapping_rules"],
            confidence_rules = cfg["confidence_rules"],
            output_schema    = cfg["output_schema"],
            reviewer_rules   = cfg["reviewer_rules"],
        )
        system_text = cfg["system_prompt"].strip()
        model_id    = cfg["model"]["model_id"]
        return self._assemble_messages(system_text, user_content.strip(), model_id)

    # ── Internal ──────────────────────────────────────────────────

    def _build_dest_block(self, schema: DestinationSchema, cfg: dict) -> str:
        tpl = cfg["dest_column_template"]
        lines = []
        for i, field in enumerate(schema.fields):
            line = tpl.format(
                index           = i + 1,
                name            = field.name,
                data_type       = field.data_type,
                format_str      = f" | format={field.format}"             if field.format        else "",
                mandatory_label = " | MANDATORY"                          if field.mandatory     else " | optional",
                default_str     = f" | default={field.default_value}"     if field.default_value is not None else "",
                description_str = f" | description={field.description}"   if field.description   else "",
            )
            lines.append(line)
        return "\n".join(lines)

    @staticmethod
    def _build_src_block(source_columns: list[str]) -> str:
        return "\n".join(
            f'  {i + 1}. "{col}"' for i, col in enumerate(source_columns)
        )

    def _assemble_messages(
        self,
        system_text:  str,
        user_content: str,
        model_id:     str,
    ) -> list[dict]:
        # Gemma 3 on Bedrock does not support the system role —
        # merge system content into the first user message.
        if model_id.startswith("google."):
            self._log.info("Gemma model detected — merging system prompt into user message")
            merged = f"[SYSTEM INSTRUCTIONS]\n{system_text}\n\n[USER REQUEST]\n{user_content}"
            return [{"role": "user", "content": merged}]

        return [
            {"role": "system", "content": system_text},
            {"role": "user",   "content": user_content},
        ]
