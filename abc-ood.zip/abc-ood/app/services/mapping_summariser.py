"""
app/services/mapping_summariser.py
────────────────────────────────────
MappingSummariser — pure stateless calculation of coverage statistics.
No I/O, no AWS, no configuration needed.
"""

import math

from app.models.mapping import MappingRecord, MappingSummary, CombinedSummary


class MappingSummariser:
    """
    Computes MappingSummary and CombinedSummary from lists of MappingRecord.

    This class is intentionally stateless — all methods operate on the
    data passed in and return new model instances. It can be instantiated
    once and reused for every category and every run.
    """

    # ── Public interface ──────────────────────────────────────────

    def summarise(self, mappings: list[MappingRecord]) -> MappingSummary:
        """Compute per-category statistics from a flat list of MappingRecords."""
        total        = len(mappings)
        single_match = sum(1 for m in mappings if m.outcome == "single_match")
        split        = sum(1 for m in mappings if m.outcome == "split")
        unmapped     = sum(1 for m in mappings if m.outcome == "unmapped")
        ambiguous    = sum(1 for m in mappings if m.outcome == "ambiguous")
        needs_review = sum(1 for m in mappings if m.reviewer_action_required)
        mapped       = single_match + split
        coverage_pct = math.floor((mapped / total) * 100) if total else 0

        return MappingSummary(
            total=total,
            single_match=single_match,
            split=split,
            unmapped=unmapped,
            ambiguous=ambiguous,
            needs_review=needs_review,
            coverage_pct=coverage_pct,
        )

    def combine(self, summaries: dict[str, MappingSummary]) -> CombinedSummary:
        """Aggregate per-category summaries into a single CombinedSummary."""
        grand_total        = sum(s.total        for s in summaries.values())
        grand_mapped       = sum(s.single_match + s.split for s in summaries.values())
        grand_unmapped     = sum(s.unmapped     for s in summaries.values())
        grand_needs_review = sum(s.needs_review for s in summaries.values())
        overall_pct        = (
            math.floor(grand_mapped / grand_total * 100) if grand_total else 0
        )

        return CombinedSummary(
            total_categories=len(summaries),
            by_category=summaries,
            grand_total=grand_total,
            grand_mapped=grand_mapped,
            grand_unmapped=grand_unmapped,
            grand_needs_review=grand_needs_review,
            overall_coverage_pct=overall_pct,
        )
