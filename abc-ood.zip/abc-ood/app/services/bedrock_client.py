"""
app/services/bedrock_client.py
────────────────────────────────
BedrockClient — calls AWS Bedrock converse API and parses the JSON response.

Isolated from all other concerns: receives messages + config, returns
a list of parsed MappingRecord objects.
"""

import json
import time

from app.core.exceptions import BedrockCallError, MappingParseError
from app.core.logging import LoggerFactory
from app.models.mapping import MappingRecord, TransformationDetail


class BedrockClient:
    """
    Wraps the boto3 bedrock-runtime converse call.

    Responsibilities:
      - Build the Bedrock-specific request shape from OpenAI-style messages.
      - Call bedrock.converse() with inference config from prompt_config.yaml.
      - Strip markdown fences from the response text.
      - Parse the raw JSON array into validated MappingRecord objects.
    """

    def __init__(self, bedrock_client) -> None:
        self._client = bedrock_client
        self._log    = LoggerFactory.get(self.__class__.__name__)

    # ── Public interface ──────────────────────────────────────────

    def converse(
        self,
        messages:   list[dict],
        model_cfg:  dict,
    ) -> list[MappingRecord]:
        """
        Send the message list to Bedrock and return parsed MappingRecord list.

        Parameters
        ----------
        messages  : [{"role": "system"|"user", "content": "..."}]
        model_cfg : the model sub-dict from prompt_config.yaml
        """
        model_id     = model_cfg["model_id"]
        request      = self._build_request(messages, model_cfg)

        self._log.info("Calling Bedrock converse — model=%s", model_id)
        t0 = time.time()

        try:
            response = self._client.converse(modelId=model_id, **request)
        except Exception as exc:
            raise BedrockCallError(f"Bedrock converse failed: {exc}") from exc

        elapsed = time.time() - t0
        usage   = response.get("usage", {})
        self._log.info(
            "Response received %.2fs — in=%s out=%s tokens",
            elapsed,
            usage.get("inputTokens", "?"),
            usage.get("outputTokens", "?"),
        )

        raw_text = response["output"]["message"]["content"][0]["text"]
        return self._parse_response(raw_text)

    # ── Internal ──────────────────────────────────────────────────

    @staticmethod
    def _build_request(messages: list[dict], model_cfg: dict) -> dict:
        system_msgs = [m for m in messages if m["role"] == "system"]
        conv_msgs   = [m for m in messages if m["role"] != "system"]

        request: dict = {
            "messages": [
                {
                    "role":    m["role"],
                    "content": [{"type": "text", "text": m["content"]}],
                }
                for m in conv_msgs
            ],
            "inferenceConfig": {
                "maxTokens":   int(model_cfg["max_tokens"]),
                "temperature": float(model_cfg["temperature"]),
                "topP":        float(model_cfg["top_p"]),
            },
        }
        if system_msgs:
            request["system"] = [{"text": m["content"]} for m in system_msgs]
        return request

    def _parse_response(self, raw_text: str) -> list[MappingRecord]:
        cleaned = raw_text.strip().replace("```json", "").replace("```", "").strip()
        try:
            raw_list: list[dict] = json.loads(cleaned)
        except json.JSONDecodeError as exc:
            raise MappingParseError(
                f"LLM response is not valid JSON: {exc}\nRaw text (first 500 chars): {cleaned[:500]}"
            ) from exc

        records: list[MappingRecord] = []
        for item in raw_list:
            # Normalise the transformation sub-object
            t_raw = item.get("transformation") or {}
            item["transformation"] = TransformationDetail(**t_raw)
            records.append(MappingRecord(**item))

        self._log.info("Parsed %d mapping records", len(records))
        return records
