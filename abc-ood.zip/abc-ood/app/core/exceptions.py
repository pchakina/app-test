"""
app/core/exceptions.py
───────────────────────
Domain exception hierarchy.
All application exceptions inherit from SchemaMapperError so callers
can catch at any level of specificity they need.
"""

from fastapi import HTTPException
from fastapi.responses import JSONResponse


# ── Base ──────────────────────────────────────────────────────────

class SchemaMapperError(Exception):
    """Base class for all domain exceptions."""
    status_code: int = 500

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message

    def to_http(self) -> HTTPException:
        return HTTPException(status_code=self.status_code, detail=self.message)


# ── Configuration errors ──────────────────────────────────────────

class ConfigurationError(SchemaMapperError):
    """Raised when environment config or YAML config is invalid."""
    status_code = 500


class PromptConfigNotFoundError(ConfigurationError):
    """Raised when the prompt_config.yaml cannot be loaded from S3."""
    status_code = 404


# ── Source / schema errors ────────────────────────────────────────

class SourceFileError(SchemaMapperError):
    """Raised when the source file cannot be read or parsed."""
    status_code = 422


class CategoryNotFoundError(SchemaMapperError):
    """Raised when a requested category is not present in the source."""
    status_code = 404


class SchemaNotFoundError(SchemaMapperError):
    """Raised when a destination schema for a category cannot be found."""
    status_code = 404


class CategoryColumnMissingError(SourceFileError):
    """Raised when the category column is absent from the source file."""
    status_code = 422


# ── Bedrock / LLM errors ──────────────────────────────────────────

class BedrockCallError(SchemaMapperError):
    """Raised when the Bedrock converse API call fails."""
    status_code = 502


class MappingParseError(SchemaMapperError):
    """Raised when the LLM response cannot be parsed as valid JSON."""
    status_code = 502


# ── Output errors ─────────────────────────────────────────────────

class OutputWriteError(SchemaMapperError):
    """Raised when writing outputs to S3 fails."""
    status_code = 500


class OutputNotFoundError(SchemaMapperError):
    """Raised when a requested output file does not exist in S3."""
    status_code = 404


# ── FastAPI exception handler helper ─────────────────────────────

def domain_exception_handler(_request, exc: SchemaMapperError) -> JSONResponse:
    """
    Register with FastAPI:
        app.add_exception_handler(SchemaMapperError, domain_exception_handler)
    """
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.__class__.__name__, "detail": exc.message},
    )
