"""
app/core/logging.py
────────────────────
Centralised logging configuration.
Call LoggerFactory.configure() once at startup, then use
LoggerFactory.get(name) anywhere in the codebase.
"""

import logging
import sys
from app.core.config import get_config


class LoggerFactory:
    """
    Configures and vends named loggers.

    Usage
    -----
        LoggerFactory.configure()                    # call once in main.py
        log = LoggerFactory.get("schema_mapper")     # anywhere else
    """

    _configured: bool = False

    @classmethod
    def configure(cls) -> None:
        if cls._configured:
            return

        cfg     = get_config()
        level   = getattr(logging, cfg.log_level.upper(), logging.INFO)
        fmt     = "%(asctime)s [%(levelname)-8s] %(name)s — %(message)s"
        datefmt = "%Y-%m-%d %H:%M:%S"

        handlers: list[logging.Handler] = [
            logging.StreamHandler(sys.stdout),
            logging.FileHandler("schema_mapper.log", encoding="utf-8"),
        ]

        logging.basicConfig(
            level=level,
            format=fmt,
            datefmt=datefmt,
            handlers=handlers,
        )

        cls._configured = True

    @classmethod
    def get(cls, name: str) -> logging.Logger:
        if not cls._configured:
            cls.configure()
        return logging.getLogger(name)
