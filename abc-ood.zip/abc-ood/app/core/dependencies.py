"""
app/core/dependencies.py
─────────────────────────
FastAPI dependency injection wiring.
All collaborating objects are constructed here and injected via Depends().
This is the only place that wires concrete implementations together.
"""

from functools import lru_cache
from typing import Annotated

import boto3
from fastapi import Depends

from app.core.config import AppConfig, get_config
from app.repositories.config_repository import ConfigRepository
from app.repositories.schema_repository import SchemaRepository
from app.repositories.source_repository import SourceRepository
from app.repositories.output_repository import OutputRepository
from app.services.bedrock_client import BedrockClient
from app.services.prompt_builder import PromptBuilder
from app.services.mapping_summariser import MappingSummariser
from app.services.output_writer import OutputWriter
from app.services.mapping_pipeline import MappingPipeline
from app.utils.verification import VerificationEngine


# ── Boto3 sessions / clients ──────────────────────────────────────

@lru_cache(maxsize=1)
def get_s3_client(cfg: AppConfig = get_config()):
    session = boto3.Session(
        region_name=cfg.aws_region,
        profile_name=cfg.aws_profile or None,
    )
    return session.client("s3")


@lru_cache(maxsize=1)
def get_bedrock_client_raw(cfg: AppConfig = get_config()):
    session = boto3.Session(
        region_name=cfg.aws_region,
        profile_name=cfg.aws_profile or None,
    )
    return session.client("bedrock-runtime")


# ── Repositories ──────────────────────────────────────────────────

def get_config_repository(
    cfg: Annotated[AppConfig, Depends(get_config)],
) -> ConfigRepository:
    return ConfigRepository(s3_client=get_s3_client(), config=cfg)


def get_schema_repository(
    cfg: Annotated[AppConfig, Depends(get_config)],
) -> SchemaRepository:
    return SchemaRepository(s3_client=get_s3_client(), config=cfg)


def get_source_repository(
    cfg: Annotated[AppConfig, Depends(get_config)],
) -> SourceRepository:
    return SourceRepository(s3_client=get_s3_client(), config=cfg)


def get_output_repository(
    cfg: Annotated[AppConfig, Depends(get_config)],
) -> OutputRepository:
    return OutputRepository(s3_client=get_s3_client(), config=cfg)


# ── Services ──────────────────────────────────────────────────────

def get_bedrock_service(
    cfg: Annotated[AppConfig, Depends(get_config)],
) -> BedrockClient:
    return BedrockClient(bedrock_client=get_bedrock_client_raw())


def get_prompt_builder(
    config_repo: Annotated[ConfigRepository, Depends(get_config_repository)],
) -> PromptBuilder:
    return PromptBuilder(config_repo=config_repo)


def get_output_writer(
    output_repo: Annotated[OutputRepository, Depends(get_output_repository)],
    cfg: Annotated[AppConfig, Depends(get_config)],
) -> OutputWriter:
    return OutputWriter(output_repo=output_repo, config=cfg)


def get_mapping_pipeline(
    cfg:           Annotated[AppConfig,          Depends(get_config)],
    config_repo:   Annotated[ConfigRepository,   Depends(get_config_repository)],
    schema_repo:   Annotated[SchemaRepository,   Depends(get_schema_repository)],
    source_repo:   Annotated[SourceRepository,   Depends(get_source_repository)],
    bedrock:       Annotated[BedrockClient,       Depends(get_bedrock_service)],
    prompt_builder:Annotated[PromptBuilder,       Depends(get_prompt_builder)],
    output_writer: Annotated[OutputWriter,        Depends(get_output_writer)],
) -> MappingPipeline:
    return MappingPipeline(
        config         = cfg,
        config_repo    = config_repo,
        schema_repo    = schema_repo,
        source_repo    = source_repo,
        bedrock        = bedrock,
        prompt_builder = prompt_builder,
        summariser     = MappingSummariser(),
        output_writer  = output_writer,
    )


def get_verification_engine() -> VerificationEngine:
    return VerificationEngine()
