"""
app/core/config.py
──────────────────
Single source of truth for all environment-driven configuration.
Uses pydantic-settings so every variable is type-validated and documented.
"""

import json
from functools import lru_cache
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class AppConfig(BaseSettings):
    """
    All configuration is read from environment variables (or a .env file).
    Changing behaviour never requires editing Python code — only env vars.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Application ───────────────────────────────────────────────
    app_title:   str = Field(default="Healthcare Schema Mapper")
    app_version: str = Field(default="2.0.0")
    log_level:   str = Field(default="INFO")

    # ── AWS ───────────────────────────────────────────────────────
    aws_region:  str = Field(default="us-east-1")
    aws_profile: str | None = Field(default=None)

    # ── S3 ────────────────────────────────────────────────────────
    source_bucket: str = Field(default="your-source-bucket")
    output_bucket: str = Field(default="your-output-bucket")

    # ── S3 object keys ────────────────────────────────────────────
    source_key:        str = Field(default="templates/healthcare_providers.csv")
    prompt_config_key: str = Field(default="config/prompt_config.yaml")
    template_key:      str = Field(default="report_templates/mapping_review.html")
    dest_schema_key:   str = Field(default="config/destination_schema.json")

    # ── Category routing ──────────────────────────────────────────
    category_column: str = Field(
        default="source_category",
        description="Column name (or 0-based int index) identifying the provider category",
    )

    category_schema_map_raw: str = Field(
        default='{"PRACTITIONER":"config/practitioner_schema.json",'
                '"PRACTICE":"config/practice_schema.json",'
                '"FACILITY":"config/facility_schema.json"}',
        alias="CATEGORY_SCHEMA_MAP",
        description="JSON string mapping category name → S3 key of its destination schema",
    )

    @field_validator("category_schema_map_raw", mode="before")
    @classmethod
    def validate_json(cls, v: str) -> str:
        try:
            json.loads(v)
        except json.JSONDecodeError as exc:
            raise ValueError(f"CATEGORY_SCHEMA_MAP is not valid JSON: {exc}") from exc
        return v

    @property
    def category_schema_map(self) -> dict[str, str]:
        """Parsed dict: {category_name: s3_key}"""
        return json.loads(self.category_schema_map_raw)


@lru_cache(maxsize=1)
def get_config() -> AppConfig:
    """
    Return the singleton AppConfig instance.
    Use FastAPI's Depends(get_config) to inject into route handlers.
    """
    return AppConfig()
