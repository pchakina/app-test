"""
app/models/mapping.py
──────────────────────
Pydantic models for mapping requests, records, summaries and run results.
"""

from datetime import datetime
from pydantic import BaseModel, Field


# ── Per-column mapping record (LLM output) ────────────────────────

class TransformationDetail(BaseModel):
    type_cast:          str | None = None
    format_conversion:  str | None = None
    default_value:      str | None = None
    split_instruction:  str | None = None


class MappingRecord(BaseModel):
    """One row in the LLM's mapping output array."""
    source_column:          str
    outcome:                str   # single_match | split | unmapped | ambiguous
    destination_columns:    list[str]
    confidence:             str   # high | medium | low
    semantic_understanding: str   = ""
    mapping_rationale:      str   = ""
    ambiguity_candidates:   list[str] = Field(default_factory=list)
    transformation:         TransformationDetail = Field(default_factory=TransformationDetail)
    mandatory:              bool  = False
    reviewer_action_required: bool = False
    reviewer_priority:      str   = "low"


# ── Run-level summary ─────────────────────────────────────────────

class MappingSummary(BaseModel):
    """Coverage statistics for a single category mapping run."""
    total:        int
    single_match: int
    split:        int
    unmapped:     int
    ambiguous:    int
    needs_review: int
    coverage_pct: int


class CombinedSummary(BaseModel):
    """Aggregated statistics across all categories in a run."""
    total_categories:   int
    by_category:        dict[str, MappingSummary]
    grand_total:        int
    grand_mapped:       int
    grand_unmapped:     int
    grand_needs_review: int
    overall_coverage_pct: int


# ── Per-category result ───────────────────────────────────────────

class CategoryOutputKeys(BaseModel):
    json:  str
    excel: str
    html:  str


class CategoryResult(BaseModel):
    """Full result for one category in a mapping run."""
    category:    str
    summary:     MappingSummary
    output_keys: CategoryOutputKeys
    mappings:    list[MappingRecord]


# ── Full run result ───────────────────────────────────────────────

class MappingRunResult(BaseModel):
    """Top-level result returned by the pipeline and stored as combined JSON."""
    run_id:                str
    source_name:           str
    source_key:            str
    timestamp:             str
    generated_at:          datetime
    model_id:              str
    categories_processed:  list[str]
    combined_summary:      CombinedSummary
    combined_key:          str
    category_results:      dict[str, CategoryResult]


# ── API request / response models ────────────────────────────────

class RunMappingRequest(BaseModel):
    """Request body for POST /mappings/run"""
    source_key:       str | None = Field(default=None,
        description="Override SOURCE_KEY env var")
    categories:       list[str] | None = Field(default=None,
        description="Limit to these categories; null = all")
    category_column:  str | None = Field(default=None,
        description="Override CATEGORY_COLUMN env var")


class RunMappingResponse(BaseModel):
    """Lightweight response immediately returned by POST /mappings/run"""
    run_id:                str
    source_name:           str
    timestamp:             str
    categories_processed:  list[str]
    combined_key:          str
    combined_summary:      CombinedSummary
    output_keys_by_category: dict[str, CategoryOutputKeys]


class CategoryMappingResponse(BaseModel):
    """Response from GET /mappings/{run_id}/{category}"""
    run_id:      str
    category:    str
    summary:     MappingSummary
    output_keys: CategoryOutputKeys
    mappings:    list[MappingRecord]
