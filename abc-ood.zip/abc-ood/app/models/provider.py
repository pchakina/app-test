"""
app/models/provider.py
───────────────────────
Pydantic models representing provider source data and file metadata.
These are pure data containers with no business logic.
"""

from enum import StrEnum
from pydantic import BaseModel, Field


class ProviderCategory(StrEnum):
    """
    The three supported provider entity types.
    Extend here to add new categories — no other code change needed
    as long as the CATEGORY_SCHEMA_MAP env var is updated too.
    """
    PRACTITIONER = "PRACTITIONER"
    PRACTICE     = "PRACTICE"
    FACILITY     = "FACILITY"


class FileMeta(BaseModel):
    """Metadata about the source file as detected by the file reader."""
    file_type:    str            = Field(description="csv | xlsx | xls")
    header_row:   int            = Field(description="0-based index of the header row")
    skipped_rows: int            = Field(default=0)
    sheet:        str | None     = Field(default=None, description="Excel sheet name if applicable")
    source_key:   str            = Field(description="S3 key of the source file")


class SourceSplit(BaseModel):
    """
    Result of splitting the source file by provider category.
    Maps each category to the list of column headers detected.
    """
    headers:            list[str]                = Field(description="All column headers (excl. category col)")
    categories_found:   list[str]                = Field(description="Unique category values in the source")
    file_meta:          FileMeta


class ValidateSourceRequest(BaseModel):
    """Request body for POST /sources/validate"""
    source_key:      str        = Field(description="S3 key of the source file to validate")
    category_column: str | None = Field(default=None, description="Override the category column name")


class ValidateSourceResponse(BaseModel):
    """Response from POST /sources/validate"""
    source_key:       str
    file_meta:        FileMeta
    categories_found: list[str]
    column_count:     int
    headers:          list[str]
