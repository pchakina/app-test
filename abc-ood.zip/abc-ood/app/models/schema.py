"""
app/models/schema.py
─────────────────────
Pydantic models for destination schemas.
"""

from pydantic import BaseModel, Field


class DestinationField(BaseModel):
    """One column in a destination schema."""
    name:          str
    data_type:     str
    format:        str | None  = None
    mandatory:     bool        = False
    default_value: str | None  = None
    description:   str | None  = None


class DestinationSchema(BaseModel):
    """Full destination schema for one provider category."""
    category: str
    s3_key:   str
    fields:   list[DestinationField]

    @property
    def field_count(self) -> int:
        return len(self.fields)

    @property
    def mandatory_fields(self) -> list[DestinationField]:
        return [f for f in self.fields if f.mandatory]


class SchemaListResponse(BaseModel):
    """Response from GET /schemas"""
    count:      int
    categories: list[str]
    schemas:    list[dict]       # lightweight: {category, s3_key, field_count}


class SchemaDetailResponse(BaseModel):
    """Response from GET /schemas/{category}"""
    category:    str
    s3_key:      str
    field_count: int
    fields:      list[DestinationField]
