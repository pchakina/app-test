"""
app/utils/verification.py
──────────────────────────
VerificationEngine — runs automated health checks on a template configuration.

Pure utility: no I/O, no AWS, no state.
"""

from app.models.schema import DestinationSchema


class VerificationCheck:
    """Result of one health check."""

    def __init__(self, check_id: int, status: str, title: str, desc: str) -> None:
        self.check_id = check_id
        self.status   = status   # pass | warn | fail
        self.title    = title
        self.desc     = desc

    def to_dict(self) -> dict:
        return {
            "check_id": self.check_id,
            "status":   self.status,
            "title":    self.title,
            "desc":     self.desc,
        }


class VerificationResult:
    """Aggregated result from all health checks."""

    def __init__(self, checks: list[VerificationCheck], category: str) -> None:
        self.checks   = checks
        self.category = category

    @property
    def score(self) -> int:
        if not self.checks:
            return 0
        passed = sum(1 for c in self.checks if c.status == "pass")
        return round((passed / len(self.checks)) * 100)

    @property
    def grade(self) -> str:
        s = self.score
        if s >= 85: return "excellent"
        if s >= 60: return "good"
        return "needs_attention"

    @property
    def passed(self) -> int:
        return sum(1 for c in self.checks if c.status == "pass")

    @property
    def warnings(self) -> int:
        return sum(1 for c in self.checks if c.status == "warn")

    @property
    def failures(self) -> int:
        return sum(1 for c in self.checks if c.status == "fail")

    def to_dict(self) -> dict:
        return {
            "category":  self.category,
            "score":     self.score,
            "grade":     self.grade,
            "passed":    self.passed,
            "warnings":  self.warnings,
            "failures":  self.failures,
            "checks":    [c.to_dict() for c in self.checks],
        }


class VerificationEngine:
    """
    Runs a fixed suite of automated health checks against a destination schema
    and its associated source column list.

    Extend _checks() to add new validation rules without touching callers.
    """

    def verify(
        self,
        schema:         DestinationSchema,
        source_columns: list[str],
    ) -> VerificationResult:
        checks = self._run_checks(schema, source_columns)
        return VerificationResult(checks=checks, category=schema.category)

    # ── Check suite ───────────────────────────────────────────────

    def _run_checks(
        self,
        schema:         DestinationSchema,
        source_columns: list[str],
    ) -> list[VerificationCheck]:
        return [
            self._check_source_column_count(source_columns),
            self._check_destination_field_count(schema),
            self._check_mandatory_fields_present(schema, source_columns),
            self._check_no_blank_column_names(source_columns),
            self._check_column_name_length(source_columns),
            self._check_primary_key_candidate(source_columns),
            self._check_schema_has_descriptions(schema),
            self._check_mandatory_fields_have_descriptions(schema),
        ]

    # ── Individual checks ─────────────────────────────────────────

    @staticmethod
    def _check_source_column_count(cols: list[str]) -> VerificationCheck:
        n      = len(cols)
        status = "pass" if n >= 5 else "fail"
        return VerificationCheck(
            check_id = 1,
            status   = status,
            title    = "Source column count",
            desc     = f"{n} columns detected — minimum threshold of 5 {'met' if status == 'pass' else 'NOT met'}.",
        )

    @staticmethod
    def _check_destination_field_count(schema: DestinationSchema) -> VerificationCheck:
        n      = schema.field_count
        status = "pass" if n >= 3 else "warn"
        return VerificationCheck(
            check_id = 2,
            status   = status,
            title    = "Destination schema field count",
            desc     = f"{n} destination fields defined for {schema.category}.",
        )

    @staticmethod
    def _check_mandatory_fields_present(
        schema: DestinationSchema,
        source_columns: list[str],
    ) -> VerificationCheck:
        mandatory = [f.name for f in schema.fields if f.mandatory]
        src_lower = [c.lower() for c in source_columns]
        likely_covered = [
            f for f in mandatory
            if any(word in " ".join(src_lower) for word in f.lower().split("_"))
        ]
        ratio  = len(likely_covered) / len(mandatory) if mandatory else 1.0
        status = "pass" if ratio >= 0.7 else "warn"
        return VerificationCheck(
            check_id = 3,
            status   = status,
            title    = "Mandatory field coverage estimate",
            desc     = (
                f"{len(likely_covered)}/{len(mandatory)} mandatory destination fields "
                f"likely covered by source columns (keyword heuristic)."
            ),
        )

    @staticmethod
    def _check_no_blank_column_names(cols: list[str]) -> VerificationCheck:
        blanks = [i for i, c in enumerate(cols) if not c.strip()]
        status = "pass" if not blanks else "fail"
        return VerificationCheck(
            check_id = 4,
            status   = status,
            title    = "No blank column names",
            desc     = (
                "All column names are non-empty."
                if not blanks
                else f"Blank column names at positions: {blanks}."
            ),
        )

    @staticmethod
    def _check_column_name_length(cols: list[str]) -> VerificationCheck:
        long_cols = [c for c in cols if len(c) > 500]
        status    = "warn" if long_cols else "pass"
        return VerificationCheck(
            check_id = 5,
            status   = status,
            title    = "Column name length",
            desc     = (
                "All column names within reasonable length."
                if not long_cols
                else f"{len(long_cols)} column(s) exceed 500 characters — may truncate in some systems."
            ),
        )

    @staticmethod
    def _check_primary_key_candidate(cols: list[str]) -> VerificationCheck:
        src_lower = " ".join(c.lower() for c in cols)
        has_pk    = any(kw in src_lower for kw in ("npi", "identifier", " id", "_id", "code", "key"))
        status    = "pass" if has_pk else "warn"
        return VerificationCheck(
            check_id = 6,
            status   = status,
            title    = "Primary key candidate",
            desc     = (
                "At least one likely primary key column found (NPI, ID, code, key)."
                if has_pk
                else "No obvious primary key column — manual review recommended."
            ),
        )

    @staticmethod
    def _check_schema_has_descriptions(schema: DestinationSchema) -> VerificationCheck:
        with_desc  = sum(1 for f in schema.fields if f.description)
        total      = schema.field_count
        ratio      = with_desc / total if total else 0.0
        status     = "pass" if ratio >= 0.8 else "warn"
        return VerificationCheck(
            check_id = 7,
            status   = status,
            title    = "Schema field descriptions",
            desc     = f"{with_desc}/{total} destination fields have descriptions ({round(ratio*100)}%).",
        )

    @staticmethod
    def _check_mandatory_fields_have_descriptions(
        schema: DestinationSchema,
    ) -> VerificationCheck:
        mandatory_no_desc = [
            f.name for f in schema.fields if f.mandatory and not f.description
        ]
        status = "pass" if not mandatory_no_desc else "fail"
        return VerificationCheck(
            check_id = 8,
            status   = status,
            title    = "Mandatory fields have descriptions",
            desc     = (
                "All mandatory fields have descriptions."
                if not mandatory_no_desc
                else f"Mandatory fields without descriptions: {mandatory_no_desc}."
            ),
        )
