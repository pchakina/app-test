"""
app/utils/excel_builder.py
───────────────────────────
ExcelBuilder — builds a colour-coded openpyxl workbook from mapping records.

Pure utility class: no I/O, no AWS, no configuration.
Receives data, returns bytes.
"""

import io
from datetime import datetime

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from app.models.mapping import MappingRecord
from app.models.provider import FileMeta


class ExcelBuilder:
    """
    Converts a list of MappingRecord objects into a formatted Excel workbook.

    Produces two sheets:
      1. "Mapping Review"  — one row per source column, colour-coded by confidence
      2. "Source Info"     — run metadata (category, model, file details)
    """

    # Colour fills
    _FILL_GREEN  = PatternFill("solid", fgColor="C6EFCE")
    _FILL_AMBER  = PatternFill("solid", fgColor="FFEB9C")
    _FILL_RED    = PatternFill("solid", fgColor="FFC7CE")
    _FILL_HEADER = PatternFill("solid", fgColor="1F4E79")

    # Column widths (one per output column, in order)
    _COL_WIDTHS = [12, 55, 40, 14, 30, 12, 50, 28, 16, 30, 14, 40, 10, 14, 18, 40, 28]

    # ── Public interface ──────────────────────────────────────────

    def build(
        self,
        mappings:   list[MappingRecord],
        category:   str,
        source_key: str,
        file_meta:  FileMeta,
        model_id:   str,
    ) -> bytes:
        """
        Build the workbook and return raw bytes suitable for S3 upload.
        """
        rows = [self._to_row(m) for m in mappings]
        df   = pd.DataFrame(rows)
        buf  = io.BytesIO()

        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            df.to_excel(writer, index=False, sheet_name="Mapping Review")
            ws = writer.sheets["Mapping Review"]
            self._style_header_row(ws, len(df.columns))
            self._set_column_widths(ws)
            self._style_data_rows(ws, mappings, len(df.columns))
            self._add_source_info_sheet(
                writer, category, source_key, file_meta, len(mappings), model_id
            )
            ws.freeze_panes = "C2"

        buf.seek(0)
        return buf.getvalue()

    # ── Row conversion ────────────────────────────────────────────

    @staticmethod
    def _to_row(m: MappingRecord) -> dict:
        t = m.transformation
        return {
            "Reviewer priority":     m.reviewer_priority.upper(),
            "Source column":         m.source_column,
            "AI understanding":      m.semantic_understanding,
            "Outcome":               m.outcome,
            "Destination column(s)": ", ".join(m.destination_columns) or "— UNMAPPED —",
            "Confidence":            m.confidence,
            "Mapping rationale":     m.mapping_rationale,
            "Ambiguity candidates":  ", ".join(m.ambiguity_candidates),
            "Type cast":             t.type_cast         or "",
            "Format conversion":     t.format_conversion or "",
            "Default value":         t.default_value     or "",
            "Split instruction":     t.split_instruction or "",
            "Mandatory":             "YES" if m.mandatory               else "no",
            "Action required":       "YES" if m.reviewer_action_required else "",
            "Reviewer approved":     "",
            "Reviewer comments":     "",
            "Override destination":  "",
        }

    # ── Styling helpers ───────────────────────────────────────────

    def _row_fill(self, m: MappingRecord) -> PatternFill:
        if m.outcome in ("unmapped", "ambiguous") or m.confidence == "low":
            return self._FILL_RED
        if m.confidence == "medium" or m.outcome == "split":
            return self._FILL_AMBER
        return self._FILL_GREEN

    def _style_header_row(self, ws, col_count: int) -> None:
        for cell in ws[1]:
            cell.fill      = self._FILL_HEADER
            cell.font      = Font(color="FFFFFF", bold=True, size=11)
            cell.alignment = Alignment(wrap_text=True, vertical="center")

    def _set_column_widths(self, ws) -> None:
        for i, width in enumerate(self._COL_WIDTHS, 1):
            ws.column_dimensions[get_column_letter(i)].width = width

    def _style_data_rows(
        self, ws, mappings: list[MappingRecord], col_count: int
    ) -> None:
        for idx, m in enumerate(mappings, 2):
            fill = self._row_fill(m)
            for col in range(1, col_count + 1):
                cell            = ws.cell(row=idx, column=col)
                cell.fill       = fill
                cell.alignment  = Alignment(wrap_text=True, vertical="top")
            ws.row_dimensions[idx].height = 60

    def _add_source_info_sheet(
        self,
        writer,
        category:   str,
        source_key: str,
        file_meta:  FileMeta,
        total_cols: int,
        model_id:   str,
    ) -> None:
        ws = writer.book.create_sheet("Source Info")
        info_rows = [
            ("Category",      category),
            ("Source file",   source_key),
            ("File type",     file_meta.file_type.upper()),
            ("Sheet",         file_meta.sheet or "N/A"),
            ("Header row",    file_meta.header_row),
            ("Skipped rows",  file_meta.skipped_rows),
            ("Total columns", total_cols),
            ("Generated at",  datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            ("Model",         model_id),
        ]
        for r, (label, value) in enumerate(info_rows, 1):
            ws.cell(row=r, column=1, value=label).font = Font(bold=True)
            ws.cell(row=r, column=2, value=str(value))
        ws.column_dimensions["A"].width = 20
        ws.column_dimensions["B"].width = 60
