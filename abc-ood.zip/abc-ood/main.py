"""
main.py
────────
FastAPI application entry point.

Run locally:
    uvicorn main:app --reload --port 8000

Swagger UI : http://localhost:8000/docs
ReDoc      : http://localhost:8000/redoc
OpenAPI    : http://localhost:8000/openapi.json
"""

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.router import api_router
from app.core.config import get_config
from app.core.exceptions import SchemaMapperError, domain_exception_handler
from app.core.logging import LoggerFactory


# ── Lifespan (startup / shutdown) ────────────────────────────────

@asynccontextmanager
async def lifespan(_app: FastAPI):
    # Startup
    LoggerFactory.configure()
    log = LoggerFactory.get("main")
    cfg = get_config()
    log.info("Starting %s v%s  [region=%s]", cfg.app_title, cfg.app_version, cfg.aws_region)
    log.info("Source bucket: %s   Output bucket: %s", cfg.source_bucket, cfg.output_bucket)
    log.info("Categories configured: %s", list(cfg.category_schema_map.keys()))
    yield
    # Shutdown (add cleanup here if needed)
    log.info("Shutdown complete.")


# ── App factory ───────────────────────────────────────────────────

def create_app() -> FastAPI:
    cfg = get_config()

    app = FastAPI(
        title       = cfg.app_title,
        version     = cfg.app_version,
        description = (
            "## Healthcare Provider Schema Mapper\n\n"
            "AI-powered ETL schema mapping for healthcare provider data "
            "(Practitioner, Practice, Facility) using AWS Bedrock.\n\n"
            "### Key capabilities\n"
            "- Multi-category source file support (single CSV → 3 destination schemas)\n"
            "- Bedrock converse API with configurable model (Claude, Gemma, Llama)\n"
            "- JSON + Excel + HTML output per category\n"
            "- Automated schema health verification\n"
        ),
        lifespan    = lifespan,
        docs_url    = "/docs",
        redoc_url   = "/redoc",
    )

    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Domain exception handler — converts SchemaMapperError → clean JSON response
    app.add_exception_handler(SchemaMapperError, domain_exception_handler)  # type: ignore[arg-type]

    # Routers
    app.include_router(api_router)

    return app


app = create_app()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
