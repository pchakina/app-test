"""
shared/base_classes.py
───────────────────────
Abstract base classes that define the contracts every concrete class must fulfill.
Uses ABC + abstractmethod to enforce the interface at instantiation time.

Hierarchy:
  BaseComponent
    ├── BaseAgent          (all agent layer workers)
    │     ├── BaseSpecialistAgent
    │     │     ├── PractitionerAgent
    │     │     └── FacilityAgent
    │     ├── IntentRouterAgent
    │     └── SynthesisAgent
    ├── BaseTool           (all tools layer tools)
    │     ├── ProviderLookupTool
    │     ├── FacilityLookupTool
    │     └── NpiValidationTool
    └── BaseRegistry       (registries in each layer)
          ├── AgentRegistry
          └── ToolRegistry
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any, Optional

from shared.models import (
    AgentBlueprint, AuditEntry, ToolBlueprint, ToolResult, AgentTaskResult
)


# ── Root ──────────────────────────────────────────────────────────────

class BaseComponent(ABC):
    """
    Root base for every class in the system.
    Provides: logger, audit helper, and name property.
    """

    def __init__(self, name: str, audit_log: "AuditLog") -> None:
        self._name = name
        self._audit = audit_log
        self._logger = logging.getLogger(f"provider_agent.{name}")

    @property
    def name(self) -> str:
        return self._name

    def _log(self, action: str, details: dict, status: str = "ok") -> None:
        """Write one audit entry and also emit a logger line."""
        entry = AuditEntry(
            layer=self._layer_name(),
            component=self._name,
            action=action,
            details=details,
            status=status,
        )
        self._audit.write(entry)
        self._logger.info("[%s] %s — %s", self._name, action, details)

    @abstractmethod
    def _layer_name(self) -> str:
        """Return 'tools' | 'agent' | 'app' for audit entries."""

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self._name!r})"


# ── Tool Base ─────────────────────────────────────────────────────────

class BaseTool(BaseComponent, ABC):
    """
    Base for every tool in the Tools Layer (MCP Server).
    Each concrete tool owns one ToolBlueprint and one execute() method.
    """

    def __init__(self, blueprint: ToolBlueprint, audit_log: "AuditLog") -> None:
        super().__init__(blueprint.tool_name, audit_log)
        self._blueprint = blueprint

    @property
    def blueprint(self) -> ToolBlueprint:
        return self._blueprint

    @abstractmethod
    def execute(self, **kwargs) -> ToolResult:
        """Run the tool synchronously and return a ToolResult."""

    def _layer_name(self) -> str:
        return "tools"

    def _check_access(self, caller: str) -> None:
        if not self._blueprint.is_accessible_by(caller):
            raise PermissionError(
                f"Agent '{caller}' is not authorised to call tool '{self._name}'. "
                f"Allowed: {self._blueprint.accessible_by}"
            )


# ── Agent Base ────────────────────────────────────────────────────────

class BaseAgent(BaseComponent, ABC):
    """
    Base for every agent in the Agent Layer.
    Each concrete agent owns one AgentBlueprint.
    """

    def __init__(self, blueprint: AgentBlueprint, audit_log: "AuditLog") -> None:
        super().__init__(blueprint.name, audit_log)
        self._blueprint = blueprint

    @property
    def blueprint(self) -> AgentBlueprint:
        return self._blueprint

    @abstractmethod
    async def run(self, question: str, **kwargs) -> Any:
        """Execute this agent's task asynchronously."""

    def _layer_name(self) -> str:
        return "agent"


class BaseSpecialistAgent(BaseAgent, ABC):
    """
    Specialist domain agents (PDM agents in diagram).
    They call a specific tool in the Tools Layer via HTTP.
    """

    def __init__(
        self,
        blueprint: AgentBlueprint,
        tools_base_url: str,
        audit_log: "AuditLog",
    ) -> None:
        super().__init__(blueprint, audit_log)
        self._tools_base = tools_base_url

    @property
    @abstractmethod
    def tool_endpoint(self) -> str:
        """The Tools Layer endpoint this agent calls, e.g. /tools/lookup_provider"""

    async def run(self, question: str, **kwargs) -> ToolResult:
        import httpx
        self._log("start", {"question": question})
        caller = kwargs.get("caller", self._name)
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                f"{self._tools_base}{self.tool_endpoint}",
                params={"query": question, "caller": caller},
            )
            raw = resp.json()
        result = ToolResult(
            tool_name=self._name,
            records=raw.get("results", []),
        )
        self._log("tool_result", {"count": result.count})
        return result


# ── Registry Base ─────────────────────────────────────────────────────

class BaseRegistry(BaseComponent, ABC):
    """
    Base for registries in each layer.
    Holds blueprints and supports discovery (the /discover endpoint pattern).
    """

    def __init__(self, name: str, audit_log: "AuditLog") -> None:
        super().__init__(name, audit_log)
        self._registry: dict[str, Any] = {}

    def register(self, key: str, item: Any) -> None:
        self._registry[key] = item
        self._log("registered", {"key": key, "type": type(item).__name__})

    def get(self, key: str) -> Optional[Any]:
        return self._registry.get(key)

    def all(self) -> dict[str, Any]:
        return dict(self._registry)

    def discover(self) -> list[dict]:
        self._log("discover", {"count": len(self._registry)})
        return [
            vars(v.blueprint) if hasattr(v, "blueprint") else vars(v)
            for v in self._registry.values()
        ]

    def _layer_name(self) -> str:
        return "registry"

    def __len__(self) -> int:
        return len(self._registry)

    def __contains__(self, key: str) -> bool:
        return key in self._registry


# ── LLM Base ──────────────────────────────────────────────────────────

class BaseLLMClient(ABC):
    """
    Abstract LLM client. Concrete implementations swap the backend
    (Bedrock, Ollama, OpenAI-compat) without touching any agent code.
    """

    @property
    @abstractmethod
    def model_id(self) -> str:
        """The model identifier string."""

    @abstractmethod
    def chat_sync(
        self,
        user_message: str,
        system_prompt: Optional[str] = None,
        conversation_history: Optional[list] = None,
    ) -> str:
        """Synchronous inference."""

    async def chat(
        self,
        user_message: str,
        system_prompt: Optional[str] = None,
        conversation_history: Optional[list] = None,
    ) -> str:
        """Async inference — default wraps chat_sync in a thread pool."""
        import asyncio
        from functools import partial
        loop = asyncio.get_event_loop()
        fn = partial(self.chat_sync, user_message, system_prompt, conversation_history)
        return await loop.run_in_executor(None, fn)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(model={self.model_id!r})"


# ── Lazy import to avoid circular — AuditLog imported where used ──────
from shared.audit_log import AuditLog  # noqa: E402
