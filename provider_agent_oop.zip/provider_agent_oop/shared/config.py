"""
shared/config.py
─────────────────
ConfigLoader — loads YAML with env-var overrides.
Exposed as a class so it can be subclassed or mocked in tests.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Optional

import yaml

_DEFAULT_PATH = Path(__file__).resolve().parent.parent / "config" / "config.yaml"


class ConfigLoader:
    """
    Loads a YAML config file and applies environment variable overrides.

    Env-var convention:  SECTION__KEY=value  overrides  cfg[section][key]
    Example:  BEDROCK__MODEL_ID=google.gemma-3-12b-it
              AWS__REGION=us-west-2
    """

    def __init__(self, path: Optional[Path | str] = None) -> None:
        self._path = Path(path) if path else _DEFAULT_PATH
        self._data: dict[str, Any] = {}

    # ── Load ───────────────────────────────────────────────────────────

    def load(self) -> dict[str, Any]:
        if self._path.exists():
            with open(self._path) as f:
                self._data = yaml.safe_load(f) or {}
        self._apply_env_overrides()
        return self._data

    def _apply_env_overrides(self) -> None:
        for key, val in os.environ.items():
            if "__" not in key:
                continue
            parts = key.lower().split("__")
            node = self._data
            for part in parts[:-1]:
                node = node.setdefault(part, {})
            leaf = parts[-1]
            node[leaf] = self._coerce(val)

    @staticmethod
    def _coerce(value: str) -> Any:
        if value.lower() in ("true", "false"):
            return value.lower() == "true"
        try:
            return int(value)
        except ValueError:
            pass
        try:
            return float(value)
        except ValueError:
            pass
        return value

    # ── Section accessors ──────────────────────────────────────────────

    def get(self, section: str, default: Any = None) -> Any:
        return self._data.get(section, default or {})

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __repr__(self) -> str:
        return f"ConfigLoader(path={self._path}, sections={list(self._data.keys())})"

    # ── Factory ────────────────────────────────────────────────────────

    @classmethod
    def from_path(cls, path: str) -> "ConfigLoader":
        loader = cls(path)
        loader.load()
        return loader

    @classmethod
    def load_default(cls) -> dict[str, Any]:
        loader = cls()
        return loader.load()
