"""
shared/audit_log.py
────────────────────
Centralised Audit Log — the "Status Service" from the diagram.
AuditLog is a class (not module-level functions) so it can be
dependency-injected into every component and tested in isolation.
"""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Optional

from shared.models import AuditEntry


class AuditLog:
    """
    Singleton-compatible audit log.
    Writes to a rotating .log file and emits structured JSON lines.
    Injected into every BaseComponent subclass.
    """

    _instance: Optional["AuditLog"] = None

    def __init__(
        self,
        log_dir: str = "logs",
        log_file: str = "audit.log",
        level: str = "INFO",
        console: bool = True,
    ) -> None:
        self._entries: list[AuditEntry] = []
        self._log_path = Path(log_dir) / log_file
        os.makedirs(log_dir, exist_ok=True)

        fmt = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(message)s",
            datefmt="%H:%M:%S",
        )
        self._logger = logging.getLogger("audit")
        self._logger.setLevel(getattr(logging, level.upper(), logging.INFO))
        self._logger.propagate = False

        if not self._logger.handlers:
            fh = logging.FileHandler(self._log_path)
            fh.setFormatter(fmt)
            self._logger.addHandler(fh)
            if console:
                ch = logging.StreamHandler()
                ch.setFormatter(fmt)
                self._logger.addHandler(ch)

    # ── Factory ────────────────────────────────────────────────────────

    @classmethod
    def from_config(cls, cfg: dict) -> "AuditLog":
        """Build an AuditLog from the application config dict."""
        log_cfg = cfg.get("logging", {})
        return cls(
            log_dir=log_cfg.get("log_dir", "logs"),
            log_file=log_cfg.get("log_filename", "audit.log"),
            level=log_cfg.get("level", "INFO"),
            console=log_cfg.get("console", True),
        )

    @classmethod
    def get_default(cls) -> "AuditLog":
        """Return (or create) the process-wide default instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    # ── Write ──────────────────────────────────────────────────────────

    def write(self, entry: AuditEntry) -> None:
        self._entries.append(entry)
        line = json.dumps({
            "ts":        entry.created_at,
            "layer":     entry.layer,
            "component": entry.component,
            "action":    entry.action,
            "status":    entry.status,
            **entry.details,
        })
        self._logger.info(line)
        with open(self._log_path, "a") as f:
            f.write(line + "\n")

    # ── Query ──────────────────────────────────────────────────────────

    def all(self) -> list[dict]:
        return [e.to_dict() for e in self._entries]

    def filter(
        self,
        layer: Optional[str] = None,
        component: Optional[str] = None,
        action: Optional[str] = None,
    ) -> list[AuditEntry]:
        results = self._entries
        if layer:
            results = [e for e in results if e.layer == layer]
        if component:
            results = [e for e in results if e.component == component]
        if action:
            results = [e for e in results if e.action == action]
        return results

    @property
    def entry_count(self) -> int:
        return len(self._entries)

    def __repr__(self) -> str:
        return f"AuditLog(entries={self.entry_count}, path={self._log_path})"
