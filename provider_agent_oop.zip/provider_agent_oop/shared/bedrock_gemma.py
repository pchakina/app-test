"""
shared/bedrock_gemma.py
────────────────────────
BedrockGemmaClient — Google Gemma 3 12B IT via AWS Bedrock.
Extends BaseLLMClient. Delegates all AWS auth to AWSSessionFactory.
"""
from __future__ import annotations

import logging
from typing import Optional

from botocore.exceptions import ClientError, NoCredentialsError

from shared.aws_session import AWSSessionFactory
from shared.base_classes import BaseLLMClient

logger = logging.getLogger("bedrock_gemma")
_DEFAULT_MODEL  = "google.gemma-3-12b-it"
_DEFAULT_REGION = "us-east-1"


class BedrockGemmaClient(BaseLLMClient):
    """
    AWS Bedrock client for Google Gemma 3 12B IT.

    WHY: Concrete LLM implementation extending BaseLLMClient.
         Agents never import boto3 directly — they use this class.
         AWS auth fully delegated to AWSSessionFactory (SSO / static / IAM).
    """

    def __init__(
        self,
        model_id: str = _DEFAULT_MODEL,
        max_tokens: int = 512,
        temperature: float = 0.3,
        session_factory: Optional[AWSSessionFactory] = None,
    ) -> None:
        self._model_id    = model_id
        self._max_tokens  = max_tokens
        self._temperature = temperature
        self._factory     = session_factory or AWSSessionFactory()
        self._client      = self._build_client()

    @classmethod
    def from_config(cls, cfg: dict) -> "BedrockGemmaClient":
        b       = cfg.get("bedrock", {})
        factory = AWSSessionFactory.from_config(cfg)
        return cls(
            model_id        = b.get("model_id", _DEFAULT_MODEL),
            max_tokens      = b.get("max_tokens", 512),
            temperature     = b.get("temperature", 0.3),
            session_factory = factory,
        )

    @property
    def model_id(self) -> str:
        return self._model_id

    @property
    def region(self) -> str:
        return self._factory.region

    @property
    def auth_mode(self) -> str:
        return self._factory.auth_mode

    def chat_sync(
        self,
        user_message: str,
        system_prompt: Optional[str] = None,
        conversation_history: Optional[list] = None,
    ) -> str:
        if not self._client:
            return "[Bedrock client not initialised — check AWS credentials]"

        messages = list(conversation_history or [])
        messages.append({"role": "user", "content": [{"text": user_message}]})
        kwargs: dict = {
            "modelId":         self._model_id,
            "messages":        messages,
            "inferenceConfig": {"maxTokens": self._max_tokens, "temperature": self._temperature},
        }
        if system_prompt:
            kwargs["system"] = [{"text": system_prompt}]

        try:
            response = self._client.converse(**kwargs)
            content  = response["output"]["message"]["content"]
            text     = " ".join(b["text"] for b in content if "text" in b)
            return text.strip()
        except NoCredentialsError:
            msg = (f"[No AWS credentials — mode was '{self.auth_mode}'. "
                   "For SSO run: aws sso login --profile <profile>]")
            logger.error(msg); return msg
        except ClientError as exc:
            code = exc.response["Error"]["Code"]
            msg  = exc.response["Error"]["Message"]
            logger.error("Bedrock %s: %s", code, msg)
            return self._handle_client_error(code, msg)
        except Exception as exc:
            logger.error("Bedrock error: %s", exc)
            return f"[Unexpected error: {exc}]"

    def _build_client(self):
        try:
            session = self._factory.build()
            client  = session.client("bedrock-runtime", region_name=self._factory.region)
            logger.info("BedrockGemmaClient ready — model=%s auth=%s", self._model_id, self._factory.auth_mode)
            return client
        except Exception as exc:
            logger.error("Failed to build Bedrock client: %s", exc)
            return None

    def _handle_client_error(self, code: str, msg: str) -> str:
        return {
            "AccessDeniedException":  f"[Access denied to {self._model_id} — enable in Bedrock console]",
            "ValidationException":    f"[Validation error: {msg}]",
            "ThrottlingException":    "[Bedrock rate limit — retry shortly]",
            "ModelNotReadyException": "[Model warming up — retry shortly]",
        }.get(code, f"[Bedrock error {code}: {msg}]")

    @staticmethod
    def user_turn(text: str) -> dict:
        return {"role": "user", "content": [{"text": text}]}

    @staticmethod
    def assistant_turn(text: str) -> dict:
        return {"role": "assistant", "content": [{"text": text}]}

    def __repr__(self) -> str:
        return (f"BedrockGemmaClient(model={self._model_id!r}, "
                f"auth={self._factory.auth_mode!r}, region={self.region!r})")
