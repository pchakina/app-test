"""
shared/aws_session.py
──────────────────────
AWSSessionFactory — single class that handles all three AWS auth modes:
  1. AWS SSO  (profile from ~/.aws/config)
  2. Static credentials  (access_key_id + secret_access_key)
  3. IAM Role  (automatic on EC2 / ECS / Lambda)

WHY THIS CLASS EXISTS:
  Without it, every class that needs a boto3 client would have to
  repeat auth logic. AWSSessionFactory encapsulates it once and
  is injected into BedrockGemmaClient, future S3 clients, etc.

  SSO flow:
    1. User runs: aws sso login --profile <profile>
    2. ~/.aws/config has [profile <name>] with sso_start_url etc.
    3. boto3.Session(profile_name=<name>) picks it up automatically.
    4. AWSSessionFactory.build() does exactly that when sso.enabled=true.
"""
from __future__ import annotations

import logging
from typing import Optional

import boto3
from botocore.exceptions import ProfileNotFound, NoCredentialsError

logger = logging.getLogger("aws_session")


class AWSSessionFactory:
    """
    Builds a boto3.Session using whichever auth mode is configured.

    Priority order (mirrors boto3's own credential chain):
      1. SSO profile  (if sso.enabled = true in config)
      2. Static keys  (if access_key_id is set)
      3. Default boto3 chain  (env vars → ~/.aws/credentials → IAM role)

    Usage:
        factory = AWSSessionFactory.from_config(cfg)
        session = factory.build()
        client  = session.client("bedrock-runtime")
    """

    def __init__(
        self,
        region: str = "us-east-1",
        sso_enabled: bool = False,
        sso_profile: str = "",
        access_key_id: Optional[str] = None,
        secret_access_key: Optional[str] = None,
        session_token: Optional[str] = None,
    ) -> None:
        self._region            = region
        self._sso_enabled       = sso_enabled
        self._sso_profile       = sso_profile
        self._access_key_id     = access_key_id or None
        self._secret_access_key = secret_access_key or None
        self._session_token     = session_token or None
        self._auth_mode         = self._detect_mode()

    # ── Factory ────────────────────────────────────────────────────────

    @classmethod
    def from_config(cls, cfg: dict) -> "AWSSessionFactory":
        """Build from a loaded config dict."""
        aws = cfg.get("aws", {})
        sso = aws.get("sso", {})
        return cls(
            region            = aws.get("region", "us-east-1"),
            sso_enabled       = sso.get("enabled", False),
            sso_profile       = sso.get("profile", ""),
            access_key_id     = aws.get("access_key_id") or None,
            secret_access_key = aws.get("secret_access_key") or None,
            session_token     = aws.get("session_token") or None,
        )

    # ── Build session ──────────────────────────────────────────────────

    def build(self) -> boto3.Session:
        """
        Build and return a boto3.Session using the configured auth mode.
        Raises EnvironmentError if SSO profile is not found.
        """
        if self._auth_mode == "sso":
            return self._build_sso_session()
        elif self._auth_mode == "static":
            return self._build_static_session()
        else:
            return self._build_default_session()

    def client(self, service: str, region: Optional[str] = None) -> object:
        """Convenience: build session and immediately return a service client."""
        return self.build().client(service, region_name=region or self._region)

    # ── Auth mode builders ─────────────────────────────────────────────

    def _build_sso_session(self) -> boto3.Session:
        logger.info("AWS auth: SSO profile '%s'", self._sso_profile)
        try:
            session = boto3.Session(
                profile_name=self._sso_profile,
                region_name=self._region,
            )
            # Eagerly validate credentials so we fail fast with a clear message
            creds = session.get_credentials()
            if creds is None:
                raise NoCredentialsError()
            resolved = creds.resolve_frozen()
            logger.info(
                "SSO session active — account: %s, token type: %s",
                getattr(resolved, "account_id", "unknown"),
                type(creds).__name__,
            )
            return session
        except ProfileNotFound:
            raise EnvironmentError(
                f"AWS SSO profile '{self._sso_profile}' not found in ~/.aws/config.\n"
                f"Run:  aws configure sso --profile {self._sso_profile}\n"
                f"Then: aws sso login --profile {self._sso_profile}"
            )
        except NoCredentialsError:
            raise EnvironmentError(
                f"SSO profile '{self._sso_profile}' exists but has no active credentials.\n"
                f"Run:  aws sso login --profile {self._sso_profile}"
            )

    def _build_static_session(self) -> boto3.Session:
        logger.info("AWS auth: static credentials (access key)")
        kwargs: dict = {
            "region_name":            self._region,
            "aws_access_key_id":      self._access_key_id,
            "aws_secret_access_key":  self._secret_access_key,
        }
        if self._session_token:
            kwargs["aws_session_token"] = self._session_token
        return boto3.Session(**kwargs)

    def _build_default_session(self) -> boto3.Session:
        logger.info("AWS auth: default boto3 chain (env vars / ~/.aws / IAM role)")
        return boto3.Session(region_name=self._region)

    # ── Helpers ────────────────────────────────────────────────────────

    def _detect_mode(self) -> str:
        if self._sso_enabled and self._sso_profile:
            return "sso"
        if self._access_key_id and self._secret_access_key:
            return "static"
        return "default"

    @property
    def auth_mode(self) -> str:
        return self._auth_mode

    @property
    def region(self) -> str:
        return self._region

    def __repr__(self) -> str:
        if self._auth_mode == "sso":
            detail = f"profile={self._sso_profile!r}"
        elif self._auth_mode == "static":
            detail = f"key=***{(self._access_key_id or '')[-4:]}"
        else:
            detail = "default-chain"
        return f"AWSSessionFactory(mode={self._auth_mode!r}, {detail}, region={self._region!r})"
