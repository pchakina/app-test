"""
shared/mcp_protocol.py
───────────────────────
Model Context Protocol (MCP) implementation.

What is MCP and why do we need it?
────────────────────────────────────
MCP is the standard protocol that lets LLM agents discover and call
external tools at runtime — without hard-coding which tools exist.

In the diagram this is the "Tools Registry of HS Provider Org (MCP Server)"
box with its blueprint:
  ▸ Tool capability / propose
  ▸ Input schema
  ▸ Which agent(s) can access the tool
  ▸ Human Approval Requirement
  ▸ Which team own the tool

Without MCP:  agents know tool URLs at import time (brittle, not scalable)
With MCP:     agents call /mcp/list_tools at startup, get live tool schemas,
              then call /mcp/call_tool with structured JSON — LLM decides
              which tool to use and what params to pass.

Classes in this file:
  MCPToolSchema       — the JSON Schema contract for one tool's inputs
  MCPToolDefinition   — full tool spec (name + description + schema + access)
  MCPListToolsResponse — response envelope for /mcp/list_tools
  MCPCallToolRequest  — request envelope for /mcp/call_tool
  MCPCallToolResponse — response envelope from /mcp/call_tool
  MCPClient           — HTTP client that agents use to speak MCP
  MCPRegistry         — server-side registry that backs the MCP endpoints
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx

logger = logging.getLogger("mcp")


# ══════════════════════════════════════════════════════════════════════
# MCP Data Contracts  (the "schema" layer of the protocol)
# ══════════════════════════════════════════════════════════════════════

@dataclass
class MCPToolSchema:
    """
    JSON Schema for a single tool's input parameters.
    Tells the LLM exactly what fields to populate when calling a tool.

    WHY: The LLM reads this schema at runtime to know what JSON to generate.
         Without a schema the LLM would have to guess parameter names.
    """
    type: str = "object"
    properties: dict[str, dict] = field(default_factory=dict)
    required: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "type":       self.type,
            "properties": self.properties,
            "required":   self.required,
        }

    @classmethod
    def simple_string(cls, param: str, description: str) -> "MCPToolSchema":
        """Factory: single string parameter tool schema."""
        return cls(
            properties={param: {"type": "string", "description": description}},
            required=[param],
        )

    def __repr__(self) -> str:
        return f"MCPToolSchema(params={list(self.properties.keys())})"


@dataclass
class MCPToolDefinition:
    """
    Full MCP tool specification — what the agent registry returns for each tool.

    WHY: Agents call /mcp/list_tools and receive a list of these.
         The LLM uses name + description to pick the right tool,
         then uses input_schema to generate the call arguments.
    """
    name: str
    description: str
    input_schema: MCPToolSchema
    accessible_by: list[str] = field(default_factory=list)
    owner_team: str = ""
    requires_human_approval: bool = False

    def to_dict(self) -> dict:
        return {
            "name":                    self.name,
            "description":             self.description,
            "inputSchema":             self.input_schema.to_dict(),
            "accessibleBy":            self.accessible_by,
            "ownerTeam":               self.owner_team,
            "requiresHumanApproval":   self.requires_human_approval,
        }

    def is_accessible_by(self, agent: str) -> bool:
        return agent in self.accessible_by

    def __repr__(self) -> str:
        return (
            f"MCPToolDefinition(name={self.name!r}, "
            f"approval={self.requires_human_approval})"
        )


@dataclass
class MCPListToolsResponse:
    """
    Response envelope for GET /mcp/list_tools.

    WHY: Standardised wrapper so every MCP client can parse the same shape,
         regardless of which MCP server it talks to.
    """
    tools: list[MCPToolDefinition] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"tools": [t.to_dict() for t in self.tools]}

    def find(self, name: str) -> Optional[MCPToolDefinition]:
        return next((t for t in self.tools if t.name == name), None)

    def __repr__(self) -> str:
        return f"MCPListToolsResponse(tools={[t.name for t in self.tools]})"


@dataclass
class MCPCallToolRequest:
    """
    Request envelope for POST /mcp/call_tool.

    WHY: Uniform call structure — name tells the server which tool,
         arguments is the JSON the LLM generated from the schema.
    """
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)
    caller: str = "unknown"

    def to_dict(self) -> dict:
        return {"name": self.name, "arguments": self.arguments, "caller": self.caller}

    def __repr__(self) -> str:
        return f"MCPCallToolRequest(name={self.name!r}, caller={self.caller!r})"


@dataclass
class MCPCallToolResponse:
    """
    Response envelope for POST /mcp/call_tool.

    WHY: Standardised shape — isError flag lets agents handle failures
         without parsing error strings. content holds the tool output.
    """
    content: list[dict] = field(default_factory=list)
    is_error: bool = False
    error_message: str = ""

    @classmethod
    def success(cls, data: Any) -> "MCPCallToolResponse":
        return cls(content=[{"type": "json", "data": data}])

    @classmethod
    def error(cls, msg: str) -> "MCPCallToolResponse":
        return cls(is_error=True, error_message=msg)

    def first_data(self) -> Any:
        """Return the first content block's data, or None."""
        return self.content[0]["data"] if self.content else None

    def to_dict(self) -> dict:
        return {
            "content":      self.content,
            "isError":      self.is_error,
            "errorMessage": self.error_message,
        }

    def __repr__(self) -> str:
        return f"MCPCallToolResponse(error={self.is_error}, blocks={len(self.content)})"


# ══════════════════════════════════════════════════════════════════════
# MCPClient  — used by agents to speak MCP with the Tools Layer
# ══════════════════════════════════════════════════════════════════════

class MCPClient:
    """
    HTTP client that agents use to communicate with the MCP Server.

    WHY: Encapsulates all MCP HTTP calls behind a clean interface.
         Agents call list_tools() once at startup to discover what's
         available, then call_tool() for every tool invocation.
         This decouples agents from knowing tool URLs or schemas.

    Used by: PractitionerAgent, FacilityAgent, NpiValidationTool
    """

    def __init__(self, base_url: str, timeout: float = 10.0) -> None:
        self._base    = base_url.rstrip("/")
        self._timeout = timeout
        self._cached_tools: Optional[MCPListToolsResponse] = None

    @property
    def base_url(self) -> str:
        return self._base

    async def list_tools(self, force_refresh: bool = False) -> MCPListToolsResponse:
        """
        Discover all available tools from the MCP server.
        Result is cached — agents call this once at startup.
        """
        if self._cached_tools and not force_refresh:
            return self._cached_tools

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.get(f"{self._base}/mcp/list_tools")
            resp.raise_for_status()
            raw = resp.json()

        tools = [
            MCPToolDefinition(
                name=t["name"],
                description=t["description"],
                input_schema=MCPToolSchema(**t.get("inputSchema", {})),
                accessible_by=t.get("accessibleBy", []),
                owner_team=t.get("ownerTeam", ""),
                requires_human_approval=t.get("requiresHumanApproval", False),
            )
            for t in raw.get("tools", [])
        ]
        self._cached_tools = MCPListToolsResponse(tools=tools)
        logger.info("MCPClient discovered %d tools from %s", len(tools), self._base)
        return self._cached_tools

    async def call_tool(
        self,
        name: str,
        arguments: dict,
        caller: str = "unknown",
    ) -> MCPCallToolResponse:
        """
        Invoke a tool on the MCP server by name + arguments.
        Returns a standardised MCPCallToolResponse.
        """
        request = MCPCallToolRequest(name=name, arguments=arguments, caller=caller)
        logger.debug("MCPClient calling tool %r with %s", name, arguments)

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{self._base}/mcp/call_tool",
                json=request.to_dict(),
            )

        if resp.status_code >= 400:
            return MCPCallToolResponse.error(
                f"HTTP {resp.status_code} from MCP server: {resp.text[:200]}"
            )

        raw = resp.json()
        return MCPCallToolResponse(
            content=raw.get("content", []),
            is_error=raw.get("isError", False),
            error_message=raw.get("errorMessage", ""),
        )

    def __repr__(self) -> str:
        cached = len(self._cached_tools.tools) if self._cached_tools else 0
        return f"MCPClient(base={self._base!r}, cached_tools={cached})"


# ══════════════════════════════════════════════════════════════════════
# MCPRegistry  — server-side, backs the /mcp/* endpoints
# ══════════════════════════════════════════════════════════════════════

class MCPRegistry:
    """
    Server-side MCP registry that the MCPServer exposes via FastAPI.

    WHY: Holds MCPToolDefinitions and dispatches call_tool requests
         to concrete BaseTool instances. This is the bridge between
         the MCP HTTP protocol and the Python tool objects.

    Mounted by: MCPServer in tools_layer/tools_server.py
    """

    def __init__(self) -> None:
        self._definitions: dict[str, MCPToolDefinition] = {}
        self._executors: dict[str, Any] = {}   # name → BaseTool instance

    def register(
        self,
        definition: MCPToolDefinition,
        executor: Any,          # BaseTool instance
    ) -> None:
        self._definitions[definition.name] = definition
        self._executors[definition.name]   = executor
        logger.info("MCPRegistry registered tool: %r", definition.name)

    def list_tools(self) -> MCPListToolsResponse:
        return MCPListToolsResponse(tools=list(self._definitions.values()))

    def call_tool(self, request: MCPCallToolRequest) -> MCPCallToolResponse:
        defn = self._definitions.get(request.name)
        if not defn:
            return MCPCallToolResponse.error(f"Tool '{request.name}' not found")

        if not defn.is_accessible_by(request.caller):
            return MCPCallToolResponse.error(
                f"Agent '{request.caller}' not authorised for tool '{request.name}'"
            )

        executor = self._executors[request.name]
        try:
            result = executor.execute(caller=request.caller, **request.arguments)
            return MCPCallToolResponse.success(result.to_dict())
        except Exception as exc:
            logger.error("Tool %r raised: %s", request.name, exc)
            return MCPCallToolResponse.error(str(exc))

    def __len__(self) -> int:
        return len(self._definitions)

    def __repr__(self) -> str:
        return f"MCPRegistry(tools={list(self._definitions.keys())})"
