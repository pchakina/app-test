"""
shared/models.py
─────────────────
Domain value objects shared across all three layers.
All classes are immutable-style dataclasses with __repr__ and validation.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional


# ── Base ──────────────────────────────────────────────────────────────

@dataclass
class BaseModel:
    """Root base for all domain objects. Provides created_at and a uuid."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in self.__dict__.items()}

    def __repr__(self) -> str:
        fields = ", ".join(f"{k}={v!r}" for k, v in self.__dict__.items())
        return f"{self.__class__.__name__}({fields})"


# ── A2A Protocol ──────────────────────────────────────────────────────

@dataclass
class A2AMessage(BaseModel):
    """
    Agent-to-Agent message envelope (a2a http protocol).
    Now carries conversation_history so agents have full context.
    """
    sender: str = ""
    recipient: str = ""
    intent: str = "auto"
    payload: dict = field(default_factory=dict)
    # Bedrock-formatted conversation history from ConversationHistory.to_bedrock_turns()
    conversation_history: list = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.sender:
            raise ValueError("A2AMessage.sender must not be empty")

    @classmethod
    def from_question(
        cls,
        sender: str,
        question: str,
        intent: str = "auto",
        conversation_history: Optional[list] = None,
    ) -> "A2AMessage":
        return cls(
            sender=sender,
            recipient="agent_registry",
            intent=intent,
            payload={"question": question},
            conversation_history=conversation_history or [],
        )

    @property
    def question(self) -> str:
        return self.payload.get("question", "")


# ── Blueprints ────────────────────────────────────────────────────────

@dataclass
class AgentBlueprint(BaseModel):
    name: str = ""
    description: str = ""
    owner_team: str = ""
    llm_used: str = ""
    skills: list[str] = field(default_factory=list)
    discover_endpoint: str = "/a2a/discover"
    task_endpoint: str = "/a2a/task"
    health_endpoint: str = "/health"

    def can_handle(self, skill: str) -> bool:
        return skill in self.skills

    def __repr__(self) -> str:
        return f"AgentBlueprint(name={self.name!r}, skills={self.skills})"


@dataclass
class ToolBlueprint(BaseModel):
    tool_name: str = ""
    description: str = ""
    input_schema: dict = field(default_factory=dict)
    accessible_by: list[str] = field(default_factory=list)
    owner_team: str = ""
    requires_human_approval: bool = False

    def is_accessible_by(self, agent_name: str) -> bool:
        return agent_name in self.accessible_by

    def __repr__(self) -> str:
        return (f"ToolBlueprint(name={self.tool_name!r}, "
                f"accessible_by={self.accessible_by})")


# ── Audit ──────────────────────────────────────────────────────────────

@dataclass
class AuditEntry(BaseModel):
    layer: str = ""
    component: str = ""
    action: str = ""
    details: dict = field(default_factory=dict)
    status: str = "ok"

    def __repr__(self) -> str:
        return (f"AuditEntry(ts={self.created_at[11:19]}, "
                f"layer={self.layer!r}, component={self.component!r}, "
                f"action={self.action!r}, status={self.status!r})")


# ── Tool Results ───────────────────────────────────────────────────────

@dataclass
class ToolResult(BaseModel):
    tool_name: str = ""
    records: list[dict] = field(default_factory=list)
    success: bool = True
    error: str = ""

    @property
    def count(self) -> int:
        return len(self.records)

    @property
    def is_empty(self) -> bool:
        return self.count == 0

    def __repr__(self) -> str:
        return f"ToolResult(tool={self.tool_name!r}, count={self.count}, ok={self.success})"


# ── Agent Task ─────────────────────────────────────────────────────────

@dataclass
class AgentTaskResult(BaseModel):
    """Final answer returned from the Agent Layer to the App Layer."""
    question: str = ""
    intent: str = ""
    answer: str = ""
    raw_result: ToolResult = field(default_factory=ToolResult)
    llm_model: str = ""
    context_turns_used: int = 0    # how many history turns were passed to Bedrock

    def __repr__(self) -> str:
        return (f"AgentTaskResult(intent={self.intent!r}, "
                f"records={self.raw_result.count}, "
                f"context_turns={self.context_turns_used}, "
                f"answer_len={len(self.answer)})")
