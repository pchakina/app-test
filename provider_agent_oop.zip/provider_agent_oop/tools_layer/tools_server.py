"""
tools_layer/tools_server.py
────────────────────────────
Layer 3 — MCP Server  (port 8002)

WHY THIS FILE EXISTS:
  This is "Layer 3 — Tools Layer" from the architecture diagram.
  It exposes real data (providers, facilities, NPI validation) through
  the MCP protocol so any agent can discover and call tools at runtime.

OOP Class hierarchy:
  MockDataStore           — in-memory data (replaces Symplr sPayerAPIs)
  ProviderLookupTool      — finds practitioners  (extends BaseTool)
  FacilityLookupTool      — finds facilities     (extends BaseTool)
  NpiValidationTool       — validates NPIs        (extends BaseTool)
  ToolRegistry            — holds all tools       (extends BaseRegistry)
  MCPServer               — owns everything + FastAPI routes

MCP endpoints added:
  GET  /mcp/list_tools    — agents call this to discover available tools
  POST /mcp/call_tool     — agents call this to execute a tool
  GET  /tools/*           — legacy REST endpoints (still work)
"""
from __future__ import annotations

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from typing import Optional
from fastapi import FastAPI
from pydantic import BaseModel as PydanticBase

from shared.audit_log import AuditLog
from shared.base_classes import BaseTool, BaseRegistry
from shared.config import ConfigLoader
from shared.models import ToolBlueprint, ToolResult
from shared.mcp_protocol import (
    MCPRegistry, MCPCallToolRequest, MCPCallToolResponse,
    MCPToolDefinition, MCPToolSchema,
)


# ══════════════════════════════════════════════════════════════════════
# MockDataStore
# ──────────────
# WHY: Replaces Symplr sPayerAPIs for local dev / testing.
#      Isolated in its own class so swapping to real APIs = change one class.
# ══════════════════════════════════════════════════════════════════════

class MockDataStore:
    """
    In-memory stand-in for the real Symplr sPayerAPIs.
    Isolated here so production just swaps this class for a real HTTP client.
    """

    _PROVIDERS: list[dict] = [
        {"npi": "1234567890", "name": "Dr. Alice Chen",   "specialty": "Cardiology", "state": "TX", "active": True},
        {"npi": "9876543210", "name": "Dr. Bob Martinez", "specialty": "Pediatrics", "state": "FL", "active": True},
        {"npi": "1111111111", "name": "Dr. Carol White",  "specialty": "Neurology",  "state": "CA", "active": False},
    ]
    _FACILITIES: list[dict] = [
        {"id": "FAC001", "name": "Sunrise Medical Center", "city": "Austin",        "state": "TX", "beds": 120},
        {"id": "FAC002", "name": "Bayshore Clinic",        "city": "Miami",         "state": "FL", "beds": 45},
        {"id": "FAC003", "name": "Golden Gate Hospital",   "city": "San Francisco", "state": "CA", "beds": 300},
    ]

    def search_providers(self, query: str) -> list[dict]:
        q = query.lower()
        hits = [
            p for p in self._PROVIDERS
            if q in p["name"].lower() or q in p["specialty"].lower() or q == p["npi"]
        ]
        return hits or list(self._PROVIDERS)

    def search_facilities(self, query: str) -> list[dict]:
        q = query.lower()
        hits = [
            f for f in self._FACILITIES
            if q in f["name"].lower() or q in f["city"].lower() or q in f["state"].lower()
        ]
        return hits or list(self._FACILITIES)

    def find_by_npi(self, npi: str) -> Optional[dict]:
        return next((p for p in self._PROVIDERS if p["npi"] == npi), None)

    def __repr__(self) -> str:
        return (f"MockDataStore("
                f"providers={len(self._PROVIDERS)}, "
                f"facilities={len(self._FACILITIES)})")


# ══════════════════════════════════════════════════════════════════════
# Concrete Tool Classes
# ──────────────────────
# WHY: Each tool is its own class so:
#   1. Each has a single responsibility
#   2. New tools = new class, no existing code changes (Open/Closed)
#   3. BaseTool enforces the execute() contract + access control
# ══════════════════════════════════════════════════════════════════════

class ProviderLookupTool(BaseTool):
    """
    WHY: Encapsulates all provider search logic.
    Agents never talk to MockDataStore directly — they go through this class.
    MCP exposes this as tool name 'lookup_provider'.
    """

    _BLUEPRINT = ToolBlueprint(
        tool_name="lookup_provider",
        description="Find a healthcare provider by name, specialty, or NPI",
        input_schema={"query": "string"},
        accessible_by=["practitioner_agent", "synthesis_agent"],
        owner_team="Provider Data Team",
    )
    _MCP_DEFINITION = MCPToolDefinition(
        name="lookup_provider",
        description="Find a healthcare provider by name, specialty, or NPI number",
        input_schema=MCPToolSchema.simple_string(
            "query", "Provider name, specialty (e.g. 'Cardiology'), or NPI number"
        ),
        accessible_by=["practitioner_agent", "synthesis_agent"],
        owner_team="Provider Data Team",
    )

    def __init__(self, store: MockDataStore, audit_log: AuditLog) -> None:
        super().__init__(self._BLUEPRINT, audit_log)
        self._store = store

    def execute(self, query: str = "", caller: str = "unknown") -> ToolResult:
        self._check_access(caller)
        self._log("query", {"query": query, "caller": caller})
        records = self._store.search_providers(query)
        result  = ToolResult(tool_name=self._name, records=records)
        self._log("result", {"count": result.count})
        return result


class FacilityLookupTool(BaseTool):
    """
    WHY: Encapsulates all facility/clinic search logic.
    Single responsibility: find facilities. Nothing else.
    MCP exposes this as tool name 'lookup_facility'.
    """

    _BLUEPRINT = ToolBlueprint(
        tool_name="lookup_facility",
        description="Find a clinic or hospital by name, city, or state",
        input_schema={"query": "string"},
        accessible_by=["facility_agent", "synthesis_agent"],
        owner_team="Facility Data Team",
    )
    _MCP_DEFINITION = MCPToolDefinition(
        name="lookup_facility",
        description="Find a clinic or hospital by name, city, or state",
        input_schema=MCPToolSchema.simple_string(
            "query", "Facility name, city, or US state abbreviation (e.g. 'TX')"
        ),
        accessible_by=["facility_agent", "synthesis_agent"],
        owner_team="Facility Data Team",
    )

    def __init__(self, store: MockDataStore, audit_log: AuditLog) -> None:
        super().__init__(self._BLUEPRINT, audit_log)
        self._store = store

    def execute(self, query: str = "", caller: str = "unknown") -> ToolResult:
        self._check_access(caller)
        self._log("query", {"query": query, "caller": caller})
        records = self._store.search_facilities(query)
        result  = ToolResult(tool_name=self._name, records=records)
        self._log("result", {"count": result.count})
        return result


class NpiValidationTool(BaseTool):
    """
    WHY: NPI validation is a distinct compliance concern — its own class
    means it can have its own access rules, logging, and error handling.
    MCP exposes this as tool name 'validate_npi'.
    """

    _BLUEPRINT = ToolBlueprint(
        tool_name="validate_npi",
        description="Validate an NPI number",
        input_schema={"npi": "string"},
        accessible_by=["practitioner_agent"],
        owner_team="Validation Team",
    )
    _MCP_DEFINITION = MCPToolDefinition(
        name="validate_npi",
        description="Validate a 10-digit National Provider Identifier (NPI) number",
        input_schema=MCPToolSchema.simple_string(
            "npi", "10-digit NPI number to validate"
        ),
        accessible_by=["practitioner_agent"],
        owner_team="Validation Team",
    )

    def __init__(self, store: MockDataStore, audit_log: AuditLog) -> None:
        super().__init__(self._BLUEPRINT, audit_log)
        self._store = store

    def execute(self, npi: str = "", caller: str = "unknown") -> ToolResult:
        self._check_access(caller)
        self._log("query", {"npi": npi, "caller": caller})
        match   = self._store.find_by_npi(npi)
        records = [match] if match else []
        result  = ToolResult(tool_name=self._name, records=records, success=bool(match))
        self._log("result", {"valid": not result.is_empty})
        return result


# ══════════════════════════════════════════════════════════════════════
# ToolRegistry
# ─────────────
# WHY: Single place that holds every tool. Agents never instantiate tools
#      directly — they ask the registry. Enables runtime discovery.
# ══════════════════════════════════════════════════════════════════════

class ToolRegistry(BaseRegistry):
    """
    WHY: Central catalogue of all tools.
    Inherits register(), get(), discover() from BaseRegistry.
    Adds execute_tool() so callers don't need to know tool internals.
    """

    def __init__(self, audit_log: AuditLog) -> None:
        super().__init__("tool_registry", audit_log)

    def _layer_name(self) -> str:
        return "tools"

    def execute_tool(self, tool_name: str, caller: str, **kwargs) -> ToolResult:
        tool: Optional[BaseTool] = self.get(tool_name)
        if not tool:
            return ToolResult(
                tool_name=tool_name,
                success=False,
                error=f"Tool '{tool_name}' not found in registry",
            )
        return tool.execute(caller=caller, **kwargs)


# ══════════════════════════════════════════════════════════════════════
# MCPServer
# ──────────
# WHY: Composition root for Layer 3.
#      Wires MockDataStore → tools → ToolRegistry → MCPRegistry → FastAPI.
#      Also mounts the MCP protocol endpoints (/mcp/*) that agents call.
# ══════════════════════════════════════════════════════════════════════

class MCPServer:
    """
    WHY: Owns all Layer 3 objects and exposes them via HTTP.
    Single constructor composes the full tools layer.
    MCP endpoints let agents discover + call tools via the standard protocol.
    """

    def __init__(self, cfg: dict) -> None:
        self._cfg      = cfg
        self._audit    = AuditLog.from_config(cfg)
        self._store    = MockDataStore()
        self._registry = self._build_tool_registry()
        self._mcp      = self._build_mcp_registry()
        self.app       = self._build_app()

    def _build_tool_registry(self) -> ToolRegistry:
        registry = ToolRegistry(self._audit)
        registry.register("lookup_provider", ProviderLookupTool(self._store, self._audit))
        registry.register("lookup_facility", FacilityLookupTool(self._store, self._audit))
        registry.register("validate_npi",    NpiValidationTool(self._store,  self._audit))
        return registry

    def _build_mcp_registry(self) -> MCPRegistry:
        """Build the MCP registry wired to the same tool instances."""
        mcp = MCPRegistry()
        mcp.register(ProviderLookupTool._MCP_DEFINITION, self._registry.get("lookup_provider"))
        mcp.register(FacilityLookupTool._MCP_DEFINITION, self._registry.get("lookup_facility"))
        mcp.register(NpiValidationTool._MCP_DEFINITION,  self._registry.get("validate_npi"))
        return mcp

    def _build_app(self) -> FastAPI:
        app = FastAPI(title="MCP Tools Server", version="2.0")

        # ── MCP Protocol endpoints (used by agents) ────────────────────

        @app.get("/mcp/list_tools")
        def mcp_list_tools():
            """MCP discovery — agents call this at startup."""
            return self._mcp.list_tools().to_dict()

        class CallToolBody(PydanticBase):
            name: str
            arguments: dict = {}
            caller: str = "unknown"

        @app.post("/mcp/call_tool")
        def mcp_call_tool(body: CallToolBody):
            """MCP invocation — agents call this to run a tool."""
            req    = MCPCallToolRequest(name=body.name, arguments=body.arguments, caller=body.caller)
            result = self._mcp.call_tool(req)
            return result.to_dict()

        # ── Legacy REST endpoints (still available) ────────────────────

        @app.get("/health")
        def health():
            return {"status": "healthy", "layer": "tools",
                    "tools": len(self._registry), "mcp": len(self._mcp)}

        @app.get("/registry")
        def list_tools():
            return self._registry.discover()

        @app.get("/tools/lookup_provider")
        def lookup_provider(query: str, caller: str = "unknown"):
            result = self._registry.execute_tool("lookup_provider", caller, query=query)
            return {"tool": result.tool_name, "results": result.records}

        @app.get("/tools/lookup_facility")
        def lookup_facility(query: str, caller: str = "unknown"):
            result = self._registry.execute_tool("lookup_facility", caller, query=query)
            return {"tool": result.tool_name, "results": result.records}

        @app.get("/tools/validate_npi")
        def validate_npi(npi: str, caller: str = "unknown"):
            result = self._registry.execute_tool("validate_npi", caller, npi=npi)
            return {"tool": result.tool_name, "npi": npi,
                    "valid": not result.is_empty,
                    "provider": result.records[0] if result.records else None}

        return app

    def __repr__(self) -> str:
        return f"MCPServer(tools={len(self._registry)}, store={self._store})"


# ── Entry point ────────────────────────────────────────────────────────
cfg    = ConfigLoader.load_default()
server = MCPServer(cfg)
app    = server.app

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002, log_level="warning")
