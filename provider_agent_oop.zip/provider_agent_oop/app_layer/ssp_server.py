"""
app_layer/ssp_server.py
────────────────────────
Layer 1 — SSP  (port 8000)

Context feature: ConversationHistory.to_bedrock_turns() is passed with
every /ask request so Bedrock/Gemma always has the full session context.

OOP structure:
  TemplateLoader       — loads chat.html from disk, does {{ token }} substitution
  ConversationHistory  — multi-turn context window; serialises to Bedrock format
  A2AClient            — sends questions + conversation history to Agent Layer
  SSPServer            — composition root, owns all of the above + FastAPI
"""
from __future__ import annotations

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pathlib import Path
from typing import Optional

import httpx
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel as PydanticBase

from shared.audit_log import AuditLog
from shared.config import ConfigLoader
from shared.models import AuditEntry


# ══════════════════════════════════════════════════════════════════════
# TemplateLoader
# ───────────────
# WHY: All HTML lives in templates/chat.html.
#      This class reads it and replaces {{ tokens }} at render time.
#      Zero HTML strings exist anywhere in Python files.
# ══════════════════════════════════════════════════════════════════════

class TemplateLoader:
    """
    Loads external HTML template files and performs {{ variable }} substitution.

    WHY: HTML is presentation, Python is logic — they must not mix.
         Designers can edit chat.html without touching Python code.
    """

    _TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"

    def __init__(self, template_dir: Optional[Path] = None) -> None:
        self._dir = template_dir or self._TEMPLATE_DIR

    def render(self, filename: str, context: Optional[dict] = None) -> str:
        path = self._dir / filename
        if not path.exists():
            raise FileNotFoundError(f"Template not found: {path}")
        html = path.read_text(encoding="utf-8")
        for key, value in (context or {}).items():
            html = html.replace("{{ " + key + " }}", str(value))
        return html

    def __repr__(self) -> str:
        return f"TemplateLoader(dir={self._dir})"


# ══════════════════════════════════════════════════════════════════════
# ConversationHistory
# ────────────────────
# WHY: The SSP diagram shows "Context History" as a first-class component.
#      This class owns the multi-turn memory and serialises it to the
#      exact format Bedrock's converse() API expects.
#
#      to_bedrock_turns() is the critical method — it converts stored
#      turns into [{"role": "user", "content": [{"text": "..."}]}, ...]
#      which Bedrock passes as prior context to the LLM.
# ══════════════════════════════════════════════════════════════════════

class ConversationHistory:
    """
    Multi-turn conversation context window.

    WHY: Without this, every question is answered in isolation.
         With it, Gemma can answer follow-up questions like
         "what about that doctor's NPI?" because it remembers
         the previous exchange.

    Key method: to_bedrock_turns() — serialises history into the
    exact list format that BedrockGemmaClient.chat_sync() expects
    as conversation_history argument.
    """

    def __init__(self, system_prompt: str = "", max_turns: int = 20) -> None:
        self._system_prompt = system_prompt
        self._max_turns     = max_turns          # kept turns per side (user + assistant)
        self._turns: list[dict] = []             # {"role": str, "content": str}

    # ── Write ──────────────────────────────────────────────────────────

    def add_user(self, message: str) -> None:
        self._turns.append({"role": "user", "content": message})
        self._trim()

    def add_assistant(self, message: str) -> None:
        self._turns.append({"role": "assistant", "content": message})

    def _trim(self) -> None:
        """Keep only the most recent max_turns pairs to avoid context bloat."""
        limit = self._max_turns * 2   # user + assistant per turn
        if len(self._turns) > limit:
            self._turns = self._turns[-limit:]

    # ── Serialise for Bedrock ──────────────────────────────────────────

    def to_bedrock_turns(self) -> list[dict]:
        """
        Convert stored turns to Bedrock converse() message format.

        Bedrock expects:
          [
            {"role": "user",      "content": [{"text": "Find a cardiologist"}]},
            {"role": "assistant", "content": [{"text": "Dr. Alice Chen..."}]},
            ...
          ]

        This is what gets passed as conversation_history to the LLM,
        giving Gemma full awareness of everything said so far.
        """
        return [
            {
                "role":    turn["role"],
                "content": [{"text": turn["content"]}],
            }
            for turn in self._turns
        ]

    def to_serialisable(self) -> list[dict]:
        """Plain dict list for JSON API responses (/history endpoint)."""
        return list(self._turns)

    # ── Properties ─────────────────────────────────────────────────────

    @property
    def system_prompt(self) -> str:
        return self._system_prompt

    @property
    def turn_count(self) -> int:
        """Number of complete (user + assistant) rounds."""
        return len(self._turns) // 2

    @property
    def bedrock_turn_count(self) -> int:
        """Total individual messages in the Bedrock context window."""
        return len(self._turns)

    def clear(self) -> None:
        self._turns = []

    def __repr__(self) -> str:
        return (f"ConversationHistory("
                f"turns={self.turn_count}, "
                f"max={self._max_turns}, "
                f"bedrock_msgs={self.bedrock_turn_count})")


# ══════════════════════════════════════════════════════════════════════
# A2AClient
# ──────────
# WHY: All HTTP calls from App Layer → Agent Layer go through here.
#      Now sends conversation_history with every task so the Agent
#      Layer can pass it all the way through to Bedrock.
# ══════════════════════════════════════════════════════════════════════

class A2AClient:
    """
    HTTP client for the Agent-to-Agent protocol.

    WHY: Encapsulates transport. If the protocol changes (gRPC, WS),
         only this class changes. Agents never see httpx.

    Context usage: send_task() accepts bedrock_history and includes
    it in the JSON body so AgentLayerServer can forward it to Bedrock.
    """

    def __init__(self, agent_base_url: str, timeout: float = 30.0) -> None:
        self._base    = agent_base_url.rstrip("/")
        self._timeout = timeout

    async def send_task(
        self,
        question: str,
        sender: str = "ssp",
        intent: str = "auto",
        bedrock_history: Optional[list] = None,
    ) -> dict:
        """
        Send a task via a2a HTTP.
        bedrock_history is the serialised ConversationHistory.to_bedrock_turns()
        — it travels all the way to Bedrock so the LLM has full context.
        """
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{self._base}/a2a/task",
                json={
                    "sender":               sender,
                    "question":             question,
                    "intent":               intent,
                    "conversation_history": bedrock_history or [],
                },
            )
            resp.raise_for_status()
            return resp.json()

    async def discover(self) -> dict:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(f"{self._base}/a2a/discover")
            return resp.json()

    async def health(self) -> dict:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(f"{self._base}/health")
            return resp.json()

    def __repr__(self) -> str:
        return f"A2AClient(base={self._base!r})"


# ══════════════════════════════════════════════════════════════════════
# SSPServer — composition root
# ══════════════════════════════════════════════════════════════════════

class SSPServer:
    """
    WHY: Owns every Layer 1 object and wires them together.
         - TemplateLoader:       serves chat.html from disk
         - ConversationHistory:  holds and serialises the context window
         - A2AClient:            passes question + full history to agents
         - AuditLog:             records every action
    """

    def __init__(self, cfg: dict) -> None:
        self._cfg     = cfg
        self._audit   = AuditLog.from_config(cfg)
        self._tmpl    = TemplateLoader()
        self._a2a     = A2AClient(cfg.get("services", {}).get("agent_url", "http://localhost:8001"))
        app_cfg       = cfg.get("app", {})
        system_prompt = cfg.get("prompts", {}).get("ssp_system", "You are a helpful assistant.")
        self._history = ConversationHistory(
            system_prompt=system_prompt.strip(),
            max_turns=app_cfg.get("max_turns", 20),
        )
        self._title   = app_cfg.get("title", "sPayer Provider Intelligence Platform")
        self._version = app_cfg.get("version", "2.0")
        self.app      = self._build_app()

    def _build_app(self) -> FastAPI:
        app = FastAPI(title=self._title, version=self._version)

        class AskRequest(PydanticBase):
            question: str

        @app.post("/ask")
        async def ask(req: AskRequest) -> dict:
            self._audit.write(AuditEntry(
                layer="app", component="ssp",
                action="user_question",
                details={"question": req.question,
                         "context_turns": self._history.turn_count},
            ))

            # ── Context: snapshot history BEFORE adding this question ──
            # We pass prior turns so the LLM has context but the current
            # question isn't duplicated (it's in the task payload too).
            prior_history = self._history.to_bedrock_turns()

            # Store user turn in history
            self._history.add_user(req.question)

            # Send question + full prior context to agent layer
            result = await self._a2a.send_task(
                question=req.question,
                bedrock_history=prior_history,
            )

            answer = result.get("answer", "No answer returned.")

            # Store assistant answer in history for next round
            self._history.add_assistant(answer)

            self._audit.write(AuditEntry(
                layer="app", component="ssp",
                action="answer_delivered",
                details={
                    "intent":        result.get("intent"),
                    "answer":        answer[:80],
                    "context_turns": self._history.turn_count,
                    "context_used":  result.get("context_turns_used", 0),
                },
            ))

            raw_result = result.get("raw_result") or {}
            return {
                "question":          req.question,
                "answer":            answer,
                "intent":            result.get("intent"),
                "raw_count":         len(raw_result.get("records", [])),
                "context_turns":     self._history.turn_count,
                "context_turns_used": result.get("context_turns_used", 0),
                "llm":               result.get("llm_model", ""),
            }

        @app.post("/clear")
        def clear_context() -> dict:
            """Clear the conversation history / context window."""
            old_count = self._history.turn_count
            self._history.clear()
            self._audit.write(AuditEntry(
                layer="app", component="ssp",
                action="context_cleared",
                details={"cleared_turns": old_count},
            ))
            return {"cleared": True, "turns_removed": old_count}

        @app.get("/history")
        def conversation_history() -> dict:
            return {
                "turn_count":    self._history.turn_count,
                "bedrock_msgs":  self._history.bedrock_turn_count,
                "messages":      self._history.to_serialisable(),
            }

        @app.get("/logs")
        def audit_logs():
            return self._audit.all()

        @app.get("/discover")
        async def discover_agents():
            return await self._a2a.discover()

        @app.get("/health")
        async def health():
            try:
                agent_health = await self._a2a.health()
            except Exception:
                agent_health = {"status": "unreachable"}
            return {
                "status":      "healthy",
                "layer":       "app",
                "history":     self._history.turn_count,
                "agent_layer": agent_health,
            }

        @app.get("/", response_class=HTMLResponse)
        def ui():
            # HTML from disk — no HTML in this Python file
            return HTMLResponse(content=self._tmpl.render(
                "chat.html",
                context={"app_title": self._title, "version": self._version},
            ))

        return app

    def __repr__(self) -> str:
        return (f"SSPServer(title={self._title!r}, "
                f"history={self._history}, a2a={self._a2a})")


# ── Entry point ────────────────────────────────────────────────────────
cfg    = ConfigLoader.load_default()
server = SSPServer(cfg)
app    = server.app

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="warning")
