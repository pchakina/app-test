"""
agent_layer/agent_server.py
────────────────────────────
Layer 2 — Agent Registry + Reusable Agent Pool (port 8001)

Context feature:
  TaskRequest now carries conversation_history (Bedrock-formatted turns).
  SynthesisAgent passes this history to BedrockGemmaClient.chat(),
  so Gemma sees the full session when generating the answer.

OOP hierarchy:
  PromptStore             — reads all prompts from config.yaml
  PractitionerAgent       — calls /tools/lookup_provider (extends BaseSpecialistAgent)
  FacilityAgent           — calls /tools/lookup_facility (extends BaseSpecialistAgent)
  IntentRouterAgent       — Gemma classifies intent (extends BaseAgent)
  SynthesisAgent          — Gemma formats answer WITH conversation context (extends BaseAgent)
  AgentRegistry           — holds & routes agents (extends BaseRegistry)
  AgentLayerServer        — composition root + FastAPI
"""
from __future__ import annotations

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from typing import Optional

from fastapi import FastAPI
from pydantic import BaseModel as PydanticBase

from shared.audit_log import AuditLog
from shared.base_classes import BaseAgent, BaseSpecialistAgent, BaseRegistry
from shared.bedrock_gemma import BedrockGemmaClient
from shared.config import ConfigLoader
from shared.models import AgentBlueprint, AgentTaskResult, AuditEntry, ToolResult


# ══════════════════════════════════════════════════════════════════════
# PromptStore
# ────────────
# WHY: All prompts live in config.yaml → prompts section.
#      Zero prompt strings exist in Python files.
#      Change a prompt = edit YAML, restart. No code deploy.
# ══════════════════════════════════════════════════════════════════════

class PromptStore:
    """
    WHY: Single source of truth for all system prompts.
         Injected into every LLM-powered agent at construction time.
         Prompts are config, not code.
    """

    def __init__(self, prompts_cfg: dict) -> None:
        self._prompts = prompts_cfg

    @classmethod
    def from_config(cls, cfg: dict) -> "PromptStore":
        return cls(cfg.get("prompts", {}))

    def get(self, key: str, fallback: str = "") -> str:
        return self._prompts.get(key, fallback).strip()

    @property
    def intent_router(self) -> str:
        return self.get("intent_router")

    @property
    def synthesis(self) -> str:
        return self.get("synthesis")

    @property
    def ssp_system(self) -> str:
        return self.get("ssp_system")

    def __repr__(self) -> str:
        return f"PromptStore(keys={list(self._prompts.keys())})"


# ══════════════════════════════════════════════════════════════════════
# Specialist Agents
# ══════════════════════════════════════════════════════════════════════

class PractitionerAgent(BaseSpecialistAgent):
    """
    WHY: Single responsibility — provider lookup only.
         Calls /tools/lookup_provider. Knows nothing about facilities.
    """
    _BLUEPRINT = AgentBlueprint(
        name="practitioner_agent",
        description="Looks up healthcare practitioners via MCP Tools Layer",
        owner_team="Provider AI Team",
        llm_used="google.gemma-3-12b-it via AWS Bedrock",
        skills=["lookup_provider", "validate_npi"],
    )

    def __init__(self, tools_base_url: str, audit_log: AuditLog) -> None:
        super().__init__(self._BLUEPRINT, tools_base_url, audit_log)

    @property
    def tool_endpoint(self) -> str:
        return "/tools/lookup_provider"


class FacilityAgent(BaseSpecialistAgent):
    """
    WHY: Single responsibility — facility lookup only.
         Calls /tools/lookup_facility. Knows nothing about providers.
    """
    _BLUEPRINT = AgentBlueprint(
        name="facility_agent",
        description="Looks up clinics and hospitals via MCP Tools Layer",
        owner_team="Facility AI Team",
        llm_used="google.gemma-3-12b-it via AWS Bedrock",
        skills=["lookup_facility"],
    )

    def __init__(self, tools_base_url: str, audit_log: AuditLog) -> None:
        super().__init__(self._BLUEPRINT, tools_base_url, audit_log)

    @property
    def tool_endpoint(self) -> str:
        return "/tools/lookup_facility"


# ══════════════════════════════════════════════════════════════════════
# LLM-powered Agents
# ══════════════════════════════════════════════════════════════════════

class IntentRouterAgent(BaseAgent):
    """
    WHY: Uses Gemma to classify intent so no keyword matching in code.
         Uses conversation_history so it can resolve pronouns in follow-ups
         ("what about that facility?" → context tells it which one).
         Prompt from PromptStore (config.yaml).
    """
    _BLUEPRINT = AgentBlueprint(
        name="intent_router",
        description="Classifies user intent via Gemma 3 12B on Bedrock",
        owner_team="Platform AI Team",
        llm_used="google.gemma-3-12b-it via AWS Bedrock",
        skills=["intent_classification"],
    )
    _VALID_INTENTS = frozenset({"provider", "facility"})

    def __init__(
        self,
        llm: BedrockGemmaClient,
        prompts: PromptStore,
        audit_log: AuditLog,
    ) -> None:
        super().__init__(self._BLUEPRINT, audit_log)
        self._llm     = llm
        self._prompts = prompts

    async def run(
        self,
        question: str,
        conversation_history: Optional[list] = None,
        **kwargs,
    ) -> str:
        self._log("start", {
            "question": question,
            "context_msgs": len(conversation_history or []),
        })
        # Pass history so Gemma can resolve "that clinic" / "them" etc.
        raw = await self._llm.chat(
            user_message=question,
            system_prompt=self._prompts.intent_router,
            conversation_history=conversation_history,
        )
        intent = raw.strip().lower().split()[0] if raw.strip() else "provider"
        intent = intent if intent in self._VALID_INTENTS else "provider"
        self._log("classified", {"intent": intent, "raw": raw[:40]})
        return intent


class SynthesisAgent(BaseAgent):
    """
    WHY: Formats the final answer using Gemma WITH the full conversation
         history as context. This is where context makes the biggest
         difference — Gemma can refer to previous answers, resolve
         follow-up questions, and avoid repeating itself.

         conversation_history passed as Bedrock turns list so the LLM
         sees the entire session before generating its response.

         Prompt from PromptStore (config.yaml).
    """
    _BLUEPRINT = AgentBlueprint(
        name="synthesis_agent",
        description="Formats final answer via Gemma 3 12B with full conversation context",
        owner_team="Platform AI Team",
        llm_used="google.gemma-3-12b-it via AWS Bedrock",
        skills=["format_response", "summarise"],
    )

    def __init__(
        self,
        llm: BedrockGemmaClient,
        prompts: PromptStore,
        audit_log: AuditLog,
    ) -> None:
        super().__init__(self._BLUEPRINT, audit_log)
        self._llm     = llm
        self._prompts = prompts

    async def run(
        self,
        question: str,
        tool_result: Optional[ToolResult] = None,
        conversation_history: Optional[list] = None,
        **kwargs,
    ) -> str:
        history = conversation_history or []
        self._log("start", {
            "question":     question,
            "context_msgs": len(history),
            "records":      tool_result.count if tool_result else 0,
        })

        if not tool_result or tool_result.is_empty:
            return "No results were found for your query."

        data_block = self._format_records(tool_result)
        user_msg   = (
            f'User question: "{question}"\n\n'
            f"Data retrieved from tools:\n{data_block}\n\n"
            "Please answer the user's question based on this data. "
            "If the conversation history shows prior questions, build on those answers naturally."
        )

        # ── Context passed here — Gemma sees the full session ──────────
        answer = await self._llm.chat(
            user_message=user_msg,
            system_prompt=self._prompts.synthesis,
            conversation_history=history,   # ← full prior session
        )

        self._log("done", {
            "answer_len":   len(answer),
            "model":        self._llm.model_id,
            "context_msgs": len(history),
        })
        return answer

    @staticmethod
    def _format_records(result: ToolResult) -> str:
        lines = []
        for r in result.records[:3]:
            if "npi" in r:
                status = "active" if r.get("active") else "inactive"
                lines.append(
                    f"  - {r['name']} | {r['specialty']} | {r['state']} "
                    f"| NPI {r['npi']} | {status}"
                )
            else:
                lines.append(
                    f"  - {r['name']} | {r['city']}, {r['state']} "
                    f"| {r.get('beds','?')} beds | ID {r['id']}"
                )
        return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════
# AgentRegistry
# ══════════════════════════════════════════════════════════════════════

class AgentRegistry(BaseRegistry):
    """
    WHY: Central catalogue of all agents.
         route_and_run() dispatches to the right specialist and passes
         conversation_history through so context flows unbroken.
    """

    def __init__(self, audit_log: AuditLog) -> None:
        super().__init__("agent_registry", audit_log)

    def _layer_name(self) -> str:
        return "agent"

    async def route_and_run(
        self,
        question: str,
        intent: str,
        conversation_history: Optional[list] = None,
    ) -> ToolResult:
        agent_name = "facility_agent" if intent == "facility" else "practitioner_agent"
        agent: BaseAgent = self.get(agent_name)
        self._log("dispatched", {"agent": agent_name, "intent": intent})
        # Specialist agents fetch data — they don't use history for retrieval
        return await agent.run(question)


# ══════════════════════════════════════════════════════════════════════
# AgentLayerServer — composition root
# ══════════════════════════════════════════════════════════════════════

class AgentLayerServer:
    """
    WHY: Owns all agents, registry, and FastAPI routes.
         Extracts conversation_history from TaskRequest and threads it
         through intent routing and synthesis so context is never lost.
    """

    def __init__(self, cfg: dict) -> None:
        self._cfg        = cfg
        self._audit      = AuditLog.from_config(cfg)
        self._llm        = BedrockGemmaClient.from_config(cfg)
        self._prompts    = PromptStore.from_config(cfg)
        self._tools_base = cfg.get("services", {}).get("tools_url", "http://localhost:8002")
        self._registry   = self._build_registry()
        self.app         = self._build_app()

    def _build_registry(self) -> AgentRegistry:
        registry = AgentRegistry(self._audit)
        registry.register("practitioner_agent",
                           PractitionerAgent(self._tools_base, self._audit))
        registry.register("facility_agent",
                           FacilityAgent(self._tools_base, self._audit))
        registry.register("intent_router",
                           IntentRouterAgent(self._llm, self._prompts, self._audit))
        registry.register("synthesis_agent",
                           SynthesisAgent(self._llm, self._prompts, self._audit))
        return registry

    def _build_app(self) -> FastAPI:
        app = FastAPI(title="Agent Registry — Gemma 3 12B", version="2.0")

        class TaskRequest(PydanticBase):
            sender:               str  = "app_layer"
            question:             str
            intent:               str  = "auto"
            # Bedrock-formatted conversation history from ConversationHistory.to_bedrock_turns()
            conversation_history: list = []

        @app.post("/a2a/task")
        async def handle_task(req: TaskRequest) -> dict:
            ctx = req.conversation_history   # full prior session from SSP

            self._audit.write(AuditEntry(
                layer="agent", component="registry",
                action="task_received",
                details={
                    "sender":       req.sender,
                    "question":     req.question,
                    "context_msgs": len(ctx),
                },
            ))

            # Step 1: intent routing — history helps resolve follow-ups
            intent_agent: IntentRouterAgent = self._registry.get("intent_router")
            if req.intent == "auto":
                intent = await intent_agent.run(req.question, conversation_history=ctx)
            elif req.intent in ("provider", "facility"):
                intent = req.intent
            else:
                intent = "provider"

            # Step 2: specialist fetches raw data (no context needed for retrieval)
            tool_result: ToolResult = await self._registry.route_and_run(
                req.question, intent, conversation_history=ctx
            )

            # Step 3: synthesis with FULL conversation context
            synthesis_agent: SynthesisAgent = self._registry.get("synthesis_agent")
            answer = await synthesis_agent.run(
                req.question,
                tool_result=tool_result,
                conversation_history=ctx,   # ← context flows here to Bedrock
            )

            return AgentTaskResult(
                question=req.question,
                intent=intent,
                answer=answer,
                raw_result=tool_result,
                llm_model=self._llm.model_id,
                context_turns_used=len(ctx),
            ).to_dict()

        @app.get("/a2a/discover")
        def discover():
            return self._registry.discover()

        @app.get("/health")
        def health():
            return {
                "status":     "healthy",
                "layer":      "agent",
                "agents":     len(self._registry),
                "llm":        self._llm.model_id,
                "auth_mode":  self._llm.auth_mode,
                "llm_region": self._llm.region,
            }

        return app

    def __repr__(self) -> str:
        return (f"AgentLayerServer(agents={len(self._registry)}, "
                f"llm={self._llm!r}, prompts={self._prompts!r})")


# ── Entry point ────────────────────────────────────────────────────────
cfg    = ConfigLoader.load_default()
server = AgentLayerServer(cfg)
app    = server.app

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001, log_level="warning")
