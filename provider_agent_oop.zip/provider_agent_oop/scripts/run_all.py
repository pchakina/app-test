#!/usr/bin/env python3
"""scripts/run_all.py — launches all three layers. Ctrl+C to stop."""
import subprocess, sys, time, os, signal, webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SERVERS = [
    {"name": "Tools Layer  :8002", "module": "tools_layer.tools_server", "color": "\033[93m"},
    {"name": "Agent Layer  :8001", "module": "agent_layer.agent_server", "color": "\033[92m"},
    {"name": "App Layer    :8000", "module": "app_layer.ssp_server",     "color": "\033[96m"},
]
RESET = "\033[0m"; BOLD = "\033[1m"; procs = []

def start(cfg):
    env = os.environ.copy(); env["PYTHONPATH"] = str(ROOT)
    p = subprocess.Popen([sys.executable, "-m", cfg["module"]], cwd=ROOT, env=env)
    procs.append(p)
    print(f"  {cfg['color']}▶ {cfg['name']}{RESET}  PID {p.pid}")

def stop_all(*_):
    print(f"\n{BOLD}Stopping...{RESET}")
    for p in procs:
        try: p.terminate()
        except: pass
    for p in procs:
        try: p.wait(timeout=3)
        except: p.kill()
    sys.exit(0)

signal.signal(signal.SIGINT, stop_all)
signal.signal(signal.SIGTERM, stop_all)

print(f"\n{BOLD}Provider Agent — OOP Edition (Gemma 3 12B){RESET}\n{'─'*44}")
for cfg in SERVERS:
    start(cfg); time.sleep(1.5)

print(f"\n{BOLD}All servers running.{RESET}")
print(f"  Chat UI → {BOLD}http://localhost:8000{RESET}")
print(f"  Press Ctrl+C to stop.\n")
time.sleep(2)
try: webbrowser.open("http://localhost:8000")
except: pass
while True:
    time.sleep(1)
