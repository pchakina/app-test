#!/usr/bin/env python3
"""scripts/test_gemma.py — verify Gemma 3 12B on Bedrock before running servers."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from shared.bedrock_gemma import BedrockGemmaClient

def run():
    print("=" * 56)
    print("BedrockGemmaClient — google.gemma-3-12b-it — pre-flight")
    print("=" * 56)
    llm = BedrockGemmaClient()
    print(f"Client: {llm!r}\n")

    tests = [
        ("Hello world",         None,                      "Say: Hello from Gemma 3 12B!"),
        ("Intent classification","One word: provider or facility.", "Find me a cardiologist in Texas"),
        ("Synthesis",            "Healthcare assistant. One sentence.", "Data: Dr. Alice Chen, Cardiology, TX. Question: Who?"),
    ]
    ok = True
    for name, system, user in tests:
        print(f"▶ {name}")
        ans = llm.chat_sync(user, system_prompt=system)
        print(f"  {ans[:100]}")
        if ans.startswith("["):
            print("  ✗ FAILED"); ok = False
        else:
            print("  ✓ passed")

    print("\n" + "=" * 56)
    if ok:
        print("✓ All passed — run: python scripts/run_all.py")
    else:
        print("✗ Fix credentials or enable model in Bedrock console:")
        print("  https://console.aws.amazon.com/bedrock/home#/modelaccess")

if __name__ == "__main__":
    run()
