# Provider Agent — OOP Edition
## Google Gemma 3 12B · AWS Bedrock · MCP · AWS SSO

---

## Project Structure

```
provider_agent_oop/
├── config/
│   └── config.yaml              ← ALL config: prompts, SSO, services, logging
├── shared/
│   ├── aws_session.py           ← AWSSessionFactory  (SSO / static / IAM)
│   ├── bedrock_gemma.py         ← BedrockGemmaClient (extends BaseLLMClient)
│   ├── audit_log.py             ← AuditLog           (injected everywhere)
│   ├── base_classes.py          ← Abstract base classes (BaseComponent, BaseTool, BaseAgent…)
│   ├── config.py                ← ConfigLoader
│   ├── mcp_protocol.py          ← MCP data contracts + MCPClient + MCPRegistry
│   └── models.py                ← Domain models (A2AMessage, ToolResult, AgentBlueprint…)
├── tools_layer/
│   └── tools_server.py          ← MCPServer, ToolRegistry, 3 Tool classes  :8002
├── agent_layer/
│   └── agent_server.py          ← AgentLayerServer, AgentRegistry, 4 Agent classes  :8001
├── app_layer/
│   ├── ssp_server.py            ← SSPServer, A2AClient, ConversationHistory, TemplateLoader  :8000
│   └── templates/
│       └── chat.html            ← Chat UI HTML (no HTML in Python files)
├── scripts/
│   ├── run_all.py               ← Start all 3 servers
│   └── test_gemma.py            ← Pre-flight Bedrock connectivity test
└── requirements.txt
```

---

## Every Class Explained

### `shared/aws_session.py`

| Class | Why it exists |
|---|---|
| **AWSSessionFactory** | Single place that handles all 3 AWS auth modes: SSO profile, static keys, or IAM role. Every class that needs boto3 receives this factory — no auth logic duplicated anywhere. |

### `shared/bedrock_gemma.py`

| Class | Why it exists |
|---|---|
| **BedrockGemmaClient** | Concrete LLM client for Gemma 3 12B via Bedrock `converse()` API. Extends `BaseLLMClient`. Auth fully delegated to `AWSSessionFactory`. Agents never touch boto3 directly. |

### `shared/base_classes.py`

| Class | Why it exists |
|---|---|
| **BaseComponent** | Root base for everything. Provides logger, `AuditLog` injection, and `_log()` helper so every class writes structured audit entries automatically. |
| **BaseTool** | Abstract base for all Tools Layer tools. Enforces `execute()` contract + built-in `_check_access()` so every tool validates caller permissions the same way. |
| **BaseSpecialistAgent** | Abstract base for agents that call a single tool endpoint. Provides the shared HTTP call logic in `run()` — subclasses only declare `tool_endpoint`. |
| **BaseAgent** | Abstract base for all agents. Enforces `run()` contract. |
| **BaseRegistry** | Abstract base for `ToolRegistry` and `AgentRegistry`. Provides `register()`, `get()`, `discover()`, `__len__`, `__contains__`. |
| **BaseLLMClient** | Abstract LLM interface. Swap `BedrockGemmaClient` for any other backend without touching agent code. |

### `shared/mcp_protocol.py`

| Class | Why it exists |
|---|---|
| **MCPToolSchema** | JSON Schema for a tool's inputs. The LLM reads this at runtime to know what fields to populate — eliminates guessing. |
| **MCPToolDefinition** | Full tool spec (name, description, schema, access rules). Returned by `/mcp/list_tools`. |
| **MCPListToolsResponse** | Standardised envelope for tool discovery responses. Every MCP client parses the same shape. |
| **MCPCallToolRequest** | Standardised request envelope for tool invocation. Name + arguments + caller. |
| **MCPCallToolResponse** | Standardised response with `isError` flag. Agents handle errors without parsing strings. |
| **MCPClient** | HTTP client agents use to speak MCP. `list_tools()` at startup, `call_tool()` per request. Decouples agents from tool URLs and schemas. |
| **MCPRegistry** | Server-side registry backing the `/mcp/*` endpoints. Bridges MCP HTTP protocol to Python tool objects. |

### `shared/models.py`

| Class | Why it exists |
|---|---|
| **BaseModel** | Root dataclass with `id`, `created_at`, `to_dict()`, `__repr__`. |
| **A2AMessage** | Agent-to-Agent message envelope. Has `from_question()` factory and `question` property. |
| **AgentBlueprint** | What every agent declares about itself (diagram: Agent Blue Print). |
| **ToolBlueprint** | What every tool declares (diagram: Tools Registry Blueprint). |
| **AuditEntry** | Immutable audit record written by every component. |
| **ToolResult** | Wrapper returned by every tool call. Has `count`, `is_empty` properties. |
| **AgentTaskResult** | Final answer from Agent Layer to App Layer. |

### `shared/audit_log.py`

| Class | Why it exists |
|---|---|
| **AuditLog** | Centralised audit log (diagram: "Status Service"). Injected into every `BaseComponent`. `from_config()` factory, `write()`, `filter()`, `all()`. Singleton-compatible via `get_default()`. |

### `shared/config.py`

| Class | Why it exists |
|---|---|
| **ConfigLoader** | Loads `config.yaml` + applies `SECTION__KEY` env-var overrides. `load_default()` class method for convenience. |

### `tools_layer/tools_server.py`

| Class | Why it exists |
|---|---|
| **MockDataStore** | In-memory stand-in for Symplr sPayerAPIs. Isolated so swapping to real APIs = one class change. |
| **ProviderLookupTool** | Extends `BaseTool`. Single responsibility: provider search. MCP tool name: `lookup_provider`. |
| **FacilityLookupTool** | Extends `BaseTool`. Single responsibility: facility search. MCP tool name: `lookup_facility`. |
| **NpiValidationTool** | Extends `BaseTool`. Single responsibility: NPI validation. MCP tool name: `validate_npi`. |
| **ToolRegistry** | Extends `BaseRegistry`. Holds all tools. Adds `execute_tool()` delegation method. |
| **MCPServer** | Composition root for Layer 3. Wires store → tools → ToolRegistry → MCPRegistry → FastAPI. Mounts `/mcp/list_tools` and `/mcp/call_tool`. |

### `agent_layer/agent_server.py`

| Class | Why it exists |
|---|---|
| **PromptStore** | Reads all prompts from `config.yaml → prompts`. Injected into LLM agents. Zero prompts hard-coded in Python. |
| **PractitionerAgent** | Extends `BaseSpecialistAgent`. Calls `lookup_provider` tool. Knows nothing about facilities. |
| **FacilityAgent** | Extends `BaseSpecialistAgent`. Calls `lookup_facility` tool. Knows nothing about providers. |
| **IntentRouterAgent** | Extends `BaseAgent`. Uses Gemma 3 12B + `PromptStore.intent_router` to classify "provider"/"facility". |
| **SynthesisAgent** | Extends `BaseAgent`. Uses Gemma 3 12B + `PromptStore.synthesis` to format the final human answer. |
| **AgentRegistry** | Extends `BaseRegistry`. Holds all agents. Adds `route_and_run()` dispatching. |
| **AgentLayerServer** | Composition root for Layer 2. Wires LLM → PromptStore → agents → registry → FastAPI. |

### `app_layer/ssp_server.py`

| Class | Why it exists |
|---|---|
| **TemplateLoader** | Reads HTML from `templates/chat.html` and replaces `{{ tokens }}`. Zero HTML in Python files. |
| **ConversationHistory** | Manages multi-turn context window (diagram: "Context History"). Trims old turns, never leaks state. |
| **A2AClient** | All HTTP calls to the Agent Layer go through this class. If transport changes, only this class changes. |
| **SSPServer** | Composition root for Layer 1. Owns TemplateLoader, ConversationHistory, A2AClient, AuditLog, FastAPI. |

---

## AWS SSO Setup

```bash
# 1. Configure SSO (first time only)
aws configure sso --profile your-profile-name

# 2. Login before running the app
aws sso login --profile your-profile-name

# 3. Set profile in config.yaml
#    aws.sso.enabled: true
#    aws.sso.profile: "your-profile-name"

# 4. Verify
python scripts/test_gemma.py
```

---

## Running Locally

```bash
# Install
pip install -r requirements.txt

# Test Bedrock access
python scripts/test_gemma.py

# Start all 3 servers
python scripts/run_all.py

# Open http://localhost:8000
```

---

## Key Design Principles

| Principle | Where applied |
|---|---|
| **Single Responsibility** | Each tool and agent does exactly one thing |
| **Open/Closed** | New tools = new class; existing classes unchanged |
| **Dependency Injection** | `AuditLog`, `AWSSessionFactory`, `PromptStore` injected everywhere |
| **No HTML in Python** | `TemplateLoader` reads `chat.html` from disk |
| **No prompts in Python** | `PromptStore` reads from `config.yaml` |
| **No auth logic in agents** | `AWSSessionFactory` owns all credential logic |
| **Abstract contracts** | `BaseTool`, `BaseAgent`, `BaseLLMClient` enforce interfaces |
